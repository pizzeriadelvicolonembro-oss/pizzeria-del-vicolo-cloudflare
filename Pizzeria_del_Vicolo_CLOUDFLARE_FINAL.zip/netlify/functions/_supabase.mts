/* Accesso a Supabase via REST (PostgREST) con la chiave segreta, SOLO lato server. */
export function cfg() {
  const url = Netlify.env.get("SUPABASE_URL"); const key = Netlify.env.get("SUPABASE_SECRET_KEY");
  if (!url || !key) throw new Error("Supabase non configurato (SUPABASE_URL / SUPABASE_SECRET_KEY)");
  return { url: url.replace(/\/$/, ""), key };
}
function supabaseHeaders(key: string, extra?: HeadersInit) {
  const h = new Headers(extra);
  h.set("apikey", key);
  // Le nuove chiavi Supabase sb_secret_/sb_publishable_ NON sono JWT.
  // Inviare `Authorization: Bearer sb_secret_...` fa rifiutare PostgREST.
  // Il Bearer resta solo per le vecchie chiavi JWT anon/service_role.
  if (key.split(".").length === 3) h.set("authorization", `Bearer ${key}`);
  else h.delete("authorization");
  return h;
}

export async function sb(path: string, init: RequestInit = {}) {
  const { url, key } = cfg();
  const h = supabaseHeaders(key, init.headers);
  if (init.body && !h.has("content-type")) h.set("content-type", "application/json");
  const r = await fetch(`${url}/rest/v1/${path}`, { ...init, headers: h });
  const text = await r.text(); let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) throw new Error(`Supabase ${r.status}: ${typeof data === "string" ? data : JSON.stringify(data)}`);
  return data;
}
/* Conteggio righe senza scaricarle */
export async function sbCount(path: string): Promise<number> {
  const { url, key } = cfg();
  const h = supabaseHeaders(key, { Prefer: "count=exact" });
  const r = await fetch(`${url}/rest/v1/${path}`, { method: "HEAD", headers: h });
  if (!r.ok) throw new Error(`Supabase count ${r.status}`);
  const cr = r.headers.get("content-range") || ""; const n = Number(cr.split("/")[1]);
  return Number.isFinite(n) ? n : 0;
}
export const json = (data: any, status = 200, extra: Record<string, string> = {}) =>
  Response.json(data, { status, headers: { "Cache-Control": "no-store", ...extra } });
