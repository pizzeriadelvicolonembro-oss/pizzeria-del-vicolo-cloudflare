# Pizzeria del Vicolo — audit Cloudflare

Versione auditata: 2026-09-30

## Funzioni incluse
- Sito ordini cliente con carrello, slot, promozioni, fedeltà e stato ordine.
- Gestionale PWA installabile da `https://pizzeriavicolo.it/admin/`.
- Login OWNER / STAFF.
- Il proprietario crea, sospende, elimina e cambia PIN agli account dall'app.
- Protezione contro l'eliminazione/disattivazione dell'account proprietario in uso e dell'ultimo OWNER.
- Accettazione ordine con orario confermato, poi In preparazione, Pronto, In consegna, Completato/Annullato.
- Storico, ricerca, statistiche e clienti.
- Condivisione comanda come immagine PNG dal telefono.
- Web Push, suono, email Resend, registro notifiche.
- Reminder automatico ogni 3 minuti per ordini NUOVI non accettati.
- Telegram, ntfy, telefonata Twilio e stampante cloud restano opzionali.
- Controllo sistema nell'app con stato Database / Login / Email / Push / Reminder e pulsanti di prova.

## Robustezza Cloudflare
- Custom domain previsto: `pizzeriavicolo.it` e `www.pizzeriavicolo.it`.
- `keep_vars: true`: un deploy da Wrangler non deve cancellare le variabili runtime impostate nel dashboard.
- Nome Worker allineato a `pizzeria-del-vicolo-cloudflare`.
- Variabili runtime lette anche con differenze di maiuscole/minuscole, per tollerare errori di battitura durante la migrazione mobile.
- API mai memorizzate dal service worker; pagina admin network-first.
- RLS Supabase resta attivo; il browser non riceve la chiave segreta Supabase.

## Variabili minime runtime
- `SUPABASE_URL`
- `SUPABASE_SECRET_KEY` (Secret)
- `RESEND_API_KEY` (Secret)
- `NOTIFY_EMAILS`
- `NOTIFY_FROM`
- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY` (Secret)
- `VAPID_SUBJECT`

`SITE_URL` è consigliata; se manca viene usato `https://pizzeriavicolo.it`.

## Collaudo dopo deploy
1. Aprire `/admin/` e fare login OWNER.
2. Altro → Controllo sistema: tutte le voci principali verdi.
3. Premere PROVA EMAIL.
4. Premere PROVA PUSH su un dispositivo con push attive.
5. Creare un account STAFF dall'app e fare login su un secondo telefono.
6. Fare un ordine reale di prova minimo.
7. Verificare: ordine appare, email arriva, push arriva.
8. Lasciare l'ordine NUOVO 3–6 minuti: verificare reminder.
9. Accettare: verificare che i reminder smettano.
10. Condividi comanda (foto): verificare PNG/Share Sheet.
11. Completare l'ordine e controllare storico/statistiche.

## 2026-09-30 Cloudflare Web Push runtime fix
- VAPID ES256 signing moved from Node KeyObject signing to Cloudflare Web Crypto `crypto.subtle` ECDSA P-256.
- Defensive DER-to-P1363 conversion included for runtime compatibility.
- Fix targets observed Workers error: `options.key ... Received an instance of PrivateKeyObject`.
