# Pizzeria del Vicolo — Cloudflare

Questa versione sostituisce Netlify con Cloudflare Workers + Static Assets e mantiene Supabase.

## 1. Installa e accedi
```bash
npm install
npx wrangler login
```

## 2. Imposta i secret
Imposta almeno:
```bash
npx wrangler secret put SUPABASE_URL
npx wrangler secret put SUPABASE_SECRET_KEY
npx wrangler secret put OWNER_PASSWORD
npx wrangler secret put ADMIN_SESSION_SECRET
```
Poi, se usati nel progetto, aggiungi anche: `ACCOUNTS`, `OWNER_USERNAME`, `STAFF_USERNAME`, `STAFF_PASSWORD`, `PRINT_KEY`, `RESEND_API_KEY`, `NOTIFY_EMAILS`, `NOTIFY_FROM`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_IDS`, `NTFY_TOPIC`, `NTFY_SERVER`, `NTFY_TOKEN`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`, `CALL_NUMBERS`.

Imposta anche `SITE_URL=https://pizzeriavicolo.it` come secret o variabile Cloudflare.

## 3. Deploy
```bash
npm run deploy
```

## 4. Dominio
Nel pannello Cloudflare collega `pizzeriavicolo.it` al Worker appena pubblicato (Workers & Pages > progetto > Domains & Routes > Custom Domain).

## Note
- Le URL `/api/...` restano uguali, quindi sito e gestionale non devono essere riscritti.
- L'escalation ordini è migrata su Cloudflare Cron Trigger ogni 3 minuti, 09–21 UTC, come nel progetto originale.
- Le chiavi non vanno messe nei file pubblici: usare Cloudflare Secrets.
- Il vecchio `netlify.toml` è lasciato solo come riferimento storico e non viene usato da Cloudflare.
