# Pizzeria del Vicolo — deploy Cloudflare

Questa cartella è la versione Cloudflare Workers + Static Assets.

## Deploy automatico già usato dal progetto
Build:
`rm -rf app && mkdir app && unzip -o Pizzeria_del_Vicolo_CLOUDFLARE.zip -d app && cd app && npm install`

Deploy:
`cd app && npx wrangler deploy`

## Runtime variables
Nel dashboard Worker → Settings → Runtime variables and secrets:
- SUPABASE_URL — Variable
- SUPABASE_SECRET_KEY — Secret
- RESEND_API_KEY — Secret
- NOTIFY_EMAILS — Variable
- NOTIFY_FROM — Variable
- VAPID_PUBLIC_KEY — Variable
- VAPID_PRIVATE_KEY — Secret
- VAPID_SUBJECT — Variable
- SITE_URL — Variable (consigliata)

Opzionali: PRINT_KEY, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_IDS, NTFY_TOPIC, NTFY_SERVER,
NTFY_TOKEN, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM, CALL_NUMBERS.

## Dominio
Usare Custom Domains, non Routes:
- pizzeriavicolo.it
- www.pizzeriavicolo.it

HTTP/3 può restare disattivato se una rete mobile genera ERR_QUIC_PROTOCOL_ERROR; HTTP/2 resta attivo.

## Primo controllo
Aprire `/admin/` → Altro → Controllo sistema.
Le quattro voci principali devono essere verdi: Database, Login, Email, Push.
