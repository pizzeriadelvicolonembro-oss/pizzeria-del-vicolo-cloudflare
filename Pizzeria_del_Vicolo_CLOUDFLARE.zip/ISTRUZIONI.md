# Pizzeria del Vicolo — sito ordini + gestionale (v2)

Questo pacchetto sostituisce completamente la versione online. Contiene:

- `index.html` — sito cliente (generato da `site/` + `shared/pricing.js`, non modificarlo a mano)
- `admin/` — gestionale per tablet (installabile come app)
- `netlify/functions/` — server (ordini, stati, notifiche, statistiche, escalation ogni minuto)
- `netlify/database/migrations/003_notifications_settings/`, `004_loyalty_call/`, `005_printer/`, `006_staff_users/` — quattro file `migration.sql` da eseguire UNA volta in Supabase, in ordine
- `shared/pricing.js` — **unico posto** con listino, orari e promozioni (usato da sito e server)
- `CHIAVI_PUSH_VAPID.txt` — chiavi per le notifiche push (da copiare su Netlify, poi cancellare il file dal computer)
- `tests/` — test automatici (150 controlli superati prima della consegna)

---

## 1) Supabase — esegui la migrazione (2 minuti)

1. Apri il progetto Supabase → **SQL Editor** → **New query**.
2. Incolla tutto il contenuto di `netlify/database/migrations/003_notifications_settings/migration.sql` → **Run**.
3. Poi lo stesso con `004_loyalty_call/migration.sql`, `005_printer/migration.sql` e `006_staff_users/migration.sql` → **Run** ognuno.
4. Devono finire senza errori. Si possono rieseguire senza danni.

Cosa fa: aggiunge alle tabelle esistenti le colonne per "chi ha accettato", ritardo, escalation; crea `push_subscriptions` (dispositivi con push) e `settings` (capacità per fascia); attiva la sicurezza RLS su tutte le tabelle (i dati restano leggibili solo dal server con la chiave segreta).

## 2) Netlify — variabili d'ambiente

Site configuration → Environment variables. Imposta queste (le prime 6 sono obbligatorie):

| Variabile | Valore |
|---|---|
| `SUPABASE_URL` | come oggi |
| `SUPABASE_SECRET_KEY` | come oggi (chiave **segreta/service role**, mai quella pubblica) |
| `ACCOUNTS` | `Rizwan:OWNER:password1;Zeeshan:OWNER:password2;NomeStaff:STAFF:password3` — un account per persona, separati da `;`. Il nome compare su ogni ordine accettato. Le vecchie `OWNER_PASSWORD`/`STAFF_PASSWORD` funzionano ancora ma non distinguono le persone. |
| `ADMIN_SESSION_SECRET` | una frase lunga a caso (30+ caratteri). Cambiarla scollega tutti i tablet. |
| `SESSION_DAYS` | facoltativa: per quanti giorni il tablet resta collegato senza rifare il login (default 30). |
| `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT` | da `CHIAVI_PUSH_VAPID.txt` |
| `SITE_URL` | `https://pizzeriavicolo.it` (usato nei link delle notifiche) |
| `RESEND_API_KEY` | chiave da resend.com (vedi punto 4) |
| `NOTIFY_EMAILS` | `pizzeriadelvicolonembro@gmail.com,Shanarif4@gmail.com` (tutte le email da avvisare, separate da virgola) |
| `NOTIFY_FROM` | `Pizzeria del Vicolo <ordini@pizzeriavicolo.it>` (dopo aver verificato il dominio su Resend) |
| `PRINT_KEY` | parola segreta per la stampante cloud (lettere/numeri, es. `stampante-x7q2m9`). Vedi punto 5d. |
| `NTFY_TOPIC` | allarme forte con l'app ntfy (punto 5c). |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_IDS` | **GRATIS, consigliate**: avvisi su Telegram a un gruppo con proprietari e staff, anche a gestionale chiuso. Vedi punto 5b. |
| `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`, `CALL_NUMBERS` | **facoltative e A PAGAMENTO**: telefonata automatica se un ordine non viene accettato entro 10 minuti. Senza queste, la chiamata viene saltata (SKIPPED). Con Telegram attivo non serve. |

## 3) Deploy (caricare il sito)

Il pacchetto **non ha dipendenze da installare**: sono solo file. Tre modi, dal più semplice:

1. **Trascinare la cartella** (dal computer): Netlify → il sito → **Deploys** → trascina la cartella estratta dallo zip nell'area "Drag and drop". Alla fine controlla che nella pagina del deploy compaiano le **Functions** (una ventina). Se compaiono, è fatta. Se non compaiono, usa il metodo 2.
2. **GitHub**: repository privato con questa cartella, collegato a Netlify (Add new site → Import from Git; build command vuoto, publish directory `.`). Da quel momento ogni aggiornamento è "carica i file su GitHub".
3. **Dal telefono**: Netlify → Deploys → "browse to upload" scegliendo lo **zip**. Non è garantito che le funzioni vengano pubblicate così: controlla la voce Functions nel deploy; se manca, serve il computer (metodo 1 o 2).

Consiglio: prima un **deploy di prova** (sito di staging con lo stesso database), test dei punti al capitolo 6, poi produzione.

## 4) Email (Resend, gratuito fino a 3.000 email/mese)

1. Crea l'account su resend.com → **API Keys** → crea una chiave → mettila in `RESEND_API_KEY`.
2. **Domains** → aggiungi `pizzeriavicolo.it` → copia i record DNS che ti mostra nel pannello del dominio (dove è registrato pizzeriavicolo.it) → attendi "Verified".
3. Solo dopo la verifica del dominio le email arrivano a qualsiasi indirizzo. Senza verifica, Resend consegna solo all'email con cui vi siete registrati (usate `NOTIFY_FROM` = `onboarding@resend.dev` per provare).

## 5) Push sui tablet (gratis, arrivano anche a gestionale chiuso)

Su **ogni** tablet/telefono dello staff:
1. Apri `https://pizzeriavicolo.it/admin/` → login.
2. Android/Chrome: **Installa app** (bottone in alto) o menu ⋮ → "Aggiungi a schermata Home". iPhone/iPad: Condividi → "Aggiungi alla schermata Home" (obbligatorio, altrimenti Safari non riceve push).
3. Apri il gestionale dalla schermata Home → **ATTIVA PUSH** → consenti le notifiche.
4. **Impostazioni** → "Invia push di prova a tutti": deve arrivare la notifica su ogni dispositivo. La lista "Dispositivi con push attive" mostra chi è iscritto.
5. Premi anche **SUONO** (l'allarme sonoro funziona solo con il gestionale aperto; le push funzionano sempre).

Quando un ordine viene **annullato** (anche dallo staff) parte subito un avviso ai proprietari su push, email, Telegram e ntfy, con chi l'ha annullato e il motivo.

Quando arriva un ordine: push su tutti i dispositivi + email + messaggio Telegram nel gruppo. Se nessuno accetta entro **3 minuti**: push urgente + email + Telegram "NON ACCETTATO", poi un promemoria (push + Telegram) ogni 3 minuti per al massimo 30 minuti. Se dopo **10 minuti** nessuno ha ancora accettato: **telefonata automatica** ai numeri in `CALL_NUMBERS` (solo con Twilio configurato, a pagamento, una sola chiamata per ordine). Tutto si ferma appena qualcuno preme ACCETTA o RIFIUTA. Ogni tentativo è nel registro in **Impostazioni**.

## 5a-bis) Account dello staff, dal gestionale

Non serve più toccare Netlify per ogni persona:
1. Entra nel gestionale come proprietario → **ALTRO** → riquadro **Account dello staff**.
2. Scrivi il nome (es. `Mario`) e un **PIN** di almeno 4 cifre (es. `47281`) → **CREA ACCOUNT**.
3. Manda alla persona il link `https://pizzeriavicolo.it/admin/?u=Mario`: il nome è già scritto, lei digita solo il PIN.
4. Dal riquadro puoi cambiare il PIN, sospendere o eliminare un account.

Il PIN non viene mai salvato in chiaro (solo la sua impronta). Gli account in `ACCOUNTS` su Netlify continuano a funzionare: tienine almeno uno da proprietario come chiave di riserva.

## 5b) Telegram (gratis, 5 minuti) — al posto della telefonata a pagamento

1. Sul telefono apri Telegram → cerca **@BotFather** → scrivi `/newbot` → dai un nome (es. "Ordini Vicolo") e un nome utente che finisce con `bot` (es. `vicolo_ordini_bot`). BotFather risponde con un **token** tipo `123456789:AAH...`: copialo nella variabile Netlify `TELEGRAM_BOT_TOKEN` e fai un nuovo deploy.
2. Crea un **gruppo Telegram** "Ordini Pizzeria" con te, Rizwan e lo staff. Aggiungi al gruppo il bot (cerca il suo nome utente) e scrivi un messaggio qualsiasi nel gruppo.
3. Gestionale → **Impostazioni** → riquadro **Telegram**: compare il gruppo con il suo ID (un numero che inizia con `-100`). Copialo nella variabile Netlify `TELEGRAM_CHAT_IDS` (più gruppi/persone separati da virgola) → nuovo deploy.
4. Impostazioni → "Invia push di prova a tutti": nel gruppo deve arrivare il messaggio di prova.
5. Nel gruppo imposta la **notifica con suono forte** (tieni premuto sul gruppo → Notifiche → suono). Su ogni ordine arriva: numero, totale, orario, cliente, scontrino e link al gestionale; dopo 3 minuti senza accettazione arriva l'allarme ⚠️ e poi un promemoria ogni 3 minuti.

Costo: **zero**, nessun limite per questo uso. Telegram va installato sui telefoni di chi deve ricevere gli avvisi.

## 5c) ALLARME FORTE con telefono in tasca o in carica (app ntfy, gratis)

Le push del browser e Telegram fanno il suono normale delle notifiche. Se vuoi un **allarme che continua a suonare finché qualcuno non lo tocca**, serve l'app **ntfy** (gratis, Android e iPhone):

1. Su Netlify metti la variabile `NTFY_TOPIC` con un nome **lungo e segreto** (es. `vicolo-ordini-k8f3q2-2026`): chi conosce il nome può leggere gli avvisi (che contengono solo numero ordine e importo, mai nome o telefono del cliente). Nuovo deploy.
2. Su ogni telefono: installa **ntfy** (Play Store / App Store) → tocca **+** → scrivi lo stesso nome del topic → Iscriviti. (Nel gestionale → Impostazioni il nome è scritto, così lo copi.)
3. **Android**: ntfy → Impostazioni → attiva **"Notifiche insistenti"** (max priority: il suono continua finché non tocchi la notifica). Poi tieni premuto sul topic → Impostazioni notifica → canale "Max priority" → scegli un **suono forte** e attiva **"Ignora Non disturbare"**. Infine Impostazioni Android → App → ntfy → Batteria → **"Senza limitazioni"** (altrimenti il telefono può chiudere l'app in background).
4. **iPhone**: ntfy → il topic → suono; Impostazioni iPhone → Notifiche → ntfy → attiva tutto, avvisi **Persistenti**, e in "Concentrazione/Non disturbare" aggiungi ntfy alle app consentite. Su iPhone il suono non può ripetersi da solo: arriva un suono per ogni avviso (nuovo ordine, poi ogni 3 minuti finché non accettate).
5. Gestionale → Impostazioni → **"Invia push di prova a tutti"**: il telefono deve suonare. Se non suona, il problema è nelle impostazioni del telefono (punti 3–4), non nel sito.

Stesso consiglio per **Telegram**: tieni premuto sul gruppo "Ordini" → Notifiche → suono forte; su Android Telegram → Impostazioni → Notifiche → "Ripeti notifiche" ogni 1 minuto.

Quando arriva un ordine suonano TUTTI i canali attivi: tablet (gestionale aperto), push, Telegram, ntfy, email. È voluto: meglio due allarmi che zero.

## 5d) Stampante cloud: le comande si stampano da sole

Serve una stampante termica **con funzione cloud** (si collega a internet da sola e chiede al sito se c'è da stampare, senza tablet né PC):
- **Star Micronics** con **CloudPRNT**: TSP143IV (LAN), mC-Print3 — circa €310–330.
- **Epson** con **Server Direct Print**: TM-m30III, TM-T88VII — verificare che il modello esatto abbia la funzione.
Le stampanti Bluetooth/USB economiche NON vanno bene: non sanno collegarsi a internet da sole.

Configurazione (si fa una volta, anche a casa prima di portarla in pizzeria):
1. Su Netlify metti `PRINT_KEY` (una parola segreta) → nuovo deploy.
2. Gestionale → Impostazioni → riquadro **Stampante cloud**: trovi l'indirizzo esatto da copiare.
3. Collega la stampante al router (cavo LAN) o al Wi-Fi e apri la sua pagina di configurazione dal browser (l'indirizzo IP è sullo scontrino di auto-test che stampa tenendo premuto il tasto FEED all'accensione).
   - **Star**: menu **CloudPRNT** → Enable → Server URL = indirizzo del gestionale (quello "Star") → **Polling time = 60 secondi** → Save.
   - **Epson**: menu **Server Direct Print** → Enable → URL = indirizzo "Epson" → Interval = 60 secondi → Response URL = lo stesso indirizzo → Save.
4. Fai un ordine di prova: entro un minuto la comanda esce da sola. In Impostazioni vedi "Ultimo contatto della stampante".

Cosa stampa: ogni ordine nuovo (una volta sola), con CONSEGNA/RITIRO, orario richiesto, articoli, aggiunte, note, omaggi, totale, cliente e telefono. Se la carta finisce, la comanda viene ristampata al giro dopo. Se la stampante è spenta (pizzeria chiusa), gli ordini arrivati nel frattempo escono tutti all'accensione. Il tasto **📠** in ogni ordine la ristampa a comando (utile dopo l'accettazione con +30, per avere l'orario confermato sulla carta).

Perché 60 secondi e non 5: ogni interrogazione è una chiamata al server e il piano gratuito di Netlify ne dà **125.000 al mese**. La stampante da sola, a 60 s, ne usa ~43.000. A 5 secondi il sito verrebbe sospeso in una settimana.

Non ho potuto provare con una stampante vera: il protocollo è quello ufficiale, ma al primo ordine reale controlla che stampi bene accenti e taglio. Se c'è un problema, mandami la foto della comanda.

## 6) Test obbligatori prima di dire "funziona" (dal documento di consegna)

Fateli in due: uno fa il cliente dal telefono, l'altro sta sul tablet.

1. Ordine con **gestionale chiuso** → arrivano push ed email entro un minuto.
2. Ordine con gestionale **aperto** → suono + badge rosso "Nuovi".
3. ACCETTA con **+30** → sul telefono del cliente compare "ACCETTATO, orario confermato … (+30 min)" entro 5 secondi, **senza** popup.
4. Passa a IN PREPARAZIONE → PRONTO → IN CONSEGNA → CONSEGNATO: il cliente vede ogni stato.
5. RIFIUTA con motivo → il cliente vede "RIFIUTATO / ANNULLATO" e il motivo.
6. Due tablet premono ACCETTA sullo stesso ordine → il secondo riceve "già modificato da un altro dispositivo".
7. Ordine da un secondo telefono mentre il primo è in corso → entrambi visibili, ognuno vede solo i propri.
8. Cliente chiude il browser e riapre "Ordini" → lo stato è ancora lì.
9. Nessuno accetta per 3 minuti → arriva l'avviso di escalation (e la chiamata, se attiva).
10. Prova a ordinare **lunedì a pranzo** o con orario passato → il sito non lo permette; se forzato, il server risponde "chiusa".
11. Pranzo mar–ven ore 12:30: la classica costa **7 € con lattina** scelta dal cliente; alle 19:30 lun–gio costa **6 €**; venerdì sera con 41 € di spesa compaiono **2 × 1 litro** in omaggio; a 60 € compare il **fritto mix**; con 25 € di altri articoli i dolci sono a **metà**.
12. Impostazioni → capacità = 1 → il secondo ordine nella stessa fascia di 15 minuti viene rifiutato e la fascia appare "piena" sul sito.
13. Cambia data/ora nel carrello dopo aver scritto nome e indirizzo → i dati restano.
14. Statistiche: oggi / settimana / mese e più venduti (solo proprietario).
15. Stampa (🖨️) di uno scontrino dal gestionale.
16. Stampante: ordine di prova → comanda entro un minuto; tasto 📠 → ristampa con "*** RISTAMPA ***".
17. Tessera: completa un ordine con 10+ prodotti → in "Clienti" compare € 5 di credito; dal telefono del cliente, nuovo ordine → nel carrello "Usa ora" toglie 5 €. Annulla quell'ordine → il credito torna.

## 6b) Tessera fedeltà automatica (10 prodotti = € 5)

- Identità = **numero di telefono** del cliente (normalizzato: +39, 0039 e spazi non contano).
- Ogni prodotto di un ordine **COMPLETATO** vale 1 timbro (gli omaggi no). Al 10° timbro il cliente riceve **€ 5 di credito**; al 20° altri 5, e così via.
- Nel carrello, se ha credito, il cliente vede "Hai € 5 di credito fedeltà → Usa ora": il totale scende di 5 (uno sconto per ordine). Gli omaggi (1 litro, fritto mix) si calcolano su quello che paga davvero.
- Se un ordine con credito usato viene **annullato**, il credito torna disponibile da solo.
- Il cliente vede i suoi timbri nella pagina "Tessera Fedeltà" e nel carrello ("con questo ordine accumuli N timbri"); lo staff li vede in **Clienti** (timbri e credito per ogni telefono). Il sito lo pubblicizza in Home, in Offerte e nel carrello.
- Per cambiare la regola (es. 8 prodotti o € 6): `LOYALTY` in `shared/pricing.js`.
- Limite: i timbri contano solo gli ordini fatti dal sito, non quelli al telefono o al banco.

## 7) Come cambiare prezzi, orari e promozioni

Tutto in `shared/pricing.js` (in cima al file: `MENU`, `HOURS`, `PROMO`, `MIN_LEAD_MINUTES` = anticipo minimo, oggi 20 minuti). Dopo la modifica: `node scripts/build-index.mjs` rigenera `index.html`, poi deploy. Server e sito usano sempre gli stessi numeri: il prezzo lo decide il server, il sito non può "imbrogliare".

## 8) Limiti noti (da sapere, non nascosti)

- **WhatsApp automatico**: non incluso. Il numero 035 è già su WhatsApp normale e non può essere usato dall'API Meta; servirebbe un secondo numero. Le notifiche arrivano via push + email (+ telefonata opzionale). Nelle card c'è il tasto 💬 per scrivere al cliente a mano.
- **Account staff**: si creano nella variabile `ACCOUNTS` su Netlify, non da un'interfaccia. Chi accetta un ordine viene registrato col proprio nome.
- **Push su iPhone/iPad**: solo se il gestionale è aggiunto alla schermata Home (limite di Apple).
- **Push**: implementate senza librerie esterne, verificate con test di cifratura/decifratura; la prima prova su un tablet vero va comunque fatta (Impostazioni → prova).
- **Escalation**: gira ogni 2 minuti (dalle 10 all'1 di notte ora italiana) su Netlify. Non gira sui deploy di anteprima.
- Email, push e chiamate sono state verificate con servizi simulati: la prima prova reale va fatta dopo il deploy (capitolo 6, punti 1 e 9).

## 9) Cose che mi servono ancora da voi

- **Lista bibite con prezzi** (lattine, bottiglie, birre, acqua): oggi nel menu non c'è una categoria bibite; ci sono solo le lattine e il litro delle promozioni.
- **Panino kebab**: manca il prezzo, non è a listino.
- **Nomi definitivi dello staff** per la variabile `ACCOUNTS` (uno per persona, così ogni ordine accettato ha il nome giusto).

## 9b) Se in pizzeria nessuno è "tecnico"

- Tutto il lavoro tecnico (Supabase, Netlify, variabili, Telegram) si fa da qualsiasi computer con internet: NON serve essere in pizzeria.
- In pizzeria servono solo due tocchi sul tablet: aprire `pizzeriavicolo.it/admin/`, login, **ATTIVA PUSH** e **SUONO**. Il login resta valido 30 giorni.
- Il modo più comodo: preparare un tablet già configurato (login, push, suono, ntfy con "notifiche insistenti", Telegram) e portarlo/spedirlo in pizzeria: chi lo riceve deve solo attaccarlo alla corrente e tenerlo acceso.
- Sul telefono del socio, il minimo senza installare nulla: aprire il gestionale, "Aggiungi a schermata Home", **ATTIVA PUSH**; le email arrivano su Gmail. Telegram e ntfy sono extra per l'allarme forte.

## 10) Quanto costa tenerlo acceso

Tutto gratis con i piani base, per i volumi di una pizzeria:

| Servizio | Piano gratuito | Basta? |
|---|---|---|
| Netlify (sito + funzioni) | **125.000 chiamate al server al mese** | ✅ Sì, con gli intervalli impostati: stampante ogni 60 s (~43.000), controllo ordini non accettati ogni 2 minuti (~13.500), tablet ogni 60 s + push immediate (~15.000 per tablet), sito cliente ogni 15 s solo con pagina aperta (~15.000). Totale ~90.000–110.000. Se il sito viene sospeso per superamento, Netlify Pro (~€18/mese) toglie il problema. |
| Supabase (database) | 500 MB; si mette in pausa solo dopo 7 giorni SENZA nessuna richiesta | ✅ Sì: il controllo ogni minuto lo tiene sempre attivo. Manca solo il backup automatico: una volta al mese scarica gli ordini da Supabase (Table editor → Export CSV) |
| Resend (email) | 3.000 email/mese, max 100 al giorno | ✅ Sì se `NOTIFY_EMAILS` ha 1–2 indirizzi (ogni indirizzo conta come una email) |
| Web Push (notifiche tablet) | illimitate | ✅ Sì |
| Telegram | illimitato | ✅ Sì |
| ntfy (allarme forte) | gratis sul server pubblico ntfy.sh (limiti ampi, centinaia di avvisi al giorno) | ✅ Sì |
| Twilio (telefonata) | a pagamento (~€1/mese numero + centesimi a chiamata) | ❌ Non necessario con Telegram |
| Pagamento online con carta | commissioni per ordine (Stripe/Satispay ~€0,60 su €25) | ❌ Non incluso: si paga alla consegna in contanti o POS, come oggi |

**Costo mensile con questa configurazione: € 0.**

## 11) App Android (APK) da mandare allo staff

Il gestionale è già installabile dal browser ("Installa app"). Se preferisci mandare un **file APK** su WhatsApp:
1. Vai su **pwabuilder.com** dal computer, incolla `https://pizzeriavicolo.it/admin/` e premi Start.
2. Scegli **Android** → Generate package. Lascia le impostazioni predefinite e scarica lo zip.
3. Dentro c'è il file `.apk` (da mandare allo staff) e un file `assetlinks.json`.
4. Metti `assetlinks.json` nella cartella `.well-known/` del sito (creala accanto a `index.html`) e ricarica il sito su Netlify: serve perché l'app si apra senza la barra dell'indirizzo.
5. Chi riceve l'APK deve consentire, una volta sola, l'installazione da "origini sconosciute".

Nota: l'APK è solo un involucro attorno al sito. Se cambi il sito, l'app si aggiorna da sola; non serve rimandare l'APK.

## 12) Consumo: come non far sospendere il sito

A settembre 2026 il sito è stato sospeso da Netlify per crediti esauriti. Cause e rimedi applicati:

| Problema | Prima | Adesso |
|---|---|---|
| Foto dentro la pagina | 4,9 MB a ogni visita | immagini separate in `/img`, home 756 KB, e il browser le tiene in memoria per un anno |
| Foto tacos in PNG | 2,2 MB | 90 KB in JPEG |
| Controllo ordini non accettati | ogni 2 minuti, tutto il giorno | ogni 3 minuti, solo 11–23 |
| Tablet | ogni 60 s | ogni 120 s con le push attive |
| Stampante | 60 s | 90 s consigliati |

Regole per il futuro:
- **Mai** incorporare immagini dentro `index.html`: vanno in `/img` e compresse (max 900 px, qualità ~70).
- Se aggiungi foto nuove: `convert foto.jpg -strip -resize '900x900>' -quality 72 img/nome.jpg`.
- Controlla ogni tanto Netlify → Billing: se superi il 70% a metà mese, avvisami.
- Se il sito cresce molto, valuta **Cloudflare Pages** (traffico illimitato, gratis).
