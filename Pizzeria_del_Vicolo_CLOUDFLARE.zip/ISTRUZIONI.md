# Pizzeria del Vicolo — uso del gestionale Cloudflare

## Link unico per proprietario e staff
`https://pizzeriavicolo.it/admin/`

Lo stesso link apre il gestionale su telefono, tablet o computer.

## Proprietario
Dopo il login OWNER:
- vede tutti gli ordini;
- accetta l'ordine e conferma l'orario;
- cambia gli stati;
- vede statistiche e clienti;
- crea/sospende/elimina gli account dello staff;
- cambia i PIN;
- controlla push/email e il registro notifiche;
- imposta la capacità massima per fascia da 15 minuti;
- può condividere ogni comanda come immagine PNG.

## Staff
Dopo il login STAFF:
- vede gli ordini;
- accetta e aggiorna gli stati;
- apre telefono/WhatsApp del cliente;
- stampa o condivide la comanda;
- non può gestire account o statistiche proprietario.

## Installazione app
Android/Chrome:
1. Aprire `https://pizzeriavicolo.it/admin/`.
2. Fare login.
3. Premere `INSTALLA APP SUL TELEFONO` quando compare, oppure menu Chrome → Aggiungi/Installa app.
4. In `ALTRO` premere `ATTIVA PUSH QUI` su ogni telefono/tablet che deve ricevere gli ordini.

iPhone/iPad:
1. Aprire il link in Safari.
2. Condividi → Aggiungi alla schermata Home.
3. Aprire l'app dalla Home e consentire le notifiche quando disponibili.

## Controllo prima del servizio
OWNER → `ALTRO` → `Controllo sistema`.
Devono risultare OK:
- Database
- Login/account
- Email ordini
- Push
- Promemoria

Poi premere `PROVA EMAIL` e `PROVA PUSH`.

## Comanda come immagine
Aprire un ordine → menu `⋯` → `Condividi comanda (foto)`.
Il telefono crea il PNG e apre il menu di condivisione (WhatsApp, Gmail, ecc.).

## Se arriva un ordine nuovo
1. Push e email partono subito.
2. Nell'app suona se il suono è stato attivato.
3. Se nessuno accetta, parte il promemoria automatico dopo circa 3 minuti e poi continua a intervalli.
4. Appena l'ordine viene accettato o annullato, i reminder per quell'ordine si fermano.

## Non modificare
Non servono più Route manuali o DNS Netlify. I domini sono Custom Domain Cloudflare.
Se la rete mobile dà `ERR_QUIC_PROTOCOL_ERROR`, lascia HTTP/3 disattivato e HTTP/2 attivo.
