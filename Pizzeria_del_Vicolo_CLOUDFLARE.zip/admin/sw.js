/* Service worker del gestionale: riceve le notifiche push (anche a gestionale chiuso) e apre /admin/ al tocco. */
const CACHE = "vicolo-admin-v2";
self.addEventListener("install", e => { self.skipWaiting(); e.waitUntil(caches.open(CACHE).then(c => c.addAll(["/admin/", "/admin/manifest.webmanifest"]).catch(() => {}))); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.pathname.startsWith("/api/")) return; // le API non si mettono mai in cache
  if (url.pathname.startsWith("/admin/")) e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});
self.addEventListener("push", e => {
  let data = { title: "🍕 Nuovo ordine", body: "Apri il gestionale", url: "/admin/", tag: "vicolo" };
  try { data = { ...data, ...e.data.json() }; } catch (err) { if (e.data) data.body = e.data.text(); }
  e.waitUntil(Promise.all([self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => list.forEach(c => c.postMessage({ type: "refresh", tag: data.tag }))), self.registration.showNotification(data.title, {
    body: data.body, tag: data.tag, renotify: true, requireInteraction: true,
    icon: "/admin/icon-192.png", badge: "/admin/icon-192.png", vibrate: [500, 200, 500, 200, 800],
    data: { url: data.url || "/admin/" }, actions: [{ action: "open", title: "Apri il gestionale" }]
  })]));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  const target = (e.notification.data && e.notification.data.url) || "/admin/";
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
    for (const c of list) { if (c.url.includes("/admin") && "focus" in c) return c.focus(); }
    return self.clients.openWindow(target);
  }));
});
