import adminLogout from "../netlify/functions/admin-logout.mts";
import adminSettings from "../netlify/functions/admin-settings.mts";
import loyalty from "../netlify/functions/loyalty.mts";
import orders from "../netlify/functions/orders.mts";
import printFn from "../netlify/functions/print.mts";
import adminLogin from "../netlify/functions/admin-login.mts";
import adminPush from "../netlify/functions/admin-push.mts";
import adminReprint from "../netlify/functions/admin-reprint.mts";
import escalation from "../netlify/functions/escalation.mts";
import adminStats from "../netlify/functions/admin-stats.mts";
import adminNotifications from "../netlify/functions/admin-notifications.mts";
import adminOrders from "../netlify/functions/admin-orders.mts";
import slots from "../netlify/functions/slots.mts";
import printEpson from "../netlify/functions/print-epson.mts";
import adminUsers from "../netlify/functions/admin-users.mts";
import adminOrderStatus from "../netlify/functions/admin-order-status.mts";
import adminCustomers from "../netlify/functions/admin-customers.mts";
import orderStatus from "../netlify/functions/order-status.mts";
import adminMe from "../netlify/functions/admin-me.mts";
import adminHealth from "../netlify/functions/admin-health.mts";

type Env = Record<string, string> & { ASSETS: { fetch(req: Request): Promise<Response> } };
function installEnv(env: Env) {
  // Cloudflare binding names are case-sensitive. During the migration some keys
  // were entered manually on mobile, so accept case-only variations as a safety net.
  const names = Object.keys(env);
  const byUpper = new Map(names.map(k => [k.toUpperCase(), k]));
  (globalThis as any).Netlify = { env: { get: (key: string) => {
    const exact = (env as any)[key];
    if (typeof exact === "string") return exact;
    const actual = byUpper.get(String(key).toUpperCase());
    const value = actual ? (env as any)[actual] : undefined;
    return typeof value === "string" ? value : undefined;
  } } };
}
const exact: Record<string, (r: Request) => Promise<Response>> = {
  "/api/admin/logout": adminLogout, "/api/admin/settings": adminSettings,
  "/api/loyalty": loyalty, "/api/orders": orders, "/api/admin/login": adminLogin,
  "/api/admin/push": adminPush, "/api/admin/reprint": adminReprint,
  "/api/admin/stats": adminStats, "/api/admin/notifications": adminNotifications,
  "/api/admin/orders": adminOrders, "/api/slots": slots, "/api/admin/users": adminUsers,
  "/api/admin/order-status": adminOrderStatus, "/api/admin/customers": adminCustomers,
  "/api/order-status": orderStatus, "/api/admin/me": adminMe, "/api/admin/health": adminHealth,
};
export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    installEnv(env);
    const p = new URL(req.url).pathname;
    if (exact[p]) return exact[p](req);
    if (p.startsWith("/api/print-epson/")) return printEpson(req, {} as any);
    if (p.startsWith("/api/print/")) return printFn(req, {} as any);
    if (p.startsWith("/api/")) return Response.json({ error: "API non trovata" }, { status: 404 });
    return env.ASSETS.fetch(req);
  },
  async scheduled(_controller: ScheduledController, env: Env): Promise<void> {
    installEnv(env); await escalation();
  }
};
