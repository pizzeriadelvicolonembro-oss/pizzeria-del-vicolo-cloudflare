/* ============ SITO CLIENTE — logica ============
   Prezzi, orari e promozioni arrivano da shared/pricing.js (VicoloPricing), lo stesso file usato dal server. */
const P = window.VicoloPricing;
const MENU = P.MENU;
const PHOTOS = { pizze:[IMG.pizza1, IMG.pizza2, IMG.pizza3], kebab:[IMG.kebab1, IMG.kebab2], burger:[IMG.burger1], tacos:[HERO_FRENCH_TACOS, IMG.tacos1], piadine:[IMG.piadine1], fritti:[IMG.fritti1], dolci:[IMG.dolci1] };
MENU.forEach(c => { c.photos = PHOTOS[c.id] || []; });
const ICONS = { pizze:"🍕", kebab:"🌯", burger:"🍔", tacos:"🌮", piadine:"🫓", fritti:"🍟", dolci:"🍫" };
MENU.forEach(c => { c.icon = ICONS[c.id] || c.icon || "🍽️"; });

const LOYALTY_AD = `Ogni ${P.LOYALTY.goal} prodotti ordinati dal sito, ${P.eur(P.LOYALTY.credit)} di sconto sull'ordine dopo. Automatica: conta il tuo numero di telefono, niente tessera di carta. Lo sconto si usa un ordine alla volta: dopo averlo usato, i timbri ripartono da zero.`;
const OFFERS = [
  { t:"🎁 Tessera Fedeltà", d:LOYALTY_AD, p:`${P.LOYALTY.goal} prodotti = ${P.eur(P.LOYALTY.credit)}` },
  { t:"Offerta Mezzogiorno", d:"Martedì–Venerdì a pranzo (11:00–14:00): pizza classica oppure piadina, con lattina 33cl inclusa. Si applica da sola scegliendo l'orario.", p:P.eur(P.PROMO.lunch7.price) },
  { t:"Lunedì–Giovedì sera", d:"Tutte le pizze classiche a € 6,00. Automatico.", p:"€ 6,00" },
  { t:"Weekend: 1 litro in omaggio", d:`Venerdì, sabato e domenica: con almeno € ${P.PROMO.weekendGift.min} di spesa 1 Coca-Cola o Pepsi da 1 litro in omaggio; sopra € ${P.PROMO.weekendGift.second} ne regaliamo 2.`, p:"Omaggio" },
  { t:"Dolci a metà prezzo", d:`Con un ordine da almeno € ${P.PROMO.dolciHalf.min}, tutti i dolci a -50%.`, p:"-50%" },
  { t:"Ordine da € 60: fritto mix in omaggio", d:"Con un ordine di almeno € 60 ti regaliamo il Fritto Mix da 12 pezzi.", p:"Omaggio" },
  { t:"Consegna a domicilio gratuita", d:"Sempre. Pagamento con POS anche a domicilio.", p:"€ 0,00" }
];
const STATUS_TEXT = { NUOVO:"INVIATO — in attesa di conferma", ACCETTATO:"ACCETTATO", IN_PREPARAZIONE:"IN PREPARAZIONE", PRONTO:"PRONTO", IN_CONSEGNA:"IN CONSEGNA", COMPLETATO:"COMPLETATO", ANNULLATO:"RIFIUTATO / ANNULLATO" };
const STATUS_ICON = { NUOVO:"📨", ACCETTATO:"✅", IN_PREPARAZIONE:"👨‍🍳", PRONTO:"🛍️", IN_CONSEGNA:"🛵", COMPLETATO:"🎉", ANNULLATO:"❌" };
const CLOSED = ["COMPLETATO", "ANNULLATO"];
const WA_NUMBER = "390350346406"; /* WhatsApp della pizzeria */
function waLink(o) { const t = (o.ticket || "").trim() || `Ordine ${o.orderNumber}`; return `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(t + "\n\n— inviato dal sito pizzeriavicolo.it")}`; }

/* ============ UTILITÀ ============ */
const eur = P.eur;
const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
const $ = id => document.getElementById(id);
function store(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {} }
function load(key, def) { try { const v = JSON.parse(localStorage.getItem(key) || "null"); return v === null ? def : v; } catch (e) { return def; } }
function fmtRome(iso, withDay) {
  if (!iso) return "—";
  try { return new Intl.DateTimeFormat("it-IT", { timeZone:"Europe/Rome", ...(withDay ? { weekday:"short", day:"2-digit", month:"2-digit" } : {}), hour:"2-digit", minute:"2-digit" }).format(new Date(iso)); } catch (e) { return ""; }
}
function dayLabel(dateStr) {
  const today = P.romeParts(new Date()).dateStr;
  const [y, m, d] = dateStr.split("-");
  const names = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
  if (dateStr === today) return "Oggi";
  const tomorrow = P.nextDates(new Date(), 2)[1]; if (dateStr === tomorrow) return "Domani";
  return `${names[P.weekdayOf(dateStr)]} ${d}/${m}`;
}
let toastT;
function toast(msg) { const t = $("toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 1600); }

/* ============ STATO ============ */
/* carrello: chiave → { baseKey, qty, addons:[], note } */
const cart = {};
(function migrateCart() {
  const old = load("dv_cart", {});
  Object.entries(old).forEach(([k, v]) => {
    if (!v || !v.qty) return;
    const baseKey = v.baseKey || (P.findItem(k) ? k : null); if (!baseKey || !P.findItem(baseKey)) return;
    cart[k] = { baseKey, qty:Number(v.qty) || 1, addons:Array.isArray(v.addons) ? v.addons : [], note:v.note || "" };
  });
})();
function saveCart() { store("dv_cart", cart); }
const form = Object.assign({ delivery:"consegna", name:"", phone:"", email:"", addr:"", pag:"Contanti", note:"", date:"", time:"", cans:[], weekendGift:"Coca-Cola 1L", useLoyalty:false }, load("dv_form", {}));
function saveForm() { store("dv_form", form); }
let orders = load("dv_orders", []);
(function migrateOrders() {
  const single = load("dv_active_order", null);
  if (single && single.orderNumber && !orders.some(o => o.orderNumber === single.orderNumber)) { orders.unshift({ orderNumber:single.orderNumber, key:single.key, status:single.status || "NUOVO", requested_at:single.requested_at, created_at:new Date().toISOString() }); store("dv_orders", orders); }
  try { localStorage.removeItem("dv_active_order"); } catch (e) {}
})();
function saveOrders() { store("dv_orders", orders.slice(0, 30)); }
/* tessera fedeltà: stato letto dal server (serve un proprio ordine come prova) */
let loyalty = load("dv_loyalty", null), loyaltyPhone = "", loyaltyBusy = false, manualPhone = ""; /* manualPhone resta solo in memoria: non si salva sul telefono */
function proofOrder(phone) { const ph = normPhone(phone); return orders.find(o => o.key && o.orderNumber && normPhone(o.phone) === ph) || (orders.find(o => o.key && o.orderNumber && !o.phone) || null); }
function normPhone(p) { let d = String(p || "").replace(/\D/g, ""); if (d.startsWith("0039")) d = d.slice(4); else if (d.startsWith("39") && d.length >= 12) d = d.slice(2); return d; }
async function refreshLoyalty(force) {
  const ph = normPhone(form.phone || manualPhone); if (ph.length < 8) { loyalty = null; return; }
  if (!force && loyalty && loyaltyPhone === ph) return;
  const proof = proofOrder(ph); if (!proof) { loyalty = null; loyaltyPhone = ph; store("dv_loyalty", null); return; }
  if (loyaltyBusy) return; loyaltyBusy = true;
  try { const r = await fetch(`/api/loyalty?phone=${encodeURIComponent(ph)}&order=${encodeURIComponent(proof.orderNumber)}&key=${encodeURIComponent(proof.key)}`, { cache:"no-store" }); loyalty = r.ok ? await r.json() : null; }
  catch (e) { loyalty = null; }
  loyaltyPhone = ph; store("dv_loyalty", loyalty); loyaltyBusy = false;
  if (!loyalty || !loyalty.canUse) form.useLoyalty = false;
  /* si può ridisegnare: render() rimette il cursore dov'era, il testo non si perde */
  if (["#carrello", "#fedelta"].includes(location.hash)) render();
}
function loyaltyCents() { return form.useLoyalty && loyalty && loyalty.canUse ? loyalty.rewardCents : 0; }

/* ============ CARRELLO ============ */
function cartItems() { return Object.entries(cart).map(([key, i]) => ({ key, baseKey:i.baseKey, qty:i.qty, addons:i.addons, note:i.note })); }
function cartCount() { return Object.values(cart).reduce((s, i) => s + i.qty, 0); }
function updateCount() { const n = cartCount(), el = $("cartCount"); el.textContent = n; el.style.display = n ? "flex" : "none"; }
function addToCart(baseKey, addons, note) {
  const it = P.findItem(baseKey); if (!it) return;
  addons = addons || []; note = (note || "").trim();
  const key = addons.length || note ? "custom:" + baseKey + "~" + addons.join("|") + "~" + note : baseKey;
  cart[key] = cart[key] || { baseKey, qty:0, addons, note };
  cart[key].qty++;
  saveCart(); updateCount(); toast("Aggiunto: " + it.name);
  if (location.hash === "#carrello") render();
}
function changeQty(key, d) { if (!cart[key]) return; cart[key].qty += d; if (cart[key].qty <= 0) delete cart[key]; saveCart(); updateCount(); render(); }

/* orario selezionato → "momento" per le promozioni (ora di Roma) */
let slotCache = {}; // dateStr → [{t, full}]
function ensureDateTime() {
  const dates = P.nextDates(new Date(), P.MAX_DAYS_AHEAD);
  if (!dates.includes(form.date)) form.date = "";
  if (!form.date) { for (const d of dates) { if (P.slotsFor(d).length) { form.date = d; break; } } }
  const slots = slotCache[form.date] || P.slotsFor(form.date).map(t => ({ t, full:false }));
  if (!slots.some(s => s.t === form.time && !s.full)) form.time = (slots.find(s => !s.full) || {}).t || "";
  return { dates, slots };
}
function currentMoment() {
  const { dates } = ensureDateTime(); const time = form.time || "19:30";
  const [hh, mm] = time.split(":").map(Number);
  return { weekday:P.weekdayOf(form.date || dates[0]), mins:hh * 60 + mm };
}
function computeCart() { return P.priceOrder(cartItems(), currentMoment(), { cans:form.cans, weekendGift:form.weekendGift, loyaltyCents:loyaltyCents() }); }
async function loadSlots(dateStr) {
  try { const r = await fetch("/api/slots?date=" + dateStr, { cache:"no-store" }); if (!r.ok) throw 0; const d = await r.json(); slotCache[dateStr] = d.slots; }
  catch (e) { slotCache[dateStr] = P.slotsFor(dateStr).map(t => ({ t, full:false })); }
  if (location.hash === "#carrello") render();
}

/* ============ PERSONALIZZAZIONE ============ */
let customBaseKey = null;
function openCustomizer(baseKey) {
  const it = P.findItem(baseKey); if (!it) return; customBaseKey = baseKey;
  $("customName").textContent = it.name; $("customDesc").textContent = it.desc || ""; $("customBase").textContent = eur(it.price);
  let html = "";
  if (it.catId === "pizze") {
    ["dough", "size"].forEach(g => { P.PIZZA_OPTIONS.filter(o => o.group === g).forEach(o => { html += `<div class="addon"><label><input type="radio" name="opt-${g}" data-opt="${esc(o.name)}" ${o.default ? "checked" : ""}> <span>${esc(o.name)}</span></label><b>${o.price === 0 ? "Incluso" : (o.price > 0 ? "+" : "−") + eur(Math.abs(o.price))}</b></div>`; }); });
  }
  html += `<button type="button" class="addons-toggle" id="addonsToggle" aria-expanded="false">➕ Aggiunte (facoltative) <span>▼</span></button><div class="addons-collapsible" id="addonsCollapsible">`;
  html += P.addonsFor(it.catId).map(a => `<div class="addon"><label><input type="checkbox" data-addon="${esc(a[0])}"> <span>${esc(a[0])}</span></label><b>${a[1] === 0 ? "Gratis" : "+" + eur(a[1])}</b></div>`).join("") + "</div>";
  $("customAddons").innerHTML = html; $("customNote").value = ""; $("customOverlay").classList.add("on"); updateCustomTotal();
}
function chosenAddons() { const out = []; document.querySelectorAll("#customAddons input[data-opt]:checked").forEach(el => { const o = P.PIZZA_OPTIONS.find(x => x.name === el.dataset.opt); if (o && !o.default) out.push(o.name); }); document.querySelectorAll("#customAddons input[data-addon]:checked").forEach(el => out.push(el.dataset.addon)); return out; }
function updateCustomTotal() { if (!customBaseKey) return; const it = P.findItem(customBaseKey); let x = it.price; chosenAddons().forEach(n => { x += P.addonPrice(it.catId, n) || 0; }); $("customTotal").textContent = eur(x); }
function closeCustomizer() { $("customOverlay").classList.remove("on"); customBaseKey = null; }
function addCustomized() { if (!customBaseKey) return; addToCart(customBaseKey, chosenAddons(), $("customNote").value); closeCustomizer(); }

/* ============ COMPONENTI ============ */
function slider(imgs, cls) {
  if (!imgs || !imgs.length) return "";
  /* solo la prima foto viene caricata subito: le altre quando servono */
  const dots = imgs.length > 1 ? `<div class="dots">${imgs.map((_, i) => `<span class="${i === 0 ? "on" : ""}"></span>`).join("")}</div>` : "";
  const arrows = imgs.length > 1 ? `<button class="arrow l" data-dir="-1" aria-label="Precedente">‹</button><button class="arrow r" data-dir="1" aria-label="Successiva">›</button>` : "";
  return `<div class="slider ${cls || ""}" data-slider><div class="slides">${imgs.map((s, i) => `<img src="${s}" alt="" loading="${i ? "lazy" : "eager"}" fetchpriority="${i ? "low" : "high"}" decoding="async">`).join("")}</div>${dots}${arrows}</div>`;
}
function tile(cat) {
  const photo = cat.photos[0];
  return `<a class="tile ${photo ? "" : "plain"}" href="#cat/${cat.id}">${photo ? `<img src="${photo}" alt="" loading="lazy" decoding="async">` : `<span class="ico">${cat.icon}</span>`}<div class="lbl"><span>${cat.icon} ${esc(cat.name)}</span>${cat.badge ? `<span class="badge">${esc(cat.badge)}</span>` : ""}</div></a>`;
}
function itemRow(cat, gi, ii, it) {
  const key = `${cat.id}:${gi}:${ii}`, custom = P.CUSTOMIZABLE.includes(cat.id);
  const hint = cat.id === "dolci" ? `<div class="half">-50% con ordine da € ${P.PROMO.dolciHalf.min}</div>` : (cat.id === "pizze" && gi === 0 ? `<div class="half y">€6 lun–gio sera · €7 pranzo con lattina</div>` : (cat.id === "piadine" ? `<div class="half y">€7 a pranzo mar–ven, lattina inclusa</div>` : ""));
  return `<div class="item ${custom ? "" : "no-custom"}" ${custom ? `data-customize="${key}"` : ""}><div class="txt"><div class="nm">${esc(it[0])}</div>${it[1] ? `<div class="ds">${esc(it[1])}</div>` : ""}</div><div class="pr">${eur(it[2])}${hint}</div><button class="add" ${custom ? `data-customize="${key}"` : `data-add="${key}"`} aria-label="Aggiungi ${esc(it[0])}">+</button></div>`;
}
function orderCard(o, compact) {
  const st = o.status || "NUOVO"; const closed = CLOSED.includes(st);
  const when = o.confirmed_at ? `Orario confermato dalla pizzeria: <b>${fmtRome(o.confirmed_at, true)}</b>${o.delay_minutes ? ` (+${o.delay_minutes} min)` : ""}` : `Orario richiesto: <b>${fmtRome(o.requested_at, true)}</b> · in attesa di conferma`;
  return `<div class="order-status ${closed ? "closed" : ""} st-${st}">
    <div class="os-head"><h3>Ordine ${esc(o.orderNumber)}</h3><span class="os-tot">${o.total_cents != null ? eur(o.total_cents / 100) : ""}</span></div>
    <div class="big">${STATUS_ICON[st] || ""} ${esc(STATUS_TEXT[st] || st)}</div>
    ${st === "ANNULLATO" && o.cancellation_reason ? `<small>Motivo: ${esc(o.cancellation_reason)}</small>` : ""}
    ${o.loyalty_credit_used_cents ? `<small>🎁 Credito fedeltà usato: −${eur(o.loyalty_credit_used_cents / 100)}${st === "ANNULLATO" ? " (restituito)" : ""}</small>` : ""}${st === "COMPLETATO" && o.loyalty_units ? `<small>🎁 +${o.loyalty_units} timbri fedeltà</small>` : ""}
    ${compact ? "" : `<small>${when}</small><small>${o.fulfillment_type === "DELIVERY" ? "🛵 Consegna a domicilio" : "🛍️ Ritiro in negozio"} · inviato ${fmtRome(o.created_at, true)}</small>`}
    ${!compact && o.ticket ? `<div class="share-row"><button class="btn o" data-share="${esc(o.orderNumber)}">📤 Condividi ordine</button>${st === "NUOVO" ? `<a class="btn wa" href="${waLink(o)}" target="_blank" rel="noopener">📲 WhatsApp alla pizzeria</a>` : ""}</div>` : ""}
    ${st === "NUOVO" && !compact ? `<div class="wait-note">⏳ La pizzeria conferma di solito <b>entro 15 minuti</b>. Se non ricevi la conferma, chiama lo <a href="tel:0350346406">035 034 6406</a>.</div>` : ""}
    ${closed || compact ? "" : `<small class="live">● Si aggiorna da solo ogni 15 secondi, puoi chiudere e riaprire questa pagina.</small>`}
  </div>`;
}

/* ============ PAGINE ============ */
const pages = {
  home() {
    return `<div style="height:12px"></div>${slider([IMG.promo1, IMG.promo2, IMG.promo3, IMG.promo4], "banner")}
      <div class="hero-cta"><a class="btn y" href="#menu">📖 Visualizza Menu</a><a class="btn r" href="#offerte">🔥 Le Offerte</a></div>
      <div class="facts"><div>🛵 Consegna <b>gratuita</b></div><div>☀️ Pranzo mar–ven: classica o piadina + lattina <b>€ 7</b></div><div>🌙 Lun–gio sera: classiche <b>€ 6</b></div><div>🎁 Ven–dom: <b>1L omaggio</b> da € 20</div><div>🍫 Dolci <b>-50%</b> da € 25</div><div>🍟 Da € 60: <b>fritto mix</b> omaggio</div><div>🎁 Tessera: <b>10 prodotti = € 5</b></div><div>💳 POS anche a domicilio</div></div>
      ${orders.some(o => !CLOSED.includes(o.status)) ? `<a class="btn o block" href="#ordini" style="margin-top:10px">📦 Segui il tuo ordine in corso</a>` : ""}
      <h2 class="sec">Scegli cosa ordinare</h2><div class="tiles">${MENU.map(tile).join("")}</div>
      <a class="loyalty-ad" href="#fedelta"><span class="big">🎁</span><div><b>TESSERA FEDELTÀ AUTOMATICA</b><span>${esc(LOYALTY_AD)}</span></div><span class="arr">›</span></a>
      <h2 class="sec">Gustare per credere</h2><div class="info"><p>Pomodori pelati e mozzarella fior di latte italiani, bufala Campana DOP, farina con germe di grano. Impasto integrale e mozzarella senza lattosio disponibili.</p></div>
      <a class="btn o block" href="#contatti">📍 Dove siamo · Orari</a><div style="height:10px"></div><a class="btn o block" href="#fedelta">🎁 Tessera Fedeltà</a>`;
  },
  menu() {
    return `<a class="back" href="#home">‹ Home</a><h1 class="title">Menu</h1><p class="note">Tocca una categoria per aprirla.</p>
      <div class="tiles">${MENU.map(tile).join("")}<a class="tile plain wide" href="#offerte"><span class="ico">🔥</span><div class="lbl"><span>Offerte del momento</span></div></a></div>`;
  },
  cat(id) {
    const cat = MENU.find(c => c.id === id); if (!cat) return pages.menu();
    const multi = cat.groups.length > 1;
    return `<a class="back" href="#menu">‹ Menu</a><h1 class="title">${cat.icon} ${esc(cat.name)}${cat.badge ? `<span class="badge">${esc(cat.badge)}</span>` : ""}</h1>
      ${slider(cat.photos, "categoryHero")}${cat.note ? `<p class="note">${esc(cat.note)}</p>` : ""}
      ${multi ? `<div class="chips">${cat.groups.map((g, i) => `<button class="chip ${i === 0 ? "on" : ""}" data-group="${i}">${esc(g.name)}</button>`).join("")}</div>` : ""}
      ${cat.groups.map((g, gi) => `<div class="group ${gi === 0 ? "on" : ""}" data-gi="${gi}">${multi && g.name ? `<div class="gname">${esc(g.name)}</div>` : ""}${g.note ? `<p class="note">${esc(g.note)}</p>` : ""}<div class="items">${g.items.map((it, ii) => itemRow(cat, gi, ii, it)).join("")}</div></div>`).join("")}
      <div style="height:16px"></div><a class="btn y block" href="#carrello">🛒 Vai all'ordine${cartCount() ? ` (${cartCount()})` : ""}</a>`;
  },
  offerte() {
    return `<a class="back" href="#home">‹ Home</a><h1 class="title">🔥 Offerte</h1>${slider([IMG.promo1, IMG.promo2, IMG.promo3, IMG.promo4], "banner")}<div style="height:14px"></div>
      ${OFFERS.map(o => `<div class="offer"><b>${esc(o.t)}</b><span>${esc(o.d)}</span><div class="p">${esc(o.p)}</div></div>`).join("")}<a class="btn y block" href="#menu">📖 Vai al menu</a>`;
  },
  carrello() {
    if (!Object.keys(cart).length) return `<a class="back" href="#menu">‹ Menu</a><h1 class="title">🛒 Il tuo ordine</h1><div class="empty">Il carrello è vuoto.<br><br><a class="btn y" href="#menu">Apri il menu</a></div>`;
    const { dates, slots } = ensureDateTime(); if (!slotCache[form.date]) loadSlots(form.date);
    refreshLoyalty(false);
    const c = computeCart();
    return `<a class="back" href="#menu">‹ Menu</a><h1 class="title">🛒 Il tuo ordine</h1>
      <div class="items">${c.lines.map(l => { const key = l.key; return `<div class="item no-custom"><div class="txt"><div class="nm">${esc(l.name)}</div><div class="ds">${l.unit !== l.listUnit ? `<s>${eur(l.listUnit)}</s> ` : ""}${eur(l.unit)} cad.${l.tags.length ? ` · <span class="tag">${esc(l.tags.join(" · "))}</span>` : ""}${l.note ? `<br>📝 ${esc(l.note)}` : ""}</div></div><div class="qty"><button data-q="${esc(key)}" data-d="-1">−</button><span>${l.qty}</span><button data-q="${esc(key)}" data-d="1">+</button></div></div>`; }).join("")}
      ${c.lunchCans ? `<div class="gift"><span style="font-size:1.4rem">🥤</span><div style="flex:1"><div class="nm">${c.lunchCans === 1 ? "1 lattina 33cl inclusa" : c.lunchCans + " lattine 33cl incluse"} — Offerta Mezzogiorno</div><div class="ds">Scegli il gusto</div><div class="cans">${Array.from({ length:c.lunchCans }, (_, i) => `<select data-can="${i}">${P.PROMO.lunch7.cans.map(x => `<option ${form.cans[i] === x ? "selected" : ""}>${x}</option>`).join("")}</select>`).join("")}</div></div></div>` : ""}
      ${c.weekendGifts ? `<div class="gift"><span style="font-size:1.4rem">🎁</span><div style="flex:1"><div class="nm">${c.weekendGifts} × 1 litro in OMAGGIO</div><div class="ds">Promo venerdì, sabato e domenica · da € ${P.PROMO.weekendGift.min} di spesa${c.weekendGifts > 1 ? ", 2 sopra € " + P.PROMO.weekendGift.second : ""}</div><select data-wgift>${P.PROMO.weekendGift.choices.map(x => `<option ${form.weekendGift === x ? "selected" : ""}>${x}</option>`).join("")}</select></div></div>` : ""}
      ${c.bigGift ? `<div class="gift"><span style="font-size:1.4rem">🎁</span><div><div class="nm">${esc(P.PROMO.bigGift.item)} — OMAGGIO</div><div class="ds">Ordine da € ${P.PROMO.bigGift.min}</div></div></div>` : ""}
      </div>
      ${!c.bigGift && c.missingForBigGift <= 25 ? `<div class="nudge">🍟 Aggiungi ancora <b>${eur(c.missingForBigGift)}</b> e ti regaliamo il ${esc(P.PROMO.bigGift.item)}</div>` : ""}
      ${!c.dolciHalf && c.missingForDolci > 0 && c.missingForDolci <= 12 ? `<div class="nudge">🍫 Con altri <b>${eur(c.missingForDolci)}</b> di ordine i dolci sono a metà prezzo</div>` : ""}
      ${loyalty && loyalty.canUse ? `<div class="gift loyalty"><span style="font-size:1.4rem">🎁</span><div style="flex:1"><div class="nm">Hai ${eur(loyalty.creditCents / 100)} di credito fedeltà</div><div class="ds">Vuoi usarlo su questo ordine?</div></div><button class="use ${form.useLoyalty ? "on" : ""}" data-loyalty>${form.useLoyalty ? "✓ Usato" : "Usa ora"}</button></div>` : ""}
      ${loyalty && loyalty.paused && !form.useLoyalty
        ? `<div class="nudge">🎁 Hai già <b>${eur(loyalty.rewardCents / 100)}</b> di sconto pronto: usalo su questo ordine. I nuovi timbri ripartono dopo che l'hai usato.</div>`
        : `<div class="nudge">🎁 Con questo ordine accumuli <b>${c.units} timbr${c.units === 1 ? "o" : "i"}</b>${loyalty ? ` (hai ${loyalty.stamps}/${loyalty.goal}: te ne mancano ${loyalty.missing} per ${eur(loyalty.rewardCents / 100)} di sconto)` : ` · ogni ${P.LOYALTY.goal} prodotti ${eur(P.LOYALTY.credit)} di sconto`}</div>`}
      <div class="row"><span>Subtotale</span><span>${eur(c.subtotal)}</span></div>
      ${c.delta > 0 ? `<div class="row d"><span>Promozioni</span><span>− ${eur(c.delta)}</span></div>` : ""}${c.delta < 0 ? `<div class="row"><span>Offerta pranzo (lattina inclusa)</span><span>+ ${eur(-c.delta)}</span></div>` : ""}
      ${c.loyaltyDiscount > 0 ? `<div class="row d"><span>Credito tessera fedeltà</span><span>− ${eur(c.loyaltyDiscount)}</span></div>` : ""}
      <div class="total"><span>Totale</span><span>${eur(c.total)}</span></div>
      <div class="field"><label>Ritiro o consegna?</label><div class="seg"><button data-del="consegna" class="${form.delivery === "consegna" ? "on" : ""}">🛵 Consegna gratuita</button><button data-del="ritiro" class="${form.delivery === "ritiro" ? "on" : ""}">🛍️ Ritiro in negozio</button></div></div>
      <div class="field"><label>Quando?</label><div class="chips dates">${dates.map(d => P.slotsFor(d).length ? `<button class="chip ${form.date === d ? "on" : ""}" data-date="${d}">${dayLabel(d)}</button>` : "").join("")}</div>
        <div class="slots">${slots.length ? slots.map(s => `<button class="slot ${form.time === s.t ? "on" : ""} ${s.full ? "full" : ""}" data-time="${s.t}" ${s.full ? "disabled" : ""}>${s.t}${s.full ? "<i>piena</i>" : ""}</button>`).join("") : `<p class="note">Nessun orario disponibile per questo giorno.</p>`}</div>
        <p class="note">Orari di Roma. La pizzeria conferma l'orario o ti propone qualche minuto in più. Anticipo minimo ${P.MIN_LEAD_MINUTES} minuti.</p></div>
      <div class="field"><label>Nome *</label><input id="fNome" data-f="name" value="${esc(form.name)}" placeholder="Il tuo nome" autocomplete="name"></div>
      <div class="field"><label>Telefono *</label><input id="fPhone" data-f="phone" value="${esc(form.phone)}" inputmode="tel" placeholder="Il tuo cellulare" autocomplete="tel"></div>
      <div class="field"><label>Email (facoltativa)</label><input id="fEmail" data-f="email" value="${esc(form.email)}" inputmode="email" placeholder="Per ricevere conferma" autocomplete="email"></div>
      <div class="field" id="fAddrWrap" style="${form.delivery === "ritiro" ? "display:none" : ""}"><label>Indirizzo di consegna *</label><input id="fAddr" data-f="addr" value="${esc(form.addr)}" placeholder="Via, numero civico, città" autocomplete="street-address"></div>
      <div class="field"><label>Pagamento</label><select id="fPag" data-f="pag"><option ${form.pag === "Contanti" ? "selected" : ""}>Contanti</option><option ${form.pag !== "Contanti" ? "selected" : ""}>POS / Carta (anche a domicilio)</option></select></div>
      <div class="field"><label>Note (allergie, salse, citofono…)</label><textarea id="fNote" data-f="note" rows="2">${esc(form.note)}</textarea></div>
      <button class="btn y block" id="sendOrder" style="font-size:1.08rem;padding:16px 18px" ${!form.time ? "disabled" : ""}>✅ CONFERMA E INVIA ORDINE · ${eur(c.total)}</button>
      <p class="note" style="text-align:center">L'ordine non è ancora confermato: la pizzeria risponde di solito entro 15 minuti e vedi lo stato nella pagina «Ordini». Per urgenze: <a href="tel:0350346406" style="color:var(--yellow);font-weight:700">035 034 6406</a>.</p>`;
  },
  ordini() {
    const active = orders.filter(o => !CLOSED.includes(o.status)), history = orders.filter(o => CLOSED.includes(o.status));
    return `<a class="back" href="#home">‹ Home</a><h1 class="title">📦 I tuoi ordini</h1>
      ${active.length && "Notification" in window && Notification.permission !== "granted" ? `<button class="btn o block" id="askNotify" style="margin-bottom:12px">🔔 Avvisami quando la pizzeria accetta l'ordine</button>` : ""}
      ${active.length ? active.map(o => orderCard(o)).join("") : `<div class="empty">Nessun ordine in corso.<br><br><a class="btn y" href="#menu">Apri il menu</a></div>`}
      ${history.length ? `<h2 class="sec">Storico</h2>${history.map(o => orderCard(o, true)).join("")}` : ""}
      ${orders.length ? `<p class="note" style="text-align:center">Gli ordini restano su questo telefono. Per problemi chiama il <a href="tel:0350346406" style="color:var(--yellow)">035 034 6406</a>.</p>` : ""}`;
  },
  ordine() { return pages.ordini(); },
  contatti() {
    return `<a class="back" href="#home">‹ Home</a><h1 class="title">📍 Dove siamo</h1>
      <div class="info"><h3>INDIRIZZO</h3><p>Via F. Martinengo Colleoni, 92<br>Scanzorosciate (BG)</p><div style="height:10px"></div><a class="btn o block" href="https://maps.google.com/?q=Via+F.+Martinengo+Colleoni+92+Scanzorosciate">🗺️ Apri in Google Maps</a></div>
      <div class="info"><h3>ORARI</h3><ul class="hours">${P.HOURS_TEXT.map(([d, h]) => `<li><span>${d}</span><span>${h}</span></li>`).join("")}</ul></div>
      <div class="info"><h3>CONTATTI</h3><a class="btn y block" href="tel:0350346406">📞 Chiama: 035 034 6406</a></div>`;
  },
  fedelta() {
    refreshLoyalty(false);
    const stamps = loyalty ? loyalty.stamps : 0;
    return `<a class="back" href="#home">‹ Home</a><h1 class="title">🎁 Tessera Fedeltà</h1>
      <div class="info"><h3>COME FUNZIONA</h3><p>${esc(LOYALTY_AD)} Al ${P.LOYALTY.goal}° prodotto il credito compare da solo nel carrello: premi "Usa ora".</p></div>
      <div class="info"><h3>I TUOI TIMBRI</h3>
      <div class="field"><label>Il tuo numero di telefono</label><input id="fedPhone" value="${esc(form.phone || manualPhone)}" inputmode="tel" placeholder="es. 333 1234567"><p class="note">Serve solo per mostrarti i timbri: non resta salvato sul telefono.</p></div>
      <div class="stamps">${Array.from({ length:P.LOYALTY.goal }, (_, i) => `<span class="${i < stamps ? "f" : ""}"></span>`).join("")}</div>
      ${loyalty ? `<p><b>${stamps}/${loyalty.goal}</b> timbri · te ne mancano <b>${loyalty.missing}</b>${loyalty.creditCents ? ` · <b style="color:var(--green)">${eur(loyalty.creditCents / 100)} di credito pronto da usare</b>` : ""}</p><p class="note">${loyalty.rewardsTotal ? `Premi ricevuti finora: ${loyalty.rewardsTotal}. ` : ""}I timbri arrivano quando l'ordine è COMPLETATO.${loyalty.paused ? " Hai già uno sconto pronto: i timbri ripartono dopo che lo usi." : ""}</p>` : `<p class="note">${normPhone(form.phone).length >= 8 ? "Nessun ordine completato con questo numero da questo telefono: i timbri compaiono dopo il primo ordine completato." : "Inserisci il tuo telefono qui sotto: la tessera è legata al numero."}</p>`}</div>
      <a class="btn y block" href="#menu">📖 Ordina</a>`;
  }
};

/* ============ ROUTER ============ */
function route() { const h = (location.hash || "#home").slice(1); const [p, arg] = h.split("/"); if (p === "cat") return { fn:() => pages.cat(arg), nav:"menu" }; if (pages[p]) return { fn:pages[p], nav:p === "ordine" ? "ordini" : p }; return { fn:pages.home, nav:"home" }; }
function render() {
  /* Se l'utente sta scrivendo, la pagina non gli toglie il campo da sotto le dita:
     ricordiamo dov'era il cursore e glielo restituiamo dopo aver ridisegnato. */
  const ae = document.activeElement;
  const typing = ae && (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA") && ae.id && document.getElementById("app").contains(ae);
  const keep = typing ? { id: ae.id, start: ae.selectionStart, end: ae.selectionEnd, value: ae.value } : null;
  const r = route(); const app = $("app"); app.innerHTML = `<div class="page active">${r.fn()}</div>`;
  document.querySelectorAll(".bar a").forEach(a => a.classList.toggle("on", a.dataset.nav === r.nav));
  if (!keep) window.scrollTo(0, 0);
  initSliders(app);
  if (keep) {
    const el = document.getElementById(keep.id);
    if (el) {
      if (el.value !== keep.value && document.activeElement !== el) el.value = keep.value;
      try { el.focus({ preventScroll: true }); el.setSelectionRange(keep.start, keep.end); } catch (e) {}
    }
  }
  if (r.nav === "ordini") refreshOrders();
}
window.addEventListener("hashchange", render);

/* ============ EVENTI ============ */
document.addEventListener("click", e => {
  const custom = e.target.closest("[data-customize]"); if (custom) { openCustomizer(custom.dataset.customize); return; }
  const add = e.target.closest("[data-add]"); if (add) { addToCart(add.dataset.add); return; }
  const q = e.target.closest("[data-q]"); if (q) { changeQty(q.dataset.q, +q.dataset.d); return; }
  const chip = e.target.closest("[data-group]"); if (chip) { document.querySelectorAll(".chip[data-group]").forEach(c => c.classList.toggle("on", c === chip)); document.querySelectorAll(".group").forEach(g => g.classList.toggle("on", g.dataset.gi === chip.dataset.group)); return; }
  const del = e.target.closest("[data-del]"); if (del) { form.delivery = del.dataset.del; saveForm(); render(); return; }
  const dt = e.target.closest("[data-date]"); if (dt) { form.date = dt.dataset.date; form.time = ""; saveForm(); if (!slotCache[form.date]) loadSlots(form.date); render(); return; }
  const tm = e.target.closest("[data-time]"); if (tm && !tm.disabled) { form.time = tm.dataset.time; saveForm(); render(); return; }
  const tog = e.target.closest("#addonsToggle"); if (tog) { const col = $("addonsCollapsible"); const open = !col.classList.contains("open"); col.classList.toggle("open", open); tog.classList.toggle("open", open); tog.setAttribute("aria-expanded", open ? "true" : "false"); return; }
  if (e.target.closest("#customClose") || e.target.id === "customOverlay") { closeCustomizer(); return; }
  if (e.target.closest("#customConfirm")) { addCustomized(); return; }
  if (e.target.closest("#sendOrder")) { submitOrder(); return; }
  if (e.target.closest("[data-loyalty]")) { form.useLoyalty = !form.useLoyalty; saveForm(); render(); return; }
  if (e.target.closest("#askNotify")) { askNotify(); return; }
  const sh = e.target.closest("[data-share]"); if (sh) { shareOrder(sh.dataset.share); return; }
  const arrow = e.target.closest(".arrow"); if (arrow) { const s = arrow.closest("[data-slider]"); s._go(s._i + (+arrow.dataset.dir)); s._touch(); }
});
let phoneT;
document.addEventListener("input", e => {
  if (e.target.id === "fedPhone") { manualPhone = e.target.value; clearTimeout(phoneT); phoneT = setTimeout(() => refreshLoyalty(true), 600); return; }
  const f = e.target.dataset && e.target.dataset.f; if (f) { form[f] = e.target.value; saveForm(); if (f === "phone") { clearTimeout(phoneT); phoneT = setTimeout(() => refreshLoyalty(true), 600); } }
});
document.addEventListener("change", e => {
  if (e.target.matches("#customAddons input")) { updateCustomTotal(); return; }
  if (e.target.matches("[data-can]")) { form.cans[+e.target.dataset.can] = e.target.value; saveForm(); return; }
  if (e.target.matches("[data-wgift]")) { form.weekendGift = e.target.value; saveForm(); return; }
  const f = e.target.dataset && e.target.dataset.f; if (f) { form[f] = e.target.value; saveForm(); }
});

/* ============ INVIO ORDINE ============ */
let sending = false;
async function submitOrder() {
  if (sending) return;
  const btn = $("sendOrder");
  if (!form.name.trim() || form.phone.replace(/\D/g, "").length < 8) { toast("Inserisci nome e un numero di telefono valido"); return; }
  if (form.email && !form.email.includes("@")) { toast("Email non valida"); return; }
  if (form.delivery === "consegna" && form.addr.trim().length < 5) { toast("Inserisci l'indirizzo di consegna"); return; }
  ensureDateTime(); if (!form.date || !form.time) { toast("Scegli giorno e orario"); return; }
  const requested = P.romeToUTC(form.date, form.time);
  if (requested.getTime() < Date.now() + (P.MIN_LEAD_MINUTES - 5) * 60000) { toast("Quell'orario è troppo vicino: scegline un altro"); slotCache = {}; loadSlots(form.date); return; }
  const c = computeCart(); if (c.errors.length) { toast(c.errors[0]); return; }
  const idem = crypto.randomUUID ? crypto.randomUUID() : (Date.now() + "-" + Math.random().toString(36).slice(2));
  const payload = { idempotencyKey:idem, fulfillmentType:form.delivery === "consegna" ? "DELIVERY" : "PICKUP", address:form.addr.trim(), requestedAt:requested.toISOString(), items:cartItems().map(({ key, ...it }) => it), choices:{ cans:form.cans.slice(0, c.lunchCans), weekendGift:form.weekendGift }, clientTotal:c.total, useLoyalty:loyaltyCents() > 0, paymentMethod:form.pag, customer:{ name:form.name.trim(), phone:form.phone.trim(), email:form.email.trim() }, notes:form.note.trim() };
  try {
    sending = true; if (btn) { btn.disabled = true; btn.textContent = "INVIO IN CORSO…"; }
    const r = await fetch("/api/orders", { method:"POST", headers:{ "content-type":"application/json" }, body:JSON.stringify(payload) });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      if (data.slotFull) { slotCache = {}; await loadSlots(form.date); form.time = ""; }
      if (data.loyalty) { loyalty = { ...(loyalty || {}), ...data.loyalty, canUse:!!data.loyalty.canUse }; form.useLoyalty = false; store("dv_loyalty", loyalty); }
      else if (data.serverTotal != null) { setTimeout(() => location.reload(), 1500); }
      throw new Error(data.error || "Invio non riuscito");
    }
    const o = data.order || {};
    orders.unshift({ orderNumber:o.order_number, key:idem, phone:normPhone(form.phone), ticket:o.ticket_text || "", status:o.status || "NUOVO", requested_at:o.requested_at || requested.toISOString(), confirmed_at:o.confirmed_at || null, total_cents:o.total_cents, loyalty_credit_used_cents:o.loyalty_credit_used_cents || 0, fulfillment_type:o.fulfillment_type, created_at:o.created_at || new Date().toISOString() });
    saveOrders();
    if (data.loyalty) { loyalty = data.loyalty; loyaltyPhone = normPhone(form.phone); store("dv_loyalty", loyalty); }
    form.useLoyalty = false;
    Object.keys(cart).forEach(k => delete cart[k]); saveCart(); updateCount();
    /* i dati personali NON restano sul telefono: si svuotano dopo ogni ordine */
    Object.assign(form, { name:"", phone:"", email:"", addr:"", note:"", cans:[], useLoyalty:false }); saveForm();
    toast("Ordine inviato! Conferma entro ~15 min ✅");
    location.hash = "#ordini";
  } catch (e) {
    toast(String(e.message || "Ordine non inviato, riprova"));
    if (btn) { btn.disabled = false; btn.textContent = "✅ CONFERMA E INVIA ORDINE"; }
    render();
  } finally { sending = false; }
}

/* ============ STATO ORDINI (aggiornamento automatico, senza popup) ============ */
let ordersTimer = null;
async function refreshOrders() {
  const active = orders.filter(o => !CLOSED.includes(o.status) && o.orderNumber && o.key);
  clearTimeout(ordersTimer);
  if (!active.length) return;
  let changed = false;
  await Promise.all(active.map(async o => {
    try {
      const r = await fetch(`/api/order-status?order=${encodeURIComponent(o.orderNumber)}&key=${encodeURIComponent(o.key)}`, { cache:"no-store" });
      if (r.status === 404) { return; } if (!r.ok) return;
      const d = await r.json(); const prev = o.status;
      Object.assign(o, { status:d.status || o.status, requested_at:d.requested_at || o.requested_at, confirmed_at:d.confirmed_at || null, completed_at:d.completed_at || null, cancellation_reason:d.cancellation_reason || null, total_cents:d.total_cents ?? o.total_cents, fulfillment_type:d.fulfillment_type || o.fulfillment_type, delay_minutes:d.delay_minutes || 0 });
      o.loyalty_units = d.loyalty_units || 0; o.loyalty_credit_used_cents = d.loyalty_credit_used_cents || 0;
      if (o.status !== prev) { changed = true; toast(`${STATUS_ICON[o.status] || ""} Ordine ${o.orderNumber}: ${STATUS_TEXT[o.status] || o.status}`); notifyStatus(o); if (["COMPLETATO", "ANNULLATO"].includes(o.status)) setTimeout(() => refreshLoyalty(true), 1500); }
    } catch (e) {}
  }));
  saveOrders();
  if (changed && (location.hash === "#ordini" || location.hash === "#ordine")) render();
  if (!document.hidden && orders.some(o => !CLOSED.includes(o.status))) ordersTimer = setTimeout(refreshOrders, 15000);
}
document.addEventListener("visibilitychange", () => { if (document.hidden) clearTimeout(ordersTimer); else refreshOrders(); });

/* ============ AVVISI AL CLIENTE ============ */
function notifyStatus(o) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const testo = { ACCETTATO:`Ordine accettato! Orario: ${fmtRome(o.confirmed_at || o.requested_at)}`, IN_PREPARAZIONE:"La tua pizza è in preparazione 👨‍🍳", PRONTO:o.fulfillment_type === "DELIVERY" ? "Il tuo ordine è pronto, parte a momenti 🛍️" : "Il tuo ordine è pronto per il ritiro 🛍️", IN_CONSEGNA:"Il tuo ordine è in consegna 🛵", COMPLETATO:"Ordine consegnato. Grazie! 🎉", ANNULLATO:`Ordine annullato${o.cancellation_reason ? ": " + o.cancellation_reason : ""}` }[o.status];
  if (!testo) return;
  try { new Notification(`Pizzeria Dal Vicolo — ${o.orderNumber}`, { body:testo, tag:o.orderNumber, icon:IMG.promo1 }); } catch (e) {}
}
async function askNotify() {
  if (!("Notification" in window)) { toast("Il tuo telefono non supporta gli avvisi"); return; }
  const p = await Notification.requestPermission();
  toast(p === "granted" ? "Avvisi attivi ✅" : "Avvisi non attivati");
  render();
}

/* ============ CONDIVIDI ORDINE (foto creata dal telefono) ============ */
function orderCanvas(o) {
  const raw = String(o.ticket || "").split("\n");
  const PAD = 26, W = 600, FS = 18, LH = 26, BIG = 34, BIGLH = 46;
  let h = PAD * 2; raw.forEach(l => h += l.startsWith("\u0001") ? BIGLH : LH);
  const c = document.createElement("canvas"), dpr = 2; c.width = W * dpr; c.height = h * dpr;
  const x = c.getContext("2d"); x.scale(dpr, dpr);
  x.fillStyle = "#fff"; x.fillRect(0, 0, W, h); x.fillStyle = "#000"; x.textBaseline = "top";
  let y = PAD;
  raw.forEach(l => {
    const isBig = l.startsWith("\u0001"); const text = (isBig ? l.slice(1) : l).trim();
    if (isBig) { x.font = `900 ${BIG}px system-ui,Arial`; x.textAlign = "center"; x.fillText(text, W / 2, y); y += BIGLH; }
    else if (/^-{10,}$/.test(text)) { x.strokeStyle = "#bbb"; x.beginPath(); x.moveTo(PAD, y + LH / 2); x.lineTo(W - PAD, y + LH / 2); x.stroke(); y += LH; }
    else { x.font = `${FS}px ui-monospace,Menlo,Consolas,monospace`; x.textAlign = "left"; x.fillText(l, PAD, y); y += LH; }
  });
  return c;
}
async function shareOrder(orderNumber) {
  const o = orders.find(x => x.orderNumber === orderNumber); if (!o || !o.ticket) { toast("Riepilogo non disponibile"); return; }
  try {
    const blob = await new Promise(r => orderCanvas(o).toBlob(r, "image/png"));
    const file = new File([blob], `Ordine-${o.orderNumber}.png`, { type:"image/png" });
    if (navigator.canShare && navigator.canShare({ files:[file] })) { await navigator.share({ files:[file], title:`Ordine ${o.orderNumber}` }); return; }
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = file.name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast("Immagine salvata sul telefono");
  } catch (e) { if (e && e.name !== "AbortError") toast("Non riesco a creare l'immagine"); }
}

/* ============ SLIDER ============ */
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
function initSliders(root) {
  root.querySelectorAll("[data-slider]").forEach(s => {
    const slides = s.querySelector(".slides"), n = slides.children.length, dots = s.querySelectorAll(".dots span"); s._i = 0;
    s._go = i => { s._i = (i + n) % n; slides.style.transform = `translateX(-${s._i * 100}%)`; dots.forEach((d, k) => d.classList.toggle("on", k === s._i)); };
    let timer; const start = () => { if (n > 1 && !reduceMotion) timer = setInterval(() => s._go(s._i + 1), 4000); };
    s._touch = () => { clearInterval(timer); start(); };
    let x0 = null;
    s.addEventListener("touchstart", e => { x0 = e.touches[0].clientX; clearInterval(timer); }, { passive:true });
    s.addEventListener("touchend", e => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 40) s._go(s._i + (dx < 0 ? 1 : -1)); start(); }, { passive:true });
    start();
  });
}

updateCount(); render(); refreshOrders();
