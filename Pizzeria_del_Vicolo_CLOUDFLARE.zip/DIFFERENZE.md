# Cosa c'è nella mia versione che non c'è in quella online (ChatGPT)

Elenco da girare a ChatGPT per fargli aggiungere le stesse cose, oppure da usare
come lista di controllo se si carica la mia.

## 1. Notifiche push — CORREZIONE IMPORTANTE
Nella versione online la **firma VAPID** è stata corretta con `crypto.subtle`, ma la
**cifratura del messaggio** usa ancora Node: `createECDH`, `hkdfSync`, `createCipheriv`.
Su Cloudflare Workers queste funzioni in genere non esistono → la push può fallire.
Nella mia versione `_webpush` è riscritto **interamente** con WebCrypto:
- ECDH P-256 con `crypto.subtle.generateKey` / `deriveBits`
- HKDF con `crypto.subtle.deriveBits({name:"HKDF"})`
- AES-128-GCM con `crypto.subtle.encrypt`
- niente `Buffer`, niente `node:crypto`
Test: un "browser finto" decifra il messaggio e verifica titolo, testo e delimitatore 0x02.

## 2. Comanda nell'email a caratteri grandi
Le righe marcate (numero ordine, CONSEGNA/RITIRO, orario, TOTALE) ora nell'email HTML
escono a **26px in grassetto**, come sulla stampante e nell'app. Prima erano tutte uguali.
In fondo c'è il pulsante giallo **APRI IL GESTIONALE**.

## 3. Sito leggero (era la causa della sospensione su Netlify)
- Immagini estratte dalla pagina e messe in `/img`, compresse (max 900px, qualità ~70)
- La foto tacos era un PNG da 2,2 MB → ora 90 KB
- `index.html`: da 4,9 MB a **88 KB**; prima apertura 756 KB invece di 4,9 MB
- `_headers`: immagini in cache un anno
- Caricamento differito: si scarica solo la prima foto del banner

## 4. Scrittura nei campi del carrello
Se la pagina si ridisegna mentre l'utente scrive, ora il campo **riprende il fuoco e il
cursore resta al suo posto**. Prima si poteva perdere il testo dopo la prima lettera.

## 5. Tessera fedeltà — regola nuova
- Massimo **un premio da € 5 alla volta**: finché non lo usi i timbri NON salgono
- Quando il premio scatta il conteggio **riparte da zero**
- Il carrello lo dice: "Hai già € 5 di sconto pronto: usalo su questo ordine"
- La pagina fedeltà mostra "Premi ricevuti finora: N" (prima mostrava un totale sbagliato)

## 6. Litro omaggio del weekend
1 litro da € 20 di spesa, **2 soltanto sopra € 60**, mai di più (prima: 1 ogni € 20,
quindi a € 45 ne regalava 2).

## 7. Orari
Ordini fino alle **22:00 tutte le sere** (anche lunedì–giovedì). Ultimo orario di
consegna/ritiro 22:20, perché servono 20 minuti di preparazione.

## 8. Consumo ridotto
- Promemoria ordini non accettati: ogni **3 minuti, solo 11–23** (prima ogni 2, tutto il giorno)
- Tablet: interroga il server ogni **2 minuti** quando le push sono attive (prima 1)

## 9. Gestionale
- Una **tabella sola**: lo stato è scritto sotto ogni ordine, niente cartelle
- **Un solo pulsante grande** col passo successivo
- **Freccia ▼** su ogni riga per vedere i prodotti, e **⋮** con stampa, ristampa,
  condividi foto, chiama, WhatsApp, mappa, rifiuta
- Orario: premi ACCETTA → freccina → si aprono gli orari → scegli → **si richiude** →
  poi CONFERMA ORDINE (scegliere NON accetta)
- Anteprima prodotti sulla riga chiusa ("2× Margherita · 1× Capricciosa")
- Schermo del tablet sempre acceso mentre il gestionale è aperto

## 10. Condividi ordine anche per il cliente
Il cliente, dalla sua pagina Ordini, può condividere il riepilogo come **foto**.
L'immagine la crea il telefono: nessun costo sul server.

## 11. Cloudflare Pages invece di Worker
La mia versione è fatta per **Pages**: si carica trascinando lo zip dal browser,
senza computer, senza `npm` e senza `wrangler`. Cartella `functions/` con una rotta
per file. Il cron (promemoria) va impostato su cron-job.org chiamando
`/api/cron/escalation?key=CRON_KEY`.

## Test
115 server + 40 sito + 33 gestionale + 10 Cloudflare = **198 controlli automatici**.

## 12. Offerte: com'è configurato adesso (da verificare sulla versione online)

| Offerta | Regola nel mio pacchetto | Nota |
|---|---|---|
| Pizze classiche € 6 | Lunedì–Giovedì, **solo sera** (dalle 17:00) | a pranzo vale l'offerta € 7 |
| Offerta Mezzogiorno € 7 | Martedì–Venerdì 11:00–14:00: **pizza classica O piadina** + lattina 33cl | lattine: Coca-Cola, Coca Zero, Fanta, Sprite |
| Litro omaggio | Ven/Sab/Dom: **1 litro da € 20**, **2 sopra € 60**, mai di più | prima era 1 ogni € 20 → a € 45 ne regalava 2 |
| Dolci −50% | con ordine da € 25 | |
| Fritto Mix 12 pezzi omaggio | con ordine da € 60 | non patatine |
| Consegna | sempre gratuita | |
| Tessera fedeltà | 10 prodotti = € 5; **un solo premio alla volta**, poi il conteggio riparte da zero | i timbri non salgono finché non usi lo sconto |

Le offerte si applicano da sole in base al giorno e all'orario scelto dal cliente,
e sono scritte nella pagina Offerte e nel carrello.
