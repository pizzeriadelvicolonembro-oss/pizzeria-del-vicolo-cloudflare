/* ==========================================================================
   Pizzeria Dal Vicolo — LISTINO, ORARI E PROMOZIONI (unica fonte di verità)
   Usato SIA dal sito cliente (index.html lo include) SIA dalle funzioni server
   (netlify/functions importano questo file). Se cambi un prezzo o una promo,
   cambialo SOLO qui.
   ========================================================================== */
(function (root, factory) {
  if (typeof module === "object" && module.exports) { module.exports = factory(); }
  else if (root) { root.VicoloPricing = factory(); }
})(typeof self !== "undefined" ? self : (typeof globalThis !== "undefined" ? globalThis : this), function () {

const MENU = [
  { id:"pizze", name:"Pizze", icon:"🍕", photos:[],
    note:"Impasto integrale + € 1,00 · Baby − € 1,00 · Mozzarella senza lattosio + € 1,50",
    groups:[
      { name:"Classiche", items:[
        ["Margherita","pomodoro, mozzarella fior di latte, basilico fresco",6.00],
        ["Marinara","pomodoro, origano, aglio, olio",5.50],
        ["Prosciutto","pomodoro, mozzarella fior di latte, prosciutto",7.00],
        ["Prosciutto e Funghi","pomodoro, mozzarella fior di latte, prosciutto, funghi",8.00],
        ["Capricciosa","pomodoro, mozzarella fior di latte, prosciutto, carciofi, funghi, olive nere",8.50],
        ["Diavola","pomodoro, mozzarella fior di latte, salamino piccante",8.00],
        ["Würstel","pomodoro, mozzarella fior di latte, würstel",7.50],
        ["Quattro Stagioni","pomodoro, mozzarella fior di latte, prosciutto, carciofi, funghi, olive nere",8.50],
        ["Quattro Formaggi","zola dop, taleggio dop, grana, mozzarella",8.50],
        ["Napoli","pomodoro, mozzarella fior di latte, acciughe, olive nere, origano",8.00],
        ["Romana","pomodoro, mozzarella fior di latte, acciughe, olive nere, capperi, origano",8.00],
        ["Americana","pomodoro, mozzarella fior di latte, würstel, patatine fritte",8.50],
        ["Pugliese","pomodoro, mozzarella fior di latte, cipolle",7.50],
        ["Tonno","pomodoro, mozzarella fior di latte, tonno",7.50],
        ["Tonno e Cipolle","pomodoro, mozzarella fior di latte, tonno, cipolle",8.00]
      ]},
      { name:"Speciale", items:[
        ["Country","base bianca, mozzarella fior di latte, patate al forno, pollo fritto, patatine fritte, salsa barbecue",9.00]
      ]},
      { name:"Di Terra", items:[
        ["Orto e Pollo","pomodoro, mozzarella fior di latte, pollo grigliato, peperoni grigliati, basilico fresco, filo d'olio d'oliva",8.00],
        ["Calabrese","pomodoro, mozzarella fior di latte, salamino piccante, acciughe",8.50],
        ["Bergamasca","pomodoro, mozzarella fior di latte, taleggio DOP, salame nostrano",8.50],
        ["Bomba","pomodoro, mozzarella fior di latte, panna, brie, cipolle, salame dolce",9.00],
        ["Boscaiola","pomodoro, mozzarella fior di latte, funghi, pancetta",8.50],
        ["Calzone Liscio","pomodoro, mozzarella fior di latte, prosciutto",7.50],
        ["Calzone Farcito","pomodoro, mozzarella fior di latte, prosciutto cotto, funghi, carciofi",8.00],
        ["Calzone Quattro Formaggi","pomodoro, mozzarella fior di latte, zola dop, taleggio dop, grana",8.50],
        ["Carbonara","pomodoro, mozzarella fior di latte, pancetta, uovo, grana, pepe",8.50],
        ["Golosa","mozzarella fior di latte, pancetta, asparagi, scamorza",8.50],
        ["Schiaccianoci","pomodoro, mozzarella fior di latte, zola dop, noci",8.00],
        ["Lelli","pomodoro, mozzarella fior di latte, porcini, grana, crudo",8.50],
        ["Alehandra","pomodoro, mozzarella fior di latte, salsiccia, cime di rapa, grana a scaglie",9.00],
        ["Patatosa","pomodoro, mozzarella fior di latte, patate grigliate, panna, speck",9.00],
        ["Panna e Prosciutto","pomodoro, mozzarella fior di latte, panna, prosciutto cotto",8.00],
        ["Zola e Speck","pomodoro, mozzarella fior di latte, zola dop, speck",8.50],
        ["Umbra","pomodoro, mozzarella fior di latte, bresaola, scaglie di grana, olio al tartufo",8.50],
        ["Ghiotta","pomodoro, mozzarella fior di latte, salsiccia, rucola",9.00],
        ["Fumo di Londra","pomodoro, mozzarella fior di latte, funghi, speck, rucola",9.00],
        ["Bufala e Salamino","pomodoro pelati, bufala, salamino piccante, basilico fresco",8.50],
        ["Del Vicolo","pomodoro, mozzarella fior di latte, zola dop, salsiccia, rucola",9.00],
        ["Maialina","pomodoro, mozzarella fior di latte, würstel, prosciutto, salamino, pancetta",9.00],
        ["Valtellina","pomodoro, mozzarella fior di latte, bresaola, scaglie di grana, rucola",8.50],
        ["Vicolo Crispy","pomodoro, mozzarella, patatine fritte, pollo croccante, salsa BBQ",8.50]
      ]},
      { name:"Di Mare", items:[
        ["Arlecchina","pomodoro, mozzarella fior di latte, tonno, pomodorini, pesto",9.00],
        ["Delicata","mozzarella fior di latte, salmone, porcini, panna",9.00],
        ["Panna e Salmone","pomodoro, mozzarella fior di latte, salmone, panna",8.00],
        ["Frutti di Mare","pomodoro, mozzarella fior di latte, frutti di mare",9.00],
        ["Profumo di Mare","pomodoro, frutti di mare, mix di spezie, olio piccante",9.00],
        ["Mare e Monti","pomodoro, mozzarella fior di latte, frutti di mare, porcini",9.50],
        ["Gamberetti e Zucchine","pomodoro, mozzarella fior di latte, gamberetti, zucchine",8.50],
        ["Imperiale","pomodoro, mozzarella fior di latte, gamberetti, rucola",8.00],
        ["Clo Clo","pesto, mozzarella fior di latte, gamberetti",8.50]
      ]},
      { name:"Gourmet Cremose", items:[
        ["Carcioghiotta","mozzarella fior di latte, crema di carciofo, taleggio, carciofi",8.50],
        ["Delizia","mozzarella fior di latte, crema al carciofo, salsiccia, scamorza",9.50],
        ["Al Tartufo","mozzarella fior di latte, crema al tartufo, prosciutto, panna",9.50],
        ["Alba","mozzarella fior di latte, crema al tartufo, uovo, grana",9.50],
        ["Fior di Bosco","mozzarella fior di latte, crema al tartufo, porcini, panna, insalatina o rucola",10.00],
        ["Asparagus","mozzarella di bufala, crema agli asparagi, pomodorini, asparagi",10.00],
        ["Incanto","mozzarella fior di latte, crema agli asparagi, asparagi, pancetta, grana",10.00],
        ["Magica","mozzarella di bufala, crema agli asparagi, gamberetti",10.00],
        ["Provenzale","pomodoro, mozzarella fior di latte, prosciutto, brie",9.50],
        ["Sinforosa","mozzarella fior di latte, crema al radicchio, salsiccia, taleggio, radicchio",10.00],
        ["Primavera","mozzarella fior di latte, pistacchio, mozzarella di bufala, basilico fresco",11.50]
      ]},
      { name:"Agrodolci", items:[
        ["Zio Mela","mozzarella fior di latte, gorgonzola dop, pera, cannella",8.50],
        ["Zio Pera","mozzarella fior di latte, zola, mele, cannella, gorgonzola dop",8.50],
        ["Tirolese","mozzarella fior di latte, zola, mele",8.50]
      ]},
      { name:"Verdure", items:[
        ["Ortobello","pomodoro, mozzarella fior di latte, verdure grigliate",8.00],
        ["Rustica","pomodoro, mozzarella fior di latte, melanzane, porcini, scamorza",8.50],
        ["Bufalina","pomodoro, mozzarella di bufala, pomodorini, basilico fresco",8.50],
        ["Contadina","pomodoro, mozzarella fior di latte, spinaci, cipolle, grana",8.50],
        ["Mimosa","pomodoro, mozzarella fior di latte, zucchine, patate grigliate, grana",8.50],
        ["Nazionale","pomodoro, mozzarella fior di latte, pomodorini, grana, rucola",8.00],
        ["Parmigiana","pomodoro, mozzarella fior di latte, melanzane, grana",8.00],
        ["Ricotta e Spinaci","pomodoro, mozzarella fior di latte, ricotta, spinaci",8.00],
        ["Rucola e Grana","pomodoro, mozzarella fior di latte, scaglie di grana, rucola",8.00],
        ["Trevigiana","pomodoro, mozzarella fior di latte, radicchio, zola dop o scamorza",8.50],
        ["Veggie","zucchine, melanzane, carciofi, porcini, grana",8.50],
        ["Caprese","pomodoro, mozzarella fior di latte, pomodorini, origano",7.50],
        ["Di +","doppio pomodoro, melanzane fritte, basilico fresco",9.00],
        ["Di + Pro","doppio pomodoro, bufala, melanzane fritte, basilico fresco",10.50]
      ]},
      { name:"Famiglia ½ metro", note:"Cipolle normali o caramellate a scelta.", items:[
        ["Margherita ½ metro","",16.00],
        ["Prosciutto ½ metro","",19.00],
        ["Würstel ½ metro","",19.00],
        ["Americana ½ metro","",21.00],
        ["Quattro Formaggi ½ metro","",21.00],
        ["Capricciosa ½ metro","",21.00],
        ["Verdure ½ metro","",21.00],
        ["Diavola ½ metro","",19.00],
        ["Prosciutto e Funghi ½ metro","",21.00]
      ]}
    ]},
  { id:"kebab", note:"Salse, insalata, pomodoro, cipolla e peperoni a richiesta.", name:"Kebab", icon:"🌯", badge:"NOVITÀ", photos:[],
    note:"Salse, insalata, pomodoro, cipolla e peperoni a richiesta.",
    groups:[{ name:"", items:[
      ["Pizza Kebab","carne kebab, pomodoro, mozzarella fior di latte; salse, insalata, pomodoro, cipolla e peperoni a richiesta",8.50],
      ["Piadina Kebab","carne kebab, pomodoro, mozzarella fior di latte; salse, insalata, pomodoro, cipolla e peperoni a richiesta",6.50]
    ]}]},
  { id:"burger", name:"Hamburger", icon:"🍔", photos:[],
    note:"Carne Black Angus o bovina. Menu = con patatine + bibita (+ € 3,50).",
    groups:[{ name:"", items:[
      ["Morsetto Studente","panino, chicken strips, cheddar cheese, maionese",6.00],
      ["Morsetto Studente — Menu","con patatine + bibita",9.50],
      ["Gran Fumè","panino, burger black angus, cheddar, bacon croccante, cipolla caramellata, scaglie di grana, salsa burger",9.00],
      ["Gran Fumè — Menu","con patatine + bibita",12.50],
      ["Burger Vulcano","panino, burger black angus (200g), spinacino, fritti di formaggio, maionese al tabasco, pancetta arrotolata",8.50],
      ["Burger Vulcano — Menu","con patatine + bibita",12.00],
      ["Amante di Burger","panino, doppio burger black angus (400g), doppio bacon, doppio formaggio, iceberg, salsa burger",12.00],
      ["Amante di Burger — Menu","con patatine + bibita",15.50],
      ["Cheese Burger","panino, burger di bovino (200g), insalata, pomodoro, cheddar, salsa burger",8.00],
      ["Cheese Burger — Menu","con patatine + bibita",11.50],
      ["Pollo Croccante","panino, cotoletta di pollo, maionese, cheddar, iceberg",6.50],
      ["Pollo Croccante — Menu","con patatine + bibita",10.00]
    ]}]},
  { id:"tacos", name:"French Tacos", icon:"🌮", photos:[],
    note:"Menu = con patatine + bibita (+ € 3,50).",
    groups:[{ name:"", items:[
      ["Tacos Pollo","pollo, mozzarella filante, cheddar cheese, salsa tacos, salsa bianca",7.50],
      ["Tacos Pollo — Menu","con patatine + bibita",11.00],
      ["Tacos Carne","carne bovina macinata e marinata, cheddar cheese, patatine, salsa piccante",8.00],
      ["Tacos Carne — Menu","con patatine + bibita",11.50],
      ["Tacos Del Vicolo","carne macinata di manzo e pollo, doppio cheddar cheese, patatine, salsa a scelta",9.00],
      ["Tacos Del Vicolo — Menu","con patatine + bibita",12.50],
      ["Tacos Pollo Crispy","pollo fritto croccante, salse, patatine fritte, cheddar, piadina tortilla",6.50]
    ]}]},
  { id:"piadine", name:"Piadine", icon:"🫓", photos:[],
    groups:[{ name:"", items:[
      ["Superpollo","maionese, lattuga, pomodoro, pollo, scaglie di grana",6.50],
      ["Il Patatopollo","maionese, lattuga, pomodoro, patatine, pollo croccante, scaglie di grana",7.00],
      ["Classica","mozzarella fior di latte, prosciutto crudo",6.00],
      ["Gustosa","mozzarella fior di latte, pomodorini, cotto",6.00],
      ["Valtellina","mozzarella fior di latte, grana, bresaola, rucola",6.50],
      ["Vegetariana","mozzarella fior di latte, verdure grigliate",7.50],
      ["Romagnola","scamorza dop, crudo, rucola",6.50],
      ["Tirolese","zola dop, speck, radicchio",6.50],
      ["Bergamasca","taleggio dop, salame nostrano",6.50],
      ["In Rosa","mozzarella, gamberetti, salsa rosa, rucola",6.50]
    ]}]},
  { id:"fritti", name:"Fritti", icon:"🍟", photos:[],
    groups:[{ name:"", items:[
      ["Patatine Medie","",2.50],
      ["Patatine Giganti","",3.00],
      ["Mozzarelline Fritte","",3.50],
      ["Olive Ascolane Fritte","",3.50],
      ["Crocchette di Patate","",3.50],
      ["Crocchette di Pollo","",4.00],
      ["Chili Cheese","",4.00],
      ["Pollo Popcorn","",4.00],
      ["Onion Rings","",4.00],
      ["Patate al Forno","",4.50],
      ["Mozzarella Stick","",5.00],
      ["Alette di Pollo (4 pz)","",5.50],
      ["Cosce di Pollo e Patate Arrosto","",5.50],
      ["Mix 12 Pezzi","",5.50]
    ]}]},
  { id:"dolci", name:"Dolci", icon:"🍫", badge:"NUOVO", photos:[],
    note:"Dolci disponibili nel menu.",
    groups:[{ name:"", items:[
      ["Panzerotto Nutella","panzerotto chiuso alla Nutella",6.50],
      ["Panzerotto Nutella e Noci","panzerotto chiuso alla Nutella e noci",7.50],
      ["Panzerotto Nutella e Pere","panzerotto chiuso alla Nutella e pere",7.50],
      ["Tacos Nutella e Banana","tortilla dolce, Nutella, banana, granella di nocciole, zucchero a velo",6.00]
    ]}]}
];
const PIZZA_ADDONS = [
 ["Mozzarella senza lattosio",1.50],["Bufala",2.00],["Doppia Mozzarella",2.00],["Pancetta",2.00],["Speck",2.00],["Salame dolce",2.00],["Salame piccante",2.00],["Salsiccia",2.00],["Bresaola",1.50],["Prosciutto Cotto",1.50],["Prosciutto Crudo",2.00],["Würstel",1.50],["Porcini",1.50],["Salmone",1.50],["Gamberetti",2.00],["Melanzane",1.50],["Peperoni",1.50],["Spinaci",1.50],["Asparagi",1.50],["Brie",1.50],["Patate al Forno",2.00],["Patatine fritte",2.00],["Cipolle",0.50],["Carciofi",0.50],["Zucchine",1.00],["Radicchio",1.00],["Rucola",1.00],["Pomodorini",1.00],["Pomodoro extra",1.00],["Olive nere",1.00],["Funghi",1.00],["Scamorza",1.00],["Taleggio",1.00],["Zola",1.00],["Tonno",1.00],["Panna",0.50],["Ricotta",1.00],["Grana Grattugiata",0.50],["Grana a Scaglie",1.00],["Cipolle Caramellate",1.00],["Acciughe",1.00],["Insalata",1.00],["Noci",1.00],["Ketchup",0.50],["Maionese",0.50],["Uovo",0.50],["Capperi",0.50],["Jalapeño",1.00],["Olio Piccante",0.00]
];
const FAST_ADDONS = [["Mozzarella senza lattosio",1.50],["Bufala",2.00],["Prosciutto Cotto",1.50],["Prosciutto Crudo",2.00],["Speck",2.00],["Pancetta",2.00],["Funghi",1.00],["Cipolle Caramellate",1.00],["Grana a Scaglie",1.00],["Ketchup",0.50],["Maionese",0.50],["Salsa Piccante",0.50],["Salsa Hamburger",0.50],["Salsa Barbecue",0.50],["Jalapeño",1.00],["Patatine extra dentro",2.00],["Olio Piccante",0.00]];


const PIZZA_OPTIONS = [
  { group:"dough", name:"Impasto normale", price:0, default:true },
  { group:"dough", name:"Impasto integrale", price:1.00 },
  { group:"size",  name:"Formato normale", price:0, default:true },
  { group:"size",  name:"Baby pizza", price:-1.00 }
];
const CUSTOMIZABLE = ["pizze","burger","tacos","kebab","piadine"];

/* ---------------- ORARI DI APERTURA (minuti dalla mezzanotte, ora di Roma) ---------------- */
/* 0=Domenica 1=Lunedì ... 6=Sabato */
/* Ordini online fino alle 22:00 tutte le sere: con 20 minuti di anticipo, l'ultimo orario
   di consegna/ritiro è 22:20 (EVENING_END). */
const EVENING_END = 22*60 + 20;
const HOURS = {
  0: [[17*60, EVENING_END]],
  1: [[17*60+30, EVENING_END]],
  2: [[11*60, 14*60], [17*60+30, EVENING_END]],
  3: [[11*60, 14*60], [17*60+30, EVENING_END]],
  4: [[11*60, 14*60], [17*60+30, EVENING_END]],
  5: [[11*60, 14*60], [17*60+30, EVENING_END]],
  6: [[17*60, EVENING_END]]
};
const HOURS_TEXT = [
  ["Lunedì", "pranzo chiuso · 17:30–22:00"],
  ["Martedì–Venerdì", "11:00–14:00 · 17:30–22:00"],
  ["Sabato–Domenica", "pranzo chiuso · 17:00–22:00"],
  ["Ordini online", "fino alle 22:00 tutte le sere"]
];
const SLOT_MINUTES = 15;      // passo delle fasce orarie
const MIN_LEAD_MINUTES = 20;  // anticipo minimo tra "adesso" e l'orario richiesto (modificabile)
const MAX_DAYS_AHEAD = 7;     // quanti giorni avanti si può prenotare

/* ---------------- PROMOZIONI ---------------- */
const PROMO = {
  evening6:   { days:[1,2,3,4], from:17*60, price:6.00 },          // Lun–Gio sera: pizze classiche €6
  lunch7:     { days:[2,3,4,5], from:11*60, to:14*60, price:7.00,   // Mar–Ven pranzo: pizza classica O piadina + lattina 33cl = €7
                cats:["piadine"], cans:["Coca-Cola","Coca-Cola Zero","Fanta","Sprite"] },
  /* Ven–Dom: Pepsi 1,5L omaggio da €20; la seconda solo sopra €60. Mai più di 2. */
  weekendGift:{ days:[5,6,0], min:20, second:60, max:2, choices:["Pepsi 1,5L"] },
  dolciHalf:  { min:25 },                                            // dolci -50% se il resto dell'ordine ≥ €25
  bigGift:    { min:60, item:"Fritto Mix 12 pezzi" }                 // ordine ≥ €60 → fritto mix omaggio
};
const LOYALTY = { goal:10, credit:5.00 };

/* ---------------- ORA DI ROMA ---------------- */
const WD = { Sun:0, Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6 };
function romeParts(date) {
  const f = new Intl.DateTimeFormat("en-GB", { timeZone:"Europe/Rome", hourCycle:"h23", year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", minute:"2-digit", weekday:"short" });
  const p = {}; f.formatToParts(date).forEach(x => { p[x.type] = x.value; });
  const hh = Number(p.hour) % 24;
  return { y:Number(p.year), m:Number(p.month), d:Number(p.day), hh, mm:Number(p.minute), weekday:WD[p.weekday], mins:hh*60+Number(p.minute),
           dateStr:`${p.year}-${p.month}-${p.day}`, timeStr:`${String(hh).padStart(2,"0")}:${p.minute}` };
}
function romeOffsetMinutes(utcDate) {
  const p = romeParts(utcDate);
  const asUTC = Date.UTC(p.y, p.m-1, p.d, p.hh, p.mm);
  return Math.round((asUTC - utcDate.getTime()) / 60000);
}
/* "2026-09-18" + "19:30" letti come ora di Roma → istante UTC */
function romeToUTC(dateStr, timeStr) {
  const [y,m,d] = dateStr.split("-").map(Number); const [hh,mm] = timeStr.split(":").map(Number);
  const guess = Date.UTC(y, m-1, d, hh, mm);
  let off = romeOffsetMinutes(new Date(guess));
  let utc = guess - off*60000;
  const off2 = romeOffsetMinutes(new Date(utc));
  if (off2 !== off) utc = guess - off2*60000;
  return new Date(utc);
}
function weekdayOf(dateStr) { const [y,m,d] = dateStr.split("-").map(Number); return new Date(Date.UTC(y, m-1, d)).getUTCDay(); }
function isOpenAt(weekday, mins) { return (HOURS[weekday] || []).some(([a,b]) => mins >= a && mins <= b); }
function isOpenInstant(date) { const p = romeParts(date); return isOpenAt(p.weekday, p.mins); }
/* Fasce disponibili per una data: esclude il passato e l'anticipo minimo */
function slotsFor(dateStr, now) {
  now = now || new Date();
  const wd = weekdayOf(dateStr), today = romeParts(now);
  const limit = today.dateStr === dateStr ? today.mins + MIN_LEAD_MINUTES : (dateStr < today.dateStr ? Infinity : -1);
  const out = [];
  const hm = t => `${String(Math.floor(t/60)).padStart(2,"0")}:${String(t%60).padStart(2,"0")}`;
  (HOURS[wd] || []).forEach(([a,b]) => {
    for (let t=a; t<=b; t+=SLOT_MINUTES) if (t >= limit) out.push(hm(t));
    if ((b - a) % SLOT_MINUTES && b >= limit) out.push(hm(b));        /* ultimo orario fuori griglia (22:20) */
  });
  return out;
}
function nextDates(now, days) {
  now = now || new Date(); const out = []; const base = romeParts(now);
  for (let i=0; i<(days||MAX_DAYS_AHEAD); i++) {
    const d = new Date(Date.UTC(base.y, base.m-1, base.d + i));
    out.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}-${String(d.getUTCDate()).padStart(2,"0")}`);
  }
  return out;
}

/* ---------------- LISTINO ---------------- */
function findItem(baseKey) {
  const [cid, gi, ii] = String(baseKey || "").split(":");
  const cat = MENU.find(c => c.id === cid); if (!cat) return null;
  const g = cat.groups[+gi]; const it = g && g.items[+ii]; if (!it) return null;
  return { catId:cid, groupIndex:+gi, name:it[0], desc:it[1], price:it[2], classic: cid==="pizze" && +gi===0, dolce: cid==="dolci" };
}
function addonsFor(catId) { return catId === "pizze" ? PIZZA_ADDONS : FAST_ADDONS; }
function addonPrice(catId, name) {
  const opt = catId === "pizze" ? PIZZA_OPTIONS.find(o => o.name === name) : null; if (opt) return opt.price;
  const a = addonsFor(catId).find(x => x[0] === name); return a ? a[1] : null;
}
function r2(x) { return Math.round(x*100)/100; }

function kitchenName(catId, name) {
  const n = String(name || "");
  if (catId === "pizze") return /^PIZZA\s*[-–—]/i.test(n) ? n : `PIZZA – ${n}`;
  if (catId === "piadine") return /^PIADINA\s*[-–—]/i.test(n) ? n : `PIADINA – ${n}`;
  if (catId === "burger") return /^BURGER\s*[-–—]/i.test(n) ? n : `BURGER – ${n}`;
  if (catId === "tacos") {
    const clean = n.replace(/^TACOS\s*[-–—]\s*/i, "").replace(/^Tacos\s+/i, "");
    return `TACOS – ${clean}`;
  }
  if (catId === "fritti") return /^FRITTO\s*[-–—]/i.test(n) ? n : `FRITTO – ${n}`;
  if (catId === "dolci") return /^DOLCE\s*[-–—]/i.test(n) ? n : `DOLCE – ${n}`;
  if (catId === "kebab") {
    if (/^Pizza Kebab$/i.test(n)) return "PIZZA KEBAB";
    if (/^Piadina Kebab$/i.test(n)) return "PIADINA KEBAB";
    return /^KEBAB\s*[-–—]/i.test(n) ? n : `KEBAB – ${n}`;
  }
  return n;
}

/* ---------------- CALCOLO ORDINE ----------------
   items: [{ baseKey:"pizze:0:0", qty:2, addons:["Bufala"], note:"" }]
   moment: { weekday:0-6, mins } dell'orario RICHIESTO (ora di Roma)
   choices: { cans:["Coca-Cola",...], weekendGift:"Pepsi 1,5L" } (automatico)
*/
function priceOrder(items, moment, choices) {
  choices = choices || {}; const lines = []; const errors = [];
  const lunch = PROMO.lunch7.days.includes(moment.weekday) && moment.mins >= PROMO.lunch7.from && moment.mins <= PROMO.lunch7.to;
  const evening = PROMO.evening6.days.includes(moment.weekday) && moment.mins >= PROMO.evening6.from;
  (items || []).forEach((raw, idx) => {
    const it = findItem(raw.baseKey); const qty = Math.floor(Number(raw.qty));
    if (!it) { errors.push(`Articolo ${idx+1} non valido`); return; }
    if (!Number.isFinite(qty) || qty < 1 || qty > 50) { errors.push(`Quantità non valida per ${it.name}`); return; }
    let extras = 0; const addons = [];
    (raw.addons || []).forEach(n => { const p = addonPrice(it.catId, n); if (p === null) { errors.push(`Aggiunta non valida: ${n}`); } else { extras += p; addons.push(n); } });
    if (!CUSTOMIZABLE.includes(it.catId) && addons.length) errors.push(`${it.name} non è personalizzabile`);
    const listUnit = r2(it.price + extras); let unit = listUnit; const tags = [];
    const lunchItem = it.classic || (PROMO.lunch7.cats || []).includes(it.catId);
    if (lunchItem && lunch)         { unit = r2(PROMO.lunch7.price + extras);                 tags.push("PRANZO €7 + lattina"); }
    else if (it.classic && evening) { unit = r2(Math.min(it.price, PROMO.evening6.price) + extras); if (unit < listUnit) tags.push("LUN–GIO €6"); }
    const note = String(raw.note || "").trim().slice(0, 180);
    let name = kitchenName(it.catId, it.name); if (addons.length) name += " + " + addons.join(", ");
    lines.push({ key:raw.key, baseKey:raw.baseKey, catId:it.catId, name, baseName:it.name, addons, note, qty, listUnit, unit, tags, classic:it.classic, dolce:it.dolce });
  });
  /* Dolci a metà prezzo se il resto dell'ordine (già scontato) arriva a €25 */
  const restTotal = r2(lines.filter(l => !l.dolce).reduce((s,l) => s + l.unit*l.qty, 0));
  const dolciHalf = restTotal >= PROMO.dolciHalf.min && lines.some(l => l.dolce);
  if (dolciHalf) lines.forEach(l => { if (l.dolce) { l.unit = r2(l.unit/2); l.tags.push("DOLCE -50%"); } });
  const subtotal = r2(lines.reduce((s,l) => s + l.listUnit*l.qty, 0));
  const promoTotal = r2(lines.reduce((s,l) => s + l.unit*l.qty, 0));
  /* Credito tessera fedeltà (€ 5, uno per ordine): si toglie DOPO le promozioni; gli omaggi si calcolano su quanto si paga davvero */
  const loyaltyDiscount = r2(Math.min(Math.max(0, Number(choices.loyaltyCents || 0)) / 100, promoTotal));
  const total = r2(promoTotal - loyaltyDiscount);
  /* Omaggi */
  const gifts = [];
  const lunchCans = lines.filter(l => lunch && (l.classic || (PROMO.lunch7.cats || []).includes(l.catId))).reduce((s,l) => s + l.qty, 0);
  if (lunchCans) {
    const chosen = (choices.cans || []).filter(c => PROMO.lunch7.cans.includes(c));
    for (let i=0; i<lunchCans; i++) gifts.push({ type:"lunch-can", name:"Lattina 33cl " + (chosen[i] || PROMO.lunch7.cans[0]), qty:1 });
  }
  const weekend = PROMO.weekendGift.days.includes(moment.weekday);
  const weekendGifts = weekend ? (total >= PROMO.weekendGift.second ? 2 : (total >= PROMO.weekendGift.min ? 1 : 0)) : 0;
  if (weekendGifts) gifts.push({ type:"weekend-1l", name: PROMO.weekendGift.choices.includes(choices.weekendGift) ? choices.weekendGift : PROMO.weekendGift.choices[0], qty:weekendGifts });
  const bigGift = total >= PROMO.bigGift.min;
  if (bigGift) gifts.push({ type:"big-order", name:PROMO.bigGift.item, qty:1 });
  const units = lines.reduce((s,l) => s + l.qty, 0);
  return { lines, errors, subtotal, promoTotal, loyaltyDiscount, total, delta:r2(subtotal-promoTotal), lunch, evening, weekend, lunchCans, weekendGifts, bigGift, dolciHalf, gifts, units,
           missingForBigGift: bigGift ? 0 : r2(PROMO.bigGift.min - total), missingForDolci: dolciHalf ? 0 : r2(Math.max(0, PROMO.dolciHalf.min - restTotal)) };
}
function eur(n) { return "€ " + Number(n||0).toFixed(2).replace(".", ","); }
function loyaltyUnits(lines) { return (lines||[]).reduce((s,l) => s + l.qty, 0); }

/* ---------------- COMANDA (una sola, uguale ovunque) ----------------
   Larghezza 32 caratteri: si legge bene su Gmail dal telefono, nell'app, nella foto
   condivisa e sulla carta termica da 80 mm. Le righe marcate con \u0001 vengono
   stampate a caratteri doppi dalla stampante e mostrate grandi nell'app. */
function buildTicket(o) {
  const W = 32;
  const thin = () => "-".repeat(W);
  const center = t => { t = String(t); const sp = Math.max(0, Math.floor((W - t.length) / 2)); return " ".repeat(sp) + t; };
  const center2 = t => { t = String(t); const sp = Math.max(0, Math.floor((W / 2 - t.length) / 2)); return " ".repeat(sp) + t; };
  const big = t => "\u0001" + center2(String(t).toUpperCase());
  const cols = (l, r) => { l = String(l); r = String(r); const sp = Math.max(1, W - l.length - r.length); return l + " ".repeat(sp) + r; };
  const wrap = (t, indent, first) => {
    first = first || ""; const words = String(t).split(/\s+/).filter(Boolean); const out = []; let cur = "";
    const maxFirst = W - first.length, maxRest = W - indent;
    words.forEach(w => { const max = out.length ? maxRest : maxFirst; if (cur && (cur + " " + w).length > max) { out.push(cur); cur = w; } else cur = cur ? cur + " " + w : w; });
    if (cur) out.push(cur);
    return out.map((x, i) => (i === 0 ? first : " ".repeat(indent)) + x);
  };
  const price = n => Number(n || 0).toFixed(2).replace(".", ",");
  const L = [];
  L.push(center("PIZZERIA DEL VICOLO"));
  L.push(center("035 034 6406"));
  L.push(thin());
  L.push(big(o.orderNumber || ""));
  L.push(big(o.fulfillmentType === "DELIVERY" ? "consegna" : "ritiro"));
  L.push(big((o.confirmedText || o.requestedText || "").trim()));
  L.push(thin());
  (o.lines || []).forEach(l => {
    /* nome su una riga, prezzo allineato a destra: così non va a capo nemmeno su Gmail */
    const nome = `${l.qty} ${l.name}`, pz = price(l.unit * l.qty);
    if (nome.length + pz.length + 1 <= W) L.push(cols(nome, pz));
    else { wrap(l.name, 2, `${l.qty} `).forEach(x => L.push(x)); L.push(cols("", pz)); }
    if (l.tags && l.tags.length) L.push("  " + l.tags.join(" "));
    if (l.note) wrap(l.note, 2, "  ").forEach(x => L.push(x));
  });
  (o.gifts || []).forEach(g => { const nome = `${g.qty} ${g.name}`; L.push(nome.length + 8 <= W ? cols(nome, "OMAGGIO") : nome + "\n  OMAGGIO"); });
  L.push(thin());
  if (o.delta > 0) { L.push(cols("Subtotale", price(o.subtotal))); L.push(cols("Promozioni", "-" + price(o.delta))); }
  if (o.loyaltyDiscount > 0) L.push(cols("Credito fedelta", "-" + price(o.loyaltyDiscount)));
  L.push(big("TOTALE " + price(o.total)));
  L.push(center((o.paymentMethod || "").slice(0, 18) + (o.paid ? " PAGATO" : " DA INCASSARE")));
  L.push(thin());
  L.push(`${(o.customer && o.customer.name) || ""}`.trim());
  L.push(`${(o.customer && o.customer.phone) || ""}`.trim());
  if (o.fulfillmentType === "DELIVERY" && o.address) wrap(o.address, 0, "").forEach(x => L.push(x));
  if (o.notes) { L.push(""); wrap(o.notes, 0, "NOTE: ").forEach(x => L.push(x)); }
  if (o.allergyNotes) wrap(o.allergyNotes, 0, "ALLERGIE: ").forEach(x => L.push(x));
  L.push(thin());
  return L.join("\n");
}

return { MENU, PIZZA_ADDONS, FAST_ADDONS, PIZZA_OPTIONS, CUSTOMIZABLE, HOURS, HOURS_TEXT, SLOT_MINUTES, MIN_LEAD_MINUTES, MAX_DAYS_AHEAD, PROMO, LOYALTY,
         romeParts, romeOffsetMinutes, romeToUTC, weekdayOf, isOpenAt, isOpenInstant, slotsFor, nextDates,
         findItem, addonsFor, addonPrice, priceOrder, eur, loyaltyUnits, buildTicket, r2 };
});
