-- 006: account dello staff creati dal gestionale (niente più variabili Netlify per ogni persona).
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL DEFAULT 'STAFF',
  pass_salt TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMPTZ
);
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
