-- 005: stampante cloud (comande automatiche). Sicuro da eseguire più volte.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS printed_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS print_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reprint_requested_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reprint_by TEXT;
CREATE INDEX IF NOT EXISTS orders_print_queue_idx ON orders (created_at) WHERE printed_at IS NULL;
