-- 004: tessera fedeltà automatica + telefonata di escalation. Sicuro da eseguire più volte.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS called_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS loyalty_units INTEGER NOT NULL DEFAULT 0;
ALTER TABLE loyalty_accounts ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
CREATE UNIQUE INDEX IF NOT EXISTS loyalty_ledger_earn_once ON loyalty_ledger (order_id) WHERE entry_type = 'EARN';
CREATE UNIQUE INDEX IF NOT EXISTS loyalty_ledger_refund_once ON loyalty_ledger (order_id) WHERE entry_type = 'REFUND';
CREATE INDEX IF NOT EXISTS customers_phone_idx ON customers (phone);
