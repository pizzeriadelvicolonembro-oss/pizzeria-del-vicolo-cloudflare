/* Stato di un ordine per il cliente: serve numero ordine + chiave segreta ricevuta alla creazione. */
import type { Config } from "@netlify/functions";
import { sb, json } from "./_supabase.mts";
const clean = (s: unknown, max = 160) => typeof s === "string" ? s.trim().slice(0, max) : "";
export default async (req: Request) => {
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const u = new URL(req.url), order = clean(u.searchParams.get("order")), key = clean(u.searchParams.get("key"), 120);
  if (!order || !key) return json({ error: "Dati mancanti" }, 400);
  try {
    const rows = await sb(`orders?order_number=eq.${encodeURIComponent(order)}&idempotency_key=eq.${encodeURIComponent(key)}&select=order_number,status,requested_at,confirmed_at,accepted_at,completed_at,created_at,fulfillment_type,cancellation_reason,total_cents,delay_minutes,loyalty_credit_used_cents,loyalty_units`);
    if (!rows?.[0]) return json({ error: "Ordine non trovato" }, 404);
    return json(rows[0]);
  } catch (e) { console.error(e); return json({ error: "Errore stato ordine" }, 500); }
};
export const config: Config = { path: "/api/order-status" };
