/* Registro notifiche (ultime 200) per capire cosa è partito e cosa ha fallito. */
import type { Config } from "@netlify/functions";
import { isAdmin } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
export default async (req: Request) => {
  if (!(await isAdmin(req))) return json({ error: "Non autorizzato" }, 401);
  try { return json({ log: await sb("notification_log?select=*&order=created_at.desc&limit=200"), subscriptions: await sb("push_subscriptions?select=id,user_label,role,created_at,last_ok_at,last_error&order=created_at.desc") }); }
  catch (e) { console.error(e); return json({ error: "Registro non disponibile" }, 503); }
};
export const config: Config = { path: "/api/admin/notifications" };
