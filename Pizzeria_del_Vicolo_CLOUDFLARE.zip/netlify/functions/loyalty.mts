/* Stato tessera fedeltà per il cliente. Per non far leggere i timbri di chiunque, serve la prova di un proprio ordine:
   GET /api/loyalty?phone=333...&order=V2609-XXXX&key=<chiave ricevuta alla creazione di quell'ordine> */
import { sb, json } from "./_supabase.mts";
import { normPhone, getAccount, summary } from "./_loyalty.mts";
const clean = (s: unknown, max = 160) => typeof s === "string" ? s.trim().slice(0, max) : "";
export default async (req: Request) => {
  const u = new URL(req.url); const phone = normPhone(u.searchParams.get("phone")), order = clean(u.searchParams.get("order")), key = clean(u.searchParams.get("key"), 120);
  if (phone.length < 8 || !order || !key) return json({ error: "Dati mancanti" }, 400);
  try {
    const rows = await sb(`orders?order_number=eq.${encodeURIComponent(order)}&idempotency_key=eq.${encodeURIComponent(key)}&select=customer_phone,customer_id`);
    if (!rows?.[0] || normPhone(rows[0].customer_phone) !== phone) return json({ error: "Ordine non trovato" }, 404);
    let customerId = rows[0].customer_id;
    if (!customerId) { const c = await sb(`customers?phone=eq.${phone}&select=id`); customerId = c?.[0]?.id; }
    const acc = customerId ? await getAccount(customerId) : null;
    return json({ phone, ...summary(acc) });
  } catch (e) { console.error(e); return json({ error: "Tessera non disponibile" }, 500); }
};
