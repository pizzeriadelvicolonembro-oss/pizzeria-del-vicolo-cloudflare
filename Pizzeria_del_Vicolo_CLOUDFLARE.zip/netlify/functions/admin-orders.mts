/* Elenco ordini per il gestionale.
   ?scope=active   → tutti gli ordini non chiusi (NUOVO, ACCETTATO, IN_PREPARAZIONE, PRONTO, IN_CONSEGNA)
   ?scope=today    → ordini di oggi (ora di Roma), qualsiasi stato
   ?scope=history  → chiusi (COMPLETATO/ANNULLATO), paginati: &limit=50&before=<created_at ISO>
   &q=testo        → cerca per numero ordine, nome o telefono */
import type { Config } from "@netlify/functions";
import { isAdmin } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
import pricing from "../../shared/pricing.js";
const SELECT = "*,order_items(product_name,quantity,effective_unit_cents,modifiers,item_notes)";
export default async (req: Request) => {
  if (!(await isAdmin(req))) return json({ error: "Non autorizzato" }, 401);
  const u = new URL(req.url); const scope = u.searchParams.get("scope") || "active"; const q = (u.searchParams.get("q") || "").trim().slice(0, 60);
  const limit = Math.min(200, Math.max(1, Number(u.searchParams.get("limit") || 100))); const before = u.searchParams.get("before") || "";
  try {
    let path = `orders?select=${SELECT}&order=created_at.desc&limit=${limit}`;
    if (q) {
      const s = encodeURIComponent(`*${q.replace(/[%,()]/g, "")}*`);
      path += `&or=(order_number.ilike.${s},customer_name.ilike.${s},customer_phone.ilike.${s})`;
    } else if (scope === "active") path += `&status=not.in.(COMPLETATO,ANNULLATO)`;
    else if (scope === "today") { const p = pricing.romeParts(new Date()); path += `&created_at=gte.${pricing.romeToUTC(p.dateStr, "00:00").toISOString()}`; }
    else if (scope === "history") { path += `&status=in.(COMPLETATO,ANNULLATO)`; if (before) path += `&created_at=lt.${encodeURIComponent(before)}`; }
    const orders = await sb(path);
    return json({ orders, scope, nowRome: pricing.romeParts(new Date()).timeStr, serverTime: new Date().toISOString() });
  } catch (e) { console.error(e); return json({ error: "Database ordini non disponibile" }, 503); }
};
export const config: Config = { path: "/api/admin/orders" };
