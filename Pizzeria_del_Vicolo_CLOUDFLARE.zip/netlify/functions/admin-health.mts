/* Controllo sistema, visibile solo dopo login.
   Non restituisce mai chiavi o password: solo stato verde/rosso dei componenti. */
import { getSession } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
import { notifyEmails, sendEmailToOwners, vapid, siteUrl } from "./_notify.mts";

const has = (k: string) => !!String(Netlify.env.get(k) || "").trim();

export default async (req: Request) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  const u = new URL(req.url);

  if (req.method === "POST" && u.searchParams.get("test") === "email") {
    if (s.role !== "OWNER") return json({ error: "Solo il proprietario può inviare la prova email" }, 403);
    const r = await sendEmailToOwners(null, "✅ PROVA EMAIL — Pizzeria del Vicolo",
      `Email di prova inviata dal gestionale da ${s.user}.\nSe la ricevi, gli avvisi email degli ordini sono configurati.`);
    return json({ ok: true, result: r });
  }
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });

  let database = false, dbError = "", users = 0, subscriptions = 0, lastPushOk: string | null = null;
  try {
    await sb("settings?select=key&limit=1");
    database = true;
    const us = await sb("admin_users?select=id&active=is.true&limit=500");
    users = Array.isArray(us) ? us.length : 0;
    const ps = await sb("push_subscriptions?select=last_ok_at&order=last_ok_at.desc.nullslast&limit=200");
    subscriptions = Array.isArray(ps) ? ps.length : 0;
    lastPushOk = ps?.[0]?.last_ok_at || null;
  } catch (e: any) { dbError = String(e?.message || e).slice(0, 180); }

  const v = vapid();
  const emails = notifyEmails();
  const resendConfigured = has("RESEND_API_KEY") && emails.length > 0 && has("NOTIFY_FROM");
  const pushConfigured = !!v;
  const sessionSigning = has("ADMIN_SESSION_SECRET") || has("SUPABASE_SECRET_KEY") || has("OWNER_PASSWORD") || has("ADMIN_PASSWORD");

  return json({
    ok: database && resendConfigured && pushConfigured && sessionSigning,
    generatedAt: new Date().toISOString(),
    siteUrl: siteUrl(),
    checks: {
      database: { ok: database, error: dbError || null },
      login: { ok: sessionSigning, activeUsers: users },
      email: { ok: resendConfigured, recipients: emails.length },
      push: { ok: pushConfigured, subscriptions, lastPushOk },
      reminders: { ok: true, schedule: "ogni 3 minuti, 09–21 UTC" }
    }
  });
};
