import { getSession } from "./_auth.mts";
export default async (req: Request) => {
  const s = await getSession(req); if (!s) return Response.json({ error: "Non autorizzato" }, { status: 401 });
  return Response.json({ role: s.role, user: s.user, exp: s.exp }, { headers: { "Cache-Control": "no-store" } });
};
