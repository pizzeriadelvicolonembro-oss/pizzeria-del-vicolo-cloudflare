/* Coda di stampa condivisa dai protocolli Star ed Epson. */
import { sb } from "./_supabase.mts";
const ACTIVE = "(NUOVO,ACCETTATO,IN_PREPARAZIONE,PRONTO,IN_CONSEGNA)";
/* Si stampano gli ordini ancora da fare (non annullati/completati) non ancora stampati, il cui orario richiesto non è
   passato da più di 6 ore: se la stampante era spenta (pizzeria chiusa), all'accensione escono tutti gli ordini arrivati nel frattempo. */
export async function nextPrintJob() {
  const since = new Date(Date.now() - 6 * 3600_000).toISOString();
  const rows = await sb(`orders?select=*&printed_at=is.null&status=in.${ACTIVE}&requested_at=gte.${since}&order=created_at.asc&limit=1`);
  return rows?.[0] || null;
}
/* Testo per la stampante: solo ASCII (le termiche sbagliano spesso accenti ed emoji) */
export function jobText(o: any) {
  const map: Record<string, string> = { "à": "a", "è": "e", "é": "e", "ì": "i", "ò": "o", "ù": "u", "À": "A", "È": "E", "É": "E", "Ì": "I", "Ò": "O", "Ù": "U", "€": "EUR", "·": "-", "—": "-", "–": "-", "’": "'", "“": '"', "”": '"' };
  const head = (o.print_count || 0) > 0 ? "          *** RISTAMPA ***\n" : "";
  let body = o.ticket_text || `ORDINE ${o.order_number}`;
  /* se nel frattempo l'ordine è stato accettato, aggiunge l'orario confermato sotto quello richiesto */
  if (o.confirmed_at && !body.includes("ORA CONFERMATA")) {
    const t = `${fmt(o.confirmed_at)}${o.delay_minutes ? ` (+${o.delay_minutes})` : ""}`;
    const label = "ORA CONFERMATA:";
    body = body.replace(/(ORA RICHIESTA:.*\n)/, `$1${label}${" ".repeat(Math.max(1, 42 - label.length - t.length))}${t}\n`);
  }
  const t = head + body;
  const clean = t.replace(/[àèéìòùÀÈÉÌÒÙ€·—–’“”]/g, c => map[c] || c).replace(/[^\x01\x09\x0A\x0D\x20-\x7E]/g, "");
  /* le righe che iniziano con \x01 escono a caratteri DOPPI (ESC/POS: GS ! 0x11 ... GS ! 0x00) */
  const out = clean.split("\n").map(l => l.startsWith("\x01") ? "\x1D\x21\x11" + l.slice(1) + "\x1D\x21\x00" : l).join("\n");
  return out + "\n";
}
export async function markDelivered(o: any) {
  await sb(`orders?id=eq.${o.id}`, { method: "PATCH", body: JSON.stringify({ printed_at: new Date().toISOString(), print_count: (o.print_count || 0) + 1 }) });
}
export async function markResult(id: string, ok: boolean, code: string) {
  await sb("audit_log", { method: "POST", body: JSON.stringify({ entity_type: "order", entity_id: id, action: ok ? "PRINTED" : "PRINT_FAILED", actor: "stampante", details: { code } }) }).catch(() => {});
  if (!ok) await sb(`orders?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ printed_at: null }) }).catch(() => {}); // errore (carta finita...): si ristampa al prossimo giro
}
export async function touchPrinter(kind: string, ident: string, status: string) {
  await sb("settings", { method: "POST", headers: { Prefer: "resolution=merge-duplicates" }, body: JSON.stringify({ key: "printer_last_seen", value: { at: new Date().toISOString(), kind, ident: String(ident).slice(0, 80), status: String(status).slice(0, 80) }, updated_at: new Date().toISOString() }) }).catch(() => {});
}
function fmt(iso: string) { try { return new Intl.DateTimeFormat("it-IT", { timeZone: "Europe/Rome", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(iso)); } catch { return ""; } }
