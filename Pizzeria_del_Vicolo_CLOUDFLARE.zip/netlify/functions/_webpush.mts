/* Web Push senza librerie esterne (RFC 8291 + RFC 8292): senza dipendenze esterne a runtime. Usa solo il modulo crypto di Node. */
import { createECDH, hkdfSync, createCipheriv, randomBytes } from "node:crypto";

const b64u = (b: Buffer | Uint8Array) => Buffer.from(b).toString("base64url");
const fromB64u = (s: string) => Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");

/* Token VAPID firmato con Web Crypto (ES256).
   Cloudflare Workers supporta ECDSA P-256 via crypto.subtle.
   Evitiamo i KeyObject di node:crypto, che su Workers possono essere incompatibili
   con il percorso di firma usato dal runtime. */
function derToP1363(sig: Uint8Array): Uint8Array {
  if (sig.length === 64) return sig; // WebCrypto standard: r||s
  // Compatibilita' difensiva se un runtime restituisce DER SEQUENCE(INTEGER r, INTEGER s).
  let i = 0;
  if (sig[i++] !== 0x30) throw new Error("Firma ECDSA non valida");
  let seqLen = sig[i++];
  if (seqLen & 0x80) { let n = seqLen & 0x7f; seqLen = 0; while (n-- > 0) seqLen = (seqLen << 8) | sig[i++]; }
  const readInt = () => {
    if (sig[i++] !== 0x02) throw new Error("Firma ECDSA non valida");
    let len = sig[i++];
    if (len & 0x80) { const n0 = len & 0x7f; len = 0; for (let n = 0; n < n0; n++) len = (len << 8) | sig[i++]; }
    let v = sig.slice(i, i + len); i += len;
    while (v.length > 32 && v[0] === 0) v = v.slice(1);
    if (v.length > 32) throw new Error("Firma ECDSA troppo lunga");
    const out = new Uint8Array(32); out.set(v, 32 - v.length); return out;
  };
  const r = readInt(), s = readInt();
  const out = new Uint8Array(64); out.set(r, 0); out.set(s, 32); return out;
}

export async function vapidAuthHeader(endpoint: string, publicKey: string, privateKey: string, subject: string) {
  const d = fromB64u(privateKey);
  const ecdh = createECDH("prime256v1"); ecdh.setPrivateKey(d);
  const pub = ecdh.getPublicKey(); // 65 byte: 0x04 || x || y
  const jwk = { kty: "EC", crv: "P-256", d: b64u(d), x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)), ext: true };
  const key = await crypto.subtle.importKey("jwk", jwk as any, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const header = b64u(Buffer.from(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const payload = b64u(Buffer.from(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject })));
  const data = new TextEncoder().encode(`${header}.${payload}`);
  const rawSig = new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, data));
  const sig = derToP1363(rawSig);
  return `vapid t=${header}.${payload}.${b64u(sig)}, k=${publicKey}`;
}

/* Cifratura del messaggio per il browser (aes128gcm) */
export function encryptPayload(p256dh: string, auth: string, payload: string) {
  const uaPublic = fromB64u(p256dh), authSecret = fromB64u(auth);
  if (uaPublic.length !== 65 || authSecret.length !== 16) throw new Error("chiavi iscrizione non valide");
  const ecdh = createECDH("prime256v1"); ecdh.generateKeys();
  const asPublic = ecdh.getPublicKey(); const shared = ecdh.computeSecret(uaPublic);
  const info = Buffer.concat([Buffer.from("WebPush: info\0"), uaPublic, asPublic]);
  const ikm = Buffer.from(hkdfSync("sha256", shared, authSecret, info, 32));
  const salt = randomBytes(16);
  const cek = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: aes128gcm\0"), 16));
  const nonce = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: nonce\0"), 12));
  const cipher = createCipheriv("aes-128-gcm", cek, nonce);
  const plain = Buffer.concat([Buffer.from(payload, "utf8"), Buffer.from([2])]); // 0x02 = ultimo record
  const body = Buffer.concat([cipher.update(plain), cipher.final(), cipher.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPublic.length]), asPublic, body]);
}

export type PushResult = { ok: boolean; status: number; body: string };
export async function sendWebPush(sub: { endpoint: string; p256dh: string; auth: string }, payload: string, opts: { publicKey: string; privateKey: string; subject: string; ttl?: number; urgency?: "very-low" | "low" | "normal" | "high" }): Promise<PushResult> {
  const body = encryptPayload(sub.p256dh, sub.auth, payload);
  const r = await fetch(sub.endpoint, { method: "POST", headers: { Authorization: await vapidAuthHeader(sub.endpoint, opts.publicKey, opts.privateKey, opts.subject), "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", TTL: String(opts.ttl ?? 600), Urgency: opts.urgency || "normal", "Content-Length": String(body.length) }, body });
  return { ok: r.ok, status: r.status, body: await r.text().catch(() => "") };
}
