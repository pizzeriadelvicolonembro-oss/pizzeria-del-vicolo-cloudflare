/* Account dello staff salvati nel database: il proprietario li crea dal gestionale.
   La password (o PIN) non viene mai salvata in chiaro: si salva solo l'impronta PBKDF2-SHA256. */
import { sb } from "./_supabase.mts";
const enc = new TextEncoder();
const b64 = (b: ArrayBuffer | Uint8Array) => Buffer.from(b as any).toString("base64");

export async function hashPassword(password: string, saltB64?: string) {
  const salt = saltB64 ? Buffer.from(saltB64, "base64") : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  /* Cloudflare Workers WebCrypto rifiuta PBKDF2 oltre 100.000 iterazioni.
     Manteniamo 100.000 per creare/verificare gli account staff direttamente sul Worker. */
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" }, key, 256);
  return { salt: b64(salt), hash: b64(bits) };
}
export async function findDbUser(username: string, password: string) {
  const u = String(username || "").trim(); if (!u) return null;
  let rows: any[] = [];
  try { rows = await sb(`admin_users?username=ilike.${encodeURIComponent(u)}&active=is.true&select=id,username,role,pass_salt,pass_hash`); } catch { return null; }
  const row = rows?.[0]; if (!row) return null;
  const { hash } = await hashPassword(password, row.pass_salt);
  const a = enc.encode(hash), b = enc.encode(String(row.pass_hash || ""));
  if (a.length !== b.length) return null;
  let diff = 0; for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  if (diff !== 0) return null;
  sb(`admin_users?id=eq.${row.id}`, { method: "PATCH", body: JSON.stringify({ last_login_at: new Date().toISOString() }) }).catch(() => {});
  return { user: row.username, role: row.role === "OWNER" ? "OWNER" : "STAFF" };
}
export async function listUsers() { try { return await sb("admin_users?select=id,username,role,active,created_at,created_by,last_login_at&order=created_at.asc"); } catch { return []; } }
export async function createUser(username: string, password: string, role: string, by: string) {
  const u = String(username || "").trim().slice(0, 40);
  if (!/^[\p{L}\d _.-]{2,40}$/u.test(u)) throw new Error("Nome non valido (2–40 lettere o numeri)");
  if (String(password || "").length < 4) throw new Error("La password o il PIN deve avere almeno 4 caratteri");
  const { salt, hash } = await hashPassword(String(password));
  const payload = { username: u, role: role === "OWNER" ? "OWNER" : "STAFF", pass_salt: salt, pass_hash: hash, created_by: by, active: true };
  const rows = await sb("admin_users", { method: "POST", headers: { Prefer: "return=representation,resolution=merge-duplicates" }, body: JSON.stringify(payload) });
  return rows?.[0];
}
export async function setPassword(id: string, password: string) {
  if (String(password || "").length < 4) throw new Error("La password o il PIN deve avere almeno 4 caratteri");
  const { salt, hash } = await hashPassword(String(password));
  await sb(`admin_users?id=eq.${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify({ pass_salt: salt, pass_hash: hash }) });
}
export async function setActive(id: string, active: boolean) { await sb(`admin_users?id=eq.${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify({ active }) }); }
export async function deleteUser(id: string) { await sb(`admin_users?id=eq.${encodeURIComponent(id)}`, { method: "DELETE" }); }
