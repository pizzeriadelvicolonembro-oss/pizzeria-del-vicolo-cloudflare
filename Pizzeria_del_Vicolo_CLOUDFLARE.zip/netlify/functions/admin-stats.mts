/* Statistiche: oggi / settimana (da lunedì) / mese, in ora di Roma. Solo ordini non annullati.
   Prodotti più venduti: dagli order_items del periodo. */
import type { Config } from "@netlify/functions";
import { getSession } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
import pricing from "../../shared/pricing.js";
function startOf(kind: "today" | "week" | "month") {
  const p = pricing.romeParts(new Date()); const d = new Date(Date.UTC(p.y, p.m - 1, p.d));
  if (kind === "week") { const wd = (d.getUTCDay() + 6) % 7; d.setUTCDate(d.getUTCDate() - wd); }
  if (kind === "month") d.setUTCDate(1);
  return pricing.romeToUTC(d.toISOString().slice(0, 10), "00:00").toISOString();
}
export default async (req: Request) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  try {
    const out: any = { role: s.role, user: s.user };
    const monthStart = startOf("month"), weekStart = startOf("week"), todayStart = startOf("today");
    const rows = await sb(`orders?select=total_cents,status,created_at,fulfillment_type&created_at=gte.${monthStart}&limit=5000`);
    const sum = (from: string) => { const g = (rows || []).filter((x: any) => x.status !== "ANNULLATO" && x.created_at >= from); return { orders: g.length, revenue_cents: g.reduce((a: number, x: any) => a + Number(x.total_cents || 0), 0), delivery: g.filter((x: any) => x.fulfillment_type === "DELIVERY").length, cancelled: (rows || []).filter((x: any) => x.status === "ANNULLATO" && x.created_at >= from).length }; };
    out.today = sum(todayStart); out.week = sum(weekStart); out.month = sum(monthStart);
    if (s.role === "OWNER") {
      const items = await sb(`order_items?select=product_name,quantity,orders!inner(status,created_at)&orders.status=neq.ANNULLATO&orders.created_at=gte.${monthStart}&product_key=neq.omaggio&limit=10000`);
      const agg: Record<string, number> = {}; (items || []).forEach((it: any) => { const n = String(it.product_name).split(" + ")[0]; agg[n] = (agg[n] || 0) + Number(it.quantity || 0); });
      out.topProducts = Object.entries(agg).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([product_name, qty]) => ({ product_name, qty }));
    }
    return json(out);
  } catch (e) { console.error(e); return json({ error: "Statistiche non disponibili" }, 503); }
};
export const config: Config = { path: "/api/admin/stats" };
