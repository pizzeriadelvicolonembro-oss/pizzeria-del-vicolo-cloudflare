import type { Config } from "@netlify/functions";
import { makeSessionCookie, accounts, safeEqual } from "./_auth.mts";
import { findDbUser } from "./_users.mts";
export default async (req: Request) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { username, password } = await req.json().catch(() => ({}));
  if (typeof username !== "string" || typeof password !== "string") return Response.json({ error: "Dati mancanti" }, { status: 400 });
  /* prima gli account creati dal gestionale (database), poi quelli delle variabili Netlify */
  const dbUser = await findDbUser(username, password).catch(() => null);
  const acc = dbUser || accounts().find(a => a.user.toLowerCase() === username.trim().toLowerCase() && safeEqual(a.password, password));
  if (!acc) { await new Promise(r => setTimeout(r, 400)); return Response.json({ error: "Nome utente o password non validi" }, { status: 401 }); }
  return new Response(JSON.stringify({ ok: true, role: acc.role, user: acc.user }), {
    headers: { "content-type": "application/json", "set-cookie": await makeSessionCookie(acc.role as any, acc.user) }
  });
};
export const config: Config = { path: "/api/admin/login" };
