/* STAMPANTE CLOUD — protocollo Epson "Server Direct Print" (TM-m30III, TM-T88VII, ...).
   La stampante fa POST (form) a  /api/print-epson/<PRINT_KEY>  con ConnectionType=GetRequest:
   rispondiamo con l'XML ePOS-Print della comanda (o vuoto se non c'è nulla).
   Con ConnectionType=SetResponse ci manda l'esito della stampa (stesso indirizzo come "Response URL"). */
import { nextPrintJob, jobText, markDelivered, markResult, touchPrinter } from "./_print.mts";
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
export default async (req: Request, context: any) => {
  const key = (context?.params?.key || new URL(req.url).pathname.split("/").pop() || "").trim();
  const expected = (Netlify.env.get("PRINT_KEY") || "").trim();
  if (!expected || key !== expected) return new Response("Not found", { status: 404 });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  try {
    const raw = await req.text(); const form = new URLSearchParams(raw);
    const type = form.get("ConnectionType") || "GetRequest";
    await touchPrinter("epson", form.get("ID") || form.get("Name") || "", "");
    if (type === "SetResponse") {
      const xml = form.get("ResponseFile") || ""; const id = (xml.match(/<printjobid>([^<]+)<\/printjobid>/) || [])[1]; const ok = /success="true"/.test(xml);
      if (id) await markResult(id, ok, ok ? "OK" : xml.slice(0, 200));
      return new Response("", { status: 200 });
    }
    const job = await nextPrintJob();
    if (!job) return new Response("", { status: 200, headers: { "content-type": "text/xml; charset=utf-8" } });
    await markDelivered(job);
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<PrintRequestInfo Version="3.00">
 <ePOSPrint>
  <Parameter><devid>local_printer</devid><timeout>10000</timeout><printjobid>${esc(job.id)}</printjobid></Parameter>
  <PrintData>
   <epos-print xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print">
    <text lang="en"/><text smooth="true"/><text align="left"/>
    <text>${esc(jobText(job))}&#10;&#10;</text>
    <cut type="feed"/>
   </epos-print>
  </PrintData>
 </ePOSPrint>
</PrintRequestInfo>`;
    return new Response(xml, { status: 200, headers: { "content-type": "text/xml; charset=utf-8", "cache-control": "no-store" } });
  } catch (e) { console.error("print-epson:", e); return new Response("", { status: 200 }); }
};
