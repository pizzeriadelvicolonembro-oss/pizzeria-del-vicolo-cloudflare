/* Clienti: aggregati dagli ordini (telefono = identità). */
import { isAdmin } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
import { normPhone, GOAL } from "./_loyalty.mts";
export default async (req: Request) => {
  if (!(await isAdmin(req))) return json({ error: "Non autorizzato" }, 401);
  const u = new URL(req.url); const q = (u.searchParams.get("q") || "").trim().toLowerCase().slice(0, 60);
  try {
    const rows = await sb("orders?select=customer_name,customer_phone,customer_email,address_snapshot,total_cents,status,created_at&order=created_at.desc&limit=3000");
    const map: Record<string, any> = {};
    (rows || []).forEach((o: any) => {
      const key = String(o.customer_phone || "").replace(/\D/g, "") || o.customer_name; if (!key) return;
      const c = map[key] = map[key] || { phone: o.customer_phone, name: o.customer_name, email: o.customer_email, address: o.address_snapshot, orders: 0, spent_cents: 0, cancelled: 0, last_at: o.created_at };
      if (o.status === "ANNULLATO") c.cancelled++; else { c.orders++; c.spent_cents += Number(o.total_cents || 0); }
      if (!c.address && o.address_snapshot) c.address = o.address_snapshot;
    });
    /* tessera fedeltà */
    try {
      const custs = await sb("customers?select=id,phone&limit=5000"), accs = await sb("loyalty_accounts?select=customer_id,qualifying_count,available_credit_cents&limit=5000");
      const byId: Record<string, any> = {}; (accs || []).forEach((a: any) => { byId[a.customer_id] = a; });
      (custs || []).forEach((c: any) => { const a = byId[c.id]; const key = normPhone(c.phone); const target = map[key] || Object.values(map).find((m: any) => normPhone(m.phone) === key); if (a && target) Object.assign(target, { stamps: Number(a.qualifying_count) % GOAL, units_total: Number(a.qualifying_count), credit_cents: Number(a.available_credit_cents) }); });
    } catch (e) { console.error("loyalty customers:", e); }
    let list = Object.values(map);
    if (q) list = list.filter((c: any) => String(c.name).toLowerCase().includes(q) || String(c.phone).includes(q));
    list.sort((a: any, b: any) => b.last_at.localeCompare(a.last_at));
    return json({ customers: list.slice(0, 300) });
  } catch (e) { console.error(e); return json({ error: "Clienti non disponibili" }, 503); }
};
