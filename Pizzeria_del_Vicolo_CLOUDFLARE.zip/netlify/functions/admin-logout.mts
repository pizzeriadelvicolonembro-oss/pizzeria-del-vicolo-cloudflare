import type { Config } from "@netlify/functions";
import { clearAdminCookie } from "./_auth.mts";
export default async () => new Response(JSON.stringify({ ok: true }), { headers: { "content-type": "application/json", "set-cookie": clearAdminCookie() } });
export const config: Config = { path: "/api/admin/logout" };
