import { clearAdminCookie } from "./_auth.mts";
export default async () => new Response(JSON.stringify({ ok: true }), { headers: { "content-type": "application/json", "set-cookie": clearAdminCookie() } });
