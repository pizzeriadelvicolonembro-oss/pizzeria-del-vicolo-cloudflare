/* STAMPANTE CLOUD — protocollo Star CloudPRNT (mC-Print3, TSP143IV, ...).
   La stampante interroga ogni N secondi:  POST /api/print/<PRINT_KEY>  → { jobReady, mediaTypes }
   poi scarica la comanda:                 GET  /api/print/<PRINT_KEY>?type=text/plain&token=<id>
   e conferma la stampa:                   DELETE /api/print/<PRINT_KEY>?code=200%20OK&token=<id>
   Vengono stampati gli ordini non annullati, non ancora stampati, arrivati nelle ultime 3 ore. */
import { sb, json } from "./_supabase.mts";
import { nextPrintJob, jobText, markDelivered, markResult, touchPrinter } from "./_print.mts";

export default async (req: Request, context: Context) => {
  const key = (context?.params?.key || new URL(req.url).pathname.split("/").pop() || "").trim();
  const expected = (Netlify.env.get("PRINT_KEY") || "").trim();
  if (!expected || key !== expected) return new Response("Not found", { status: 404 });
  const u = new URL(req.url); const mac = u.searchParams.get("mac") || u.searchParams.get("uid") || "";
  try {
    if (req.method === "POST") {
      const st = await req.json().catch(() => ({}));
      await touchPrinter("star", mac || st.printerMAC || st.uniqueID || "", st.status || st.statusCode || "");
      const job = await nextPrintJob();
      return json(job ? { jobReady: true, mediaTypes: ["text/plain"], jobToken: job.id, deleteMethod: "DELETE" } : { jobReady: false, mediaTypes: ["text/plain"] });
    }
    if (req.method === "GET") {
      const token = u.searchParams.get("token") || ""; const type = u.searchParams.get("type") || "text/plain";
      const job = token ? await sb(`orders?id=eq.${encodeURIComponent(token)}&select=*`).then((r: any) => r?.[0]) : await nextPrintJob();
      if (!job) return new Response("", { status: 404 });
      await markDelivered(job);
      return new Response(jobText(job), { status: 200, headers: { "content-type": type.startsWith("text/plain") ? "text/plain; charset=utf-8" : type, "cache-control": "no-store" } });
    }
    if (req.method === "DELETE") {
      const token = u.searchParams.get("token") || ""; const code = u.searchParams.get("code") || "";
      if (token) await markResult(token, /200|OK/i.test(decodeURIComponent(code)), decodeURIComponent(code));
      return new Response("", { status: 200 });
    }
    return new Response("Method not allowed", { status: 405 });
  } catch (e) { console.error("print:", e); return json({ jobReady: false, mediaTypes: ["text/plain"] }); }
};
