/* Gestione account staff dal gestionale. Solo il proprietario.
   GET → elenco · POST {username,password,role} → crea · POST {id,password} → cambia password
   POST {id,active} → attiva/disattiva · DELETE {id} → elimina */
import { getSession } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
import { listUsers, createUser, setPassword, setActive, deleteUser } from "./_users.mts";
export default async (req: Request) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  if (s.role !== "OWNER") return json({ error: "Solo il proprietario può gestire gli account" }, 403);
  try {
    if (req.method === "GET") return json({ users: await listUsers() });
    const body = await req.json().catch(() => ({}));
    const target = async (id: string) => (await sb(`admin_users?id=eq.${encodeURIComponent(id)}&select=id,username,role,active`))?.[0];
    const protectOwner = async (id: string) => {
      const t = await target(id); if (!t) throw new Error("Account non trovato");
      if (String(t.username).toLowerCase() === String(s.user).toLowerCase()) throw new Error("Non puoi disattivare o eliminare l'account con cui sei entrato");
      if (t.role === "OWNER" && t.active) {
        const owners = await sb("admin_users?role=eq.OWNER&active=is.true&select=id");
        if ((owners || []).length <= 1) throw new Error("Deve restare almeno un proprietario attivo");
      }
      return t;
    };
    if (req.method === "DELETE") {
      if (!body.id) return json({ error: "Account mancante" }, 400);
      await protectOwner(body.id); await deleteUser(body.id); return json({ ok: true });
    }
    if (req.method === "POST") {
      if (body.id && typeof body.active === "boolean") {
        if (!body.active) await protectOwner(body.id);
        await setActive(body.id, body.active); return json({ ok: true });
      }
      if (body.id) { await setPassword(body.id, body.password); return json({ ok: true }); }
      const u = await createUser(body.username, body.password, body.role, s.user);
      return json({ ok: true, user: { id: u?.id, username: u?.username, role: u?.role } }, 201);
    }
    return new Response("Method not allowed", { status: 405 });
  } catch (e: any) { console.error(e); return json({ error: e?.message || "Errore account" }, 400); }
};
