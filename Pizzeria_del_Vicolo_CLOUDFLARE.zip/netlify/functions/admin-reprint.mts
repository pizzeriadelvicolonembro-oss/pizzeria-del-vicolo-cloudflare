/* Ristampa una comanda sulla stampante cloud (rimette l'ordine in coda). */
import { getSession } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
export default async (req: Request) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { id } = await req.json().catch(() => ({})); if (!id) return json({ error: "Ordine mancante" }, 400);
  try {
    const rows = await sb(`orders?id=eq.${encodeURIComponent(id)}&select=id,order_number`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ printed_at: null, reprint_requested_at: new Date().toISOString(), reprint_by: s.user }) });
    if (!rows?.[0]) return json({ error: "Ordine non trovato" }, 404);
    const seen = (await sb("settings?key=eq.printer_last_seen&select=value"))?.[0]?.value;
    return json({ ok: true, printerSeenAt: seen?.at || null });
  } catch (e) { console.error(e); return json({ error: "Errore ristampa" }, 500); }
};
