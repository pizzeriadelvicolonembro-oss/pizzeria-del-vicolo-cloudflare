/* Fasce orarie di una data con quanti ordini ci sono già (per mostrare "piena" al cliente). */
import { sb, json } from "./_supabase.mts";
import pricing from "../../shared/pricing.js";
export default async (req: Request) => {
  const u = new URL(req.url); const date = String(u.searchParams.get("date") || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return json({ error: "Data non valida" }, 400);
  const slots = pricing.slotsFor(date, new Date());
  let capacity: number | null = null; const counts: Record<string, number> = {};
  try {
    const rows = await sb("settings?key=eq.slot_capacity&select=value"); const v = Number(rows?.[0]?.value?.n); capacity = Number.isFinite(v) && v > 0 ? v : null;
    if (capacity && slots.length) {
      const from = pricing.romeToUTC(date, slots[0]).toISOString(), to = new Date(pricing.romeToUTC(date, slots[slots.length - 1]).getTime() + pricing.SLOT_MINUTES * 60_000).toISOString();
      const orders = await sb(`orders?select=requested_at&status=neq.ANNULLATO&requested_at=gte.${from}&requested_at=lt.${to}&limit=1000`);
      (orders || []).forEach((o: any) => { const p = pricing.romeParts(new Date(o.requested_at)); const m = Math.floor(p.mins / pricing.SLOT_MINUTES) * pricing.SLOT_MINUTES; const k = `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`; counts[k] = (counts[k] || 0) + 1; });
    }
  } catch (e) { console.error("slots:", e); }
  return json({ date, slots: slots.map(t => ({ t, full: !!capacity && (counts[t] || 0) >= capacity })), capacity, minLeadMinutes: pricing.MIN_LEAD_MINUTES });
};
