/* Sessione del gestionale: cookie firmato HMAC. Account definiti nelle variabili Netlify.
   Formato consigliato:  ACCOUNTS = "Rizwan:OWNER:password1;Zeeshan:OWNER:password2;Mario:STAFF:password3"
   Compatibilità: OWNER_USERNAME/OWNER_PASSWORD e STAFF_USERNAME/STAFF_PASSWORD continuano a funzionare. */
const enc = new TextEncoder();
const COOKIE = "vicolo_session";
export type Role = "OWNER" | "STAFF";
export type Session = { role: Role; user: string; exp: number };
export type Account = { user: string; role: Role; password: string };

export function accounts(): Account[] {
  const out: Account[] = [];
  const raw = Netlify.env.get("ACCOUNTS") || "";
  raw.split(";").map(s => s.trim()).filter(Boolean).forEach(entry => {
    const [user, role, ...rest] = entry.split(":"); const password = rest.join(":");
    if (user && (role === "OWNER" || role === "STAFF") && password) out.push({ user: user.trim(), role, password });
  });
  const owner = Netlify.env.get("OWNER_PASSWORD") || Netlify.env.get("ADMIN_PASSWORD");
  if (owner) out.push({ user: (Netlify.env.get("OWNER_USERNAME") || "Rizwanzeeshan").trim(), role: "OWNER", password: owner });
  const staff = Netlify.env.get("STAFF_PASSWORD");
  if (staff) out.push({ user: (Netlify.env.get("STAFF_USERNAME") || "Staff").trim(), role: "STAFF", password: staff });
  return out;
}
function secret() {
  return Netlify.env.get("ADMIN_SESSION_SECRET") || Netlify.env.get("OWNER_PASSWORD") || Netlify.env.get("ADMIN_PASSWORD") || accounts()[0]?.password || "";
}
function b64url(bytes: Uint8Array) { return Buffer.from(bytes).toString("base64url"); }
async function hmac(value: string, key: string) {
  const k = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64url(new Uint8Array(await crypto.subtle.sign("HMAC", k, enc.encode(value))));
}
export async function makeSessionCookie(role: Role, user: string) {
  const s = secret(); if (!s) throw new Error("Nessun account configurato");
  /* Durata sessione: 30 giorni (SESSION_DAYS su Netlify per cambiarla). Il tablet della pizzeria non deve rifare il login ogni giorno;
     "Esci" nel gestionale la chiude subito. */
  const days = Math.min(365, Math.max(1, Number(Netlify.env.get("SESSION_DAYS") || 30)));
  const exp = Math.floor(Date.now() / 1000) + 60 * 60 * 24 * days;
  const payload = `${role}.${encodeURIComponent(user)}.${exp}`;
  return `${COOKIE}=${payload}.${await hmac(payload, s)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${60 * 60 * 24 * days}`;
}
export async function getSession(req: Request): Promise<Session | null> {
  const s = secret(); if (!s) return null;
  const raw = (req.headers.get("cookie") || "").split(/;\s*/).find(x => x.startsWith(COOKIE + "="))?.slice(COOKIE.length + 1);
  if (!raw) return null;
  const parts = raw.split("."); if (parts.length !== 4) return null;
  const role = parts[0] as Role; if (role !== "OWNER" && role !== "STAFF") return null;
  const exp = Number(parts[2]); if (!Number.isFinite(exp) || exp < Math.floor(Date.now() / 1000)) return null;
  const payload = `${parts[0]}.${parts[1]}.${parts[2]}`;
  if ((await hmac(payload, s)) !== parts[3]) return null;
  return { role, user: decodeURIComponent(parts[1]), exp };
}
export async function isAdmin(req: Request) { return !!(await getSession(req)); }
export async function isOwner(req: Request) { return (await getSession(req))?.role === "OWNER"; }
export function clearAdminCookie() { return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`; }
export function safeEqual(a: string, b: string) {
  const x = enc.encode(a), y = enc.encode(b); if (x.length !== y.length) return false;
  let d = 0; for (let i = 0; i < x.length; i++) d |= x[i] ^ y[i]; return d === 0;
}
