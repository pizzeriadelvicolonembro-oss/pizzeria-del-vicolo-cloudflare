/* Impostazioni: capacità per fascia (ordini ogni 15 minuti; vuoto = nessun limite). Solo il proprietario modifica. */
import { getSession } from "./_auth.mts";
import { sb, json } from "./_supabase.mts";
export default async (req: Request) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  try {
    if (req.method === "GET") {
      const rows = await sb("settings?select=key,value"); const o: any = {}; (rows || []).forEach((r: any) => { o[r.key] = r.value; });
      const key = (Netlify.env.get("PRINT_KEY") || "").trim(); const base = (Netlify.env.get("SITE_URL") || Netlify.env.get("URL") || "").replace(/\/$/, "");
      const printer = { configured: !!key, urlStar: key && s.role === "OWNER" ? `${base}/api/print/${key}` : null, urlEpson: key && s.role === "OWNER" ? `${base}/api/print-epson/${key}` : null, lastSeen: o.printer_last_seen || null };
      return json({ settings: o, role: s.role, printer });
    }
    if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
    if (s.role !== "OWNER") return json({ error: "Solo il proprietario può modificare le impostazioni" }, 403);
    const { slotCapacity } = await req.json().catch(() => ({}));
    const n = slotCapacity === null || slotCapacity === "" ? null : Number(slotCapacity);
    if (n !== null && (!Number.isInteger(n) || n < 1 || n > 100)) return json({ error: "Capacità non valida (1–100 o vuoto)" }, 400);
    await sb("settings", { method: "POST", headers: { Prefer: "resolution=merge-duplicates" }, body: JSON.stringify({ key: "slot_capacity", value: { n }, updated_by: s.user, updated_at: new Date().toISOString() }) });
    sb("audit_log", { method: "POST", body: JSON.stringify({ entity_type: "settings", action: "SLOT_CAPACITY", actor: s.user, details: { n } }) }).catch(() => {});
    return json({ ok: true, slotCapacity: n });
  } catch (e) { console.error(e); return json({ error: "Impostazioni non disponibili" }, 503); }
};
