# Passare a Cloudflare Pages — guida passo passo

Il pacchetto contiene **entrambe** le versioni: `netlify/` (vecchia) e `functions/` (Cloudflare).
Non serve toccare Supabase: il database resta dov'è.

## 1) Crea il progetto
1. Vai su **dash.cloudflare.com** → **Workers & Pages** → **Create** → **Pages** → **Upload assets**
2. Nome progetto: `pizzeria-del-vicolo`
3. Trascina lo **zip** (o la cartella scompattata) → **Deploy site**

## 2) Metti le variabili
Nel progetto → **Settings** → **Variables and Secrets** → aggiungi (tipo *Secret* per le chiavi):

| Nome | Valore |
|---|---|
| SUPABASE_URL | https://ilvdxzkdfelmtkuvugoj.supabase.co |
| SUPABASE_SECRET_KEY | (la stessa di Netlify) |
| ADMIN_SESSION_SECRET | (la stessa di Netlify) |
| ACCOUNTS | Rizwan:OWNER:… ecc. |
| SITE_URL | https://pizzeriavicolo.it |
| VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY / VAPID_SUBJECT | (le stesse) |
| RESEND_API_KEY | (la stessa) |
| NOTIFY_FROM | Pizzeria del Vicolo <ordini@pizzeriavicolo.it> |
| NOTIFY_EMAILS | le tre email |
| PRINT_KEY | stampante-x7q2m9 |
| **CRON_KEY** | **inventane una nuova, lunga** (serve al punto 4) |

Dopo averle messe: **Deployments → Retry deployment**, se no non le legge.

## 3) Sposta il dominio
1. In Cloudflare: **Custom domains** → **Set up a custom domain** → `pizzeriavicolo.it`
2. Cloudflare ti dà **due nameserver** (tipo `xxx.ns.cloudflare.com`)
3. Su **GoDaddy** → pizzeriavicolo.it → **Nameserver** → **Cambia** → metti quei due
4. Aspetta da 10 minuti a qualche ora. I record di Resend vanno **ricopiati** in Cloudflare
   (DNS → Add record): il TXT `resend._domainkey`, l'MX `send`, il TXT `send`, il CNAME `rsend`.

## 4) Il promemoria ordini non accettati
Cloudflare Pages non ha il cron. Usa **cron-job.org** (gratis):
1. Registrati, **Create cronjob**
2. URL: `https://pizzeriavicolo.it/api/cron/escalation?key=LA_TUA_CRON_KEY`
3. Ogni **3 minuti**, solo dalle 11:00 alle 23:00
4. Salva ed **Enable**

Senza questo il sistema funziona lo stesso: manca solo il sollecito automatico
se nessuno accetta un ordine.

## 5) Prova finale
- Apri pizzeriavicolo.it e fai un ordine finto
- Guarda che arrivi l'email e che compaia nel gestionale
- Sul tablet: **ATTIVA PUSH** e **SUONO** (vanno rifatti, il dominio è lo stesso ma l'app si reinstalla)

## Cosa cambia rispetto a Netlify
- Traffico **illimitato** (Netlify lo limitava: per quello si era spento)
- 100.000 chiamate al giorno per le funzioni: tu ne fai circa 3.000
- Le notifiche push sono state riscritte con la crittografia standard: funzionano su entrambi
