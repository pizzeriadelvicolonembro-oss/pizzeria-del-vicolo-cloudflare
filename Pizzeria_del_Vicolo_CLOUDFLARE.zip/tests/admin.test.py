"""Test del gestionale in un browser headless con API finte.  python3 tests/admin.test.py"""
import json, re, subprocess, sys, time
from playwright.sync_api import sync_playwright
ROOT = "/home/claude/vicolo"

now = time.time()
def iso(offset_s): return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now + offset_s))
orders = [
  {"id": "o1", "order_number": "V260918-AB12", "status": "NUOVO", "fulfillment_type": "DELIVERY", "payment_method": "Contanti", "total_cents": 2300, "created_at": iso(-240), "requested_at": iso(1800), "confirmed_at": None, "delay_minutes": 0,
   "customer_name": "Anna Rossi", "customer_phone": "3331234567", "address_snapshot": "Via Roma 1, Scanzorosciate", "notes": "citofono rotto", "promo_snapshot": {"lunch": True}, "ticket_text": "PIZZERIA DEL VICOLO — ORDINE V260918-AB12\n2x Margherita",
   "order_items": [{"product_name": "Margherita", "quantity": 2, "effective_unit_cents": 700, "modifiers": [], "item_notes": None}, {"product_name": "Lattina 33cl Fanta (OMAGGIO)", "quantity": 1, "effective_unit_cents": 0, "modifiers": [], "item_notes": None}]},
  {"id": "o2", "order_number": "V260918-CD34", "status": "NUOVO", "fulfillment_type": "PICKUP", "payment_method": "POS", "total_cents": 1500, "created_at": iso(-30), "requested_at": iso(3 * 3600), "confirmed_at": None, "delay_minutes": 0,
   "customer_name": "Carlo Bianchi", "customer_phone": "3489876543", "address_snapshot": None, "notes": None, "promo_snapshot": {}, "ticket_text": "ORDINE V260918-CD34", "order_items": [{"product_name": "Capricciosa", "quantity": 1, "effective_unit_cents": 600, "modifiers": [], "item_notes": "ben cotta"}]},
  {"id": "o3", "order_number": "V260918-EF56", "status": "PRONTO", "fulfillment_type": "DELIVERY", "payment_method": "Contanti", "total_cents": 2000, "created_at": iso(-3600), "requested_at": iso(-1800), "confirmed_at": iso(-1500), "delay_minutes": 0, "accepted_by": "Mario",
   "customer_name": "Dario Neri", "customer_phone": "3405556677", "address_snapshot": "Via Verdi 4", "notes": None, "promo_snapshot": {}, "ticket_text": "ORDINE V260918-EF56", "order_items": []},
]
session = {"logged": False}; posted = []
def handle(route, request):
    url = request.url; p = url.split("/api/")[1]; m = request.method
    def J(data, status=200): return route.fulfill(status=status, content_type="application/json", body=json.dumps(data))
    if p.startswith("admin/login"):
        b = json.loads(request.post_data)
        if b["username"] == "Rizwan" and b["password"] == "pw": session["logged"] = True; return J({"ok": True, "role": "OWNER", "user": "Rizwan"})
        return J({"error": "Nome utente o password non validi"}, 401)
    if not session["logged"]: return J({"error": "Non autorizzato"}, 401)
    if p.startswith("admin/me"): return J({"role": "OWNER", "user": "Rizwan", "exp": 0})
    if p.startswith("admin/orders"):
        q = re.search(r"[?&]q=([^&]*)", url); scope = re.search(r"scope=(\w+)", url)
        if q and q.group(1): term = q.group(1).lower(); return J({"orders": [o for o in orders if term in o["customer_name"].lower() or term in o["order_number"].lower()]})
        sc = scope.group(1) if scope else "active"
        if sc == "active": return J({"orders": [o for o in orders if o["status"] not in ("COMPLETATO", "ANNULLATO")]})
        if sc == "history": return J({"orders": [o for o in orders if o["status"] in ("COMPLETATO", "ANNULLATO")]})
        return J({"orders": orders})
    if p.startswith("admin/order-status"):
        b = json.loads(request.post_data); posted.append(b); o = next(x for x in orders if x["id"] == b["id"])
        allowed = {"NUOVO": ["ACCETTATO", "ANNULLATO"], "ACCETTATO": ["IN_PREPARAZIONE", "PRONTO", "ANNULLATO"], "IN_PREPARAZIONE": ["PRONTO", "ANNULLATO"], "PRONTO": ["IN_CONSEGNA", "COMPLETATO", "ANNULLATO"], "IN_CONSEGNA": ["COMPLETATO", "ANNULLATO"]}
        if b["status"] not in allowed.get(o["status"], []): return J({"error": "transizione vietata"}, 409)
        if b["status"] == "ANNULLATO" and len(b.get("reason", "")) < 3: return J({"error": "Motivo annullamento obbligatorio"}, 400)
        o["status"] = b["status"]
        if b["status"] == "ACCETTATO": o["accepted_by"] = "Rizwan"; o["delay_minutes"] = b.get("delayMinutes", 0); o["confirmed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.mktime(time.strptime(o["requested_at"], "%Y-%m-%dT%H:%M:%SZ")) - time.timezone + o["delay_minutes"] * 60))
        if b["status"] == "ANNULLATO": o["cancellation_reason"] = b["reason"]; o["cancelled_by"] = "Rizwan"
        return J({"ok": True})
    if p.startswith("admin/stats"): return J({"role": "OWNER", "today": {"orders": 2, "revenue_cents": 3800, "delivery": 1, "cancelled": 0}, "week": {"orders": 9, "revenue_cents": 21000, "delivery": 4, "cancelled": 1}, "month": {"orders": 30, "revenue_cents": 70000, "delivery": 12, "cancelled": 2}, "topProducts": [{"product_name": "Margherita", "qty": 14}]})
    if p.startswith("admin/customers"): return J({"customers": [{"name": "Anna Rossi", "phone": "3331234567", "orders": 3, "spent_cents": 6900, "cancelled": 0, "address": "Via Roma 1", "last_at": iso(0)}]})
    if p.startswith("admin/settings"):
        if m == "POST": posted.append(json.loads(request.post_data)); return J({"ok": True, "slotCapacity": 6})
        return J({"settings": {"slot_capacity": {"n": None}}, "role": "OWNER"})
    if p.startswith("admin/notifications"): return J({"log": [{"channel": "push", "recipient": "tablet", "status": "SENT", "created_at": iso(-100), "last_error": None}], "subscriptions": []})
    if p.startswith("admin/push"): return J({"publicKey": None, "configured": False})
    return J({"error": "no route " + p}, 404)

def ensure_open(pg, oid):
    if pg.locator(f"#ord-{oid} .ordBody.hidden").count(): pg.click(f"#ord-{oid} .chevBtn"); pg.wait_for_timeout(300)

passed = 0
def ok(name, cond):
    global passed
    if not cond: raise SystemExit("FAIL: " + name)
    passed += 1; print("  ✓", name)
srv = subprocess.Popen([sys.executable, "-m", "http.server", "8766", "--bind", "127.0.0.1"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(0.8)
with sync_playwright() as pw:
    b = pw.chromium.launch(); ctx = b.new_context(viewport={"width": 820, "height": 1100}); pg = ctx.new_page(); errors = []; pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.route("**/api/**", handle)
    pg.goto("http://127.0.0.1:8766/admin/index.html"); pg.wait_for_timeout(400)
    ok("schermata login visibile", pg.locator("#loginBox").is_visible() and pg.locator("#app").is_hidden())
    pg.fill("#username", "Rizwan"); pg.fill("#password", "sbagliata"); pg.click("text=ENTRA"); pg.wait_for_timeout(300)
    ok("password errata → messaggio", "non validi" in pg.inner_text("#loginError"))
    pg.fill("#password", "pw"); pg.press("#password", "Enter"); pg.wait_for_timeout(800)
    ok("login ok: ruolo e nome in alto, barra in basso", pg.locator("#app").is_visible() and "PROPRIETARIO" in pg.inner_text("#role") and pg.locator("#bottom").is_visible())
    txt = pg.inner_text("#orders")
    ok("una tabella sola con tutti gli ordini e il timer su ogni riga", "V260918-AB12" in txt and "V260918-CD34" in txt and "programmato" in txt.lower() and pg.locator(".timer").count() >= 3)
    ok("contatori: NUOVI 2, badge 2, titolo con allarme", pg.inner_text("#newCount") == "2" and pg.inner_text("#cntNuovi") == "2" and "NUOVI ORDINI" in pg.title())
    ok("riga chiusa: numero, cliente, anteprima prodotti, niente scontrino", "V260918-AB12" in txt and "Anna Rossi" in txt and "2× Margherita" in txt and "PIZZERIA DEL VICOLO" not in txt and pg.locator(".ordBody.hidden").count() >= 1)
    ok("freccia e menu ⋮ su ogni riga", pg.locator(".chevBtn").count() == pg.locator(".ord").count() and pg.locator(".dots").count() == pg.locator(".ord").count())
    pg.click("#ord-o1 .chevBtn"); pg.wait_for_timeout(300); txt = pg.inner_text("#orders")
    ok("tocco sull'ordine: si apre il dettaglio con orari, cliente e scontrino", "Ricevuto" in txt and "Richiesto" in txt and "Anna Rossi" in txt and "Margherita" in txt)
    pg.click("#ord-o1 .chevBtn"); pg.wait_for_timeout(300)
    ok("secondo tocco: si richiude", pg.locator("#ord-o1 .ordBody.hidden").count() == 1)
    pg.click("text=✓ ACCETTA"); pg.wait_for_timeout(200)
    ok("ACCETTA: compare l'orario con la freccina, gli orari sono nascosti", pg.locator("#times-o1.hidden").count() == 1 and pg.locator("#ord-o1 .selTime").count() == 1)
    pg.click("#ord-o1 .selTime"); pg.wait_for_timeout(200)
    ok("tocco la freccina: si aprono OK/+15/+30/+45/+60 e l'orologio", pg.locator("#times-o1.hidden").count() == 0 and pg.locator("#times-o1 .delays button").count() == 5 and pg.locator("#t-o1").count() == 1)
    pg.click("#times-o1 .delays button:has-text('+30')"); pg.wait_for_timeout(200)
    ok("scelgo +30: gli orari si richiudono, resta scritto l'orario scelto, l'ordine NON è ancora accettato", pg.locator("#times-o1.hidden").count() == 1 and "(+30)" in pg.inner_text("#sel-o1") and not any(p.get("status") == "ACCETTATO" for p in posted))
    pg.click("#ord-o1 .confirmBtn"); pg.wait_for_timeout(700)
    ok("POST ACCETTATO con delayMinutes 30", posted[-1] == {"id": "o1", "status": "ACCETTATO", "delayMinutes": 30})
    ok("il contatore NUOVI scende a 1", pg.inner_text("#newCount") == "1")
    ok("dopo l'accettazione l'ordine resta nella stessa tabella con lo stato scritto sotto", "V260918-AB12" in pg.inner_text("#orders") and pg.locator("#ord-o1 .stato").inner_text().strip().endswith("ACCETTATO"))
    ok("un solo pulsante grande: il passo successivo", pg.locator("#ord-o1 .quick button").count() == 1 and "IN PREPARAZIONE" in pg.locator("#ord-o1 .quick button").inner_text())
    pg.wait_for_timeout(300); ensure_open(pg, "o1"); txt = pg.inner_text("#orders")
    ok("aperto: mostra accettato da Rizwan e orario confermato +30", "Accettato da Rizwan" in txt and "(+30 min)" in txt)
    pg.click("#ord-o1 .quick button"); pg.wait_for_timeout(900)
    pg.click("#ord-o1 .quick button"); pg.wait_for_timeout(1000)
    pg.wait_for_timeout(400)
    ok("stato PRONTO e pulsante IN CONSEGNA (è una consegna)", pg.locator("#ord-o1 .stato").inner_text().strip().endswith("PRONTO") and "IN CONSEGNA" in pg.locator("#ord-o1 .quick button").inner_text())
    pg.click("#ord-o1 .quick button"); pg.wait_for_timeout(1000)
    ok("stato IN CONSEGNA e pulsante CONSEGNATO", pg.locator("#ord-o1 .stato").inner_text().strip().endswith("IN CONSEGNA") and "CONSEGNATO" in pg.locator("#ord-o1 .quick button").inner_text())
    pg.click("#ord-o2 .dots"); pg.wait_for_timeout(400)
    ok("menu ⋮: condividi foto, stampa, ristampa, chiama, whatsapp, rifiuta", all(x in pg.inner_text("#menuBox") for x in ["Condividi comanda", "Stampa comanda", "Ristampa", "Chiama", "WhatsApp", "Rifiuta"]))
    pg.once("dialog", lambda d: d.accept("Troppi ordini"))
    pg.click("#menuBox button:has-text('Rifiuta')"); pg.wait_for_timeout(900)
    ok("annulla con motivo", posted[-1]["status"] == "ANNULLATO" and posted[-1]["reason"] == "Troppi ordini")
    pg.click("[data-page='More']"); pg.wait_for_timeout(300); pg.click("[data-page='Orders']"); pg.wait_for_timeout(1500)
    ensure_open(pg, "o2"); txt = pg.inner_text("#orders")
    ok("l'annullato resta nella stessa tabella, in fondo, con il motivo", "Troppi ordini" in txt and "V260918-CD34" in txt and pg.locator("#ord-o2.done").count() == 1)
    pg.fill("#search", "anna"); pg.wait_for_timeout(900)
    ok("ricerca 'anna'", "V260918-AB12" in pg.inner_text("#orders") and "V260918-CD34" not in pg.inner_text("#orders"))
    pg.fill("#search", ""); pg.wait_for_timeout(500)
    pg.wait_for_timeout(500); txt = pg.inner_text("#orders")
    ok("RITARDO: riga lampeggiante con minuti e contatore in alto", "IN RITARDO DI" in txt and pg.locator(".ord.lateOrder").count() >= 1 and int(pg.inner_text("#lateCount")) >= 1 and pg.locator("#lateCard.lateCard").count() == 1)
    pg.fill("#search", ""); pg.wait_for_timeout(500)
    pg.click("[data-page='Stats']"); pg.wait_for_timeout(400); txt = pg.inner_text("#stats")
    ok("DATI: oggi/settimana/mese + più venduti", "38,00" in txt and "210,00" in txt and "700,00" in txt and "Margherita" in txt)
    pg.click("[data-page='Customers']"); pg.wait_for_timeout(400)
    ok("CLIENTI elencati con timbri", "Anna Rossi" in pg.inner_text("#customers") and "3 ordini" in pg.inner_text("#customers") and "timbri" in pg.inner_text("#customers"))
    pg.click("[data-page='More']"); pg.wait_for_timeout(500); txt = pg.inner_text("#settings")
    ok("ALTRO: push, stampante, telegram, capacità, registro", "ATTIVA PUSH QUI" in txt and "Stampante cloud" in txt and "Telegram" in txt and pg.locator("#capInput").count() == 1 and "SENT" in txt)
    pg.fill("#capInput", "6"); pg.click("text=SALVA"); pg.wait_for_timeout(400)
    ok("capacità salvata", posted[-1] == {"slotCapacity": 6})
    pg.click("[data-page='Orders']"); pg.wait_for_timeout(300)
    pg.click(".chipStat:has-text('RITARDO')"); pg.wait_for_timeout(600)
    ok("riquadro RITARDO: filtra la lista e mostra il filtro attivo", "IN RITARDO DI" in pg.inner_text("#orders") and "mostra tutti" in pg.inner_text("#subFilter"))
    pg.click("#subFilter button"); pg.wait_for_timeout(400)
    ok("tolto il filtro: tornano tutti gli ordini in corso", pg.locator("#subFilter.hidden").count() == 1 and "V260918-EF56" in pg.inner_text("#orders"))
    pg.click("[data-page='Orders']"); pg.wait_for_timeout(400)
    pg.click("#ord-o3 .dots"); pg.wait_for_timeout(400)
    pg.once("download", lambda d: None)
    pg.click("#menuBox button:has-text('Condividi')"); pg.wait_for_timeout(1200)
    dims = pg.evaluate("(()=>{const o=[...active,...today,...history].find(x=>x.id==='o3');const c=ticketCanvas(o);return [c.width,c.height];})()")
    ok("condividi comanda: crea davvero l'immagine della comanda", dims[0] >= 1000 and dims[1] >= 100)
    ok("service worker registrato", pg.evaluate("navigator.serviceWorker.getRegistrations().then(r=>r.length)") >= 1)
    ok("nessun errore JS", errors == [])
    pg.click("[data-page='Orders']"); pg.wait_for_timeout(300); pg.screenshot(path="/tmp/admin_old_style.png", clip={"x": 0, "y": 0, "width": 820, "height": 1000})
    b.close()
srv.terminate()
print(f"\nTUTTI I TEST SUPERATI: {passed}")
