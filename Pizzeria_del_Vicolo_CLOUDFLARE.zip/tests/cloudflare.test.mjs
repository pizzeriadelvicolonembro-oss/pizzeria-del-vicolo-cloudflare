/* Verifica che la versione Cloudflare sia completa e che i gestori rispondano davvero:
   stesse regole della versione Netlify, ma con le variabili passate nel contesto. */
import fs from "node:fs"; import path from "node:path";
let pass = 0; const ok = (n, c) => { if (!c) throw new Error("FAIL: " + n); pass++; console.log("  ✓", n); };

const netDir = "netlify/functions", cfDir = "functions";
const routes = fs.readdirSync(netDir).filter(f => f.endsWith(".mts") && !f.startsWith("_"))
  .map(f => { const s = fs.readFileSync(path.join(netDir, f), "utf8"); const m = s.match(/path:\s*"([^"]+)"/); return { f, path: m ? m[1] : "/api/cron/escalation" }; });

/* 1. ogni rotta Netlify ha il suo file su Cloudflare */
const missing = routes.filter(r => {
  const p = r.path.replace(/^\//, "").replace(/:(\w+)/g, "[$1]") + ".ts";
  return !fs.existsSync(path.join(cfDir, p));
});
ok(`tutte le ${routes.length} rotte presenti anche su Cloudflare`, missing.length === 0);
ok("moduli condivisi copiati (_lib)", ["_auth", "_supabase", "_notify", "_print", "_loyalty", "_users", "_webpush", "env"].every(m => fs.existsSync(`${cfDir}/_lib/${m}.ts`)));

/* 2. niente codice che su Cloudflare non esiste */
const bad = [];
for (const f of fs.readdirSync(`${cfDir}/_lib`)) {
  const s = fs.readFileSync(`${cfDir}/_lib/${f}`, "utf8");
  if (/\bBuffer\b/.test(s)) bad.push(`${f}: Buffer`);
  if (/require\(|from "node:/.test(s)) bad.push(`${f}: modulo Node`);
  if (/Netlify\.env/.test(s)) bad.push(`${f}: Netlify.env`);
}
ok("nessun modulo Node o Buffer o Netlify.env nei moduli condivisi", bad.length === 0 || (() => { console.log(bad); return false; })());

/* 3. i file di configurazione Cloudflare ci sono */
ok("_headers, _routes.json e wrangler.toml presenti", ["_headers", "_routes.json", "wrangler.toml"].every(f => fs.existsSync(f)));
ok("le immagini restano in cache un anno", fs.readFileSync("_headers", "utf8").includes("max-age=31536000"));
ok("il gestionale resta fuori da Google", fs.readFileSync("_headers", "utf8").includes("X-Robots-Tag: noindex"));

/* 4. i gestori rispondono: prova vera su slots e login */
const env = { SUPABASE_URL: "https://x.test", SUPABASE_SECRET_KEY: "k", ADMIN_SESSION_SECRET: "s".repeat(32), ACCOUNTS: "Rizwan:OWNER:pw", SITE_URL: "https://pizzeriavicolo.it", CRON_KEY: "segreto" };
const call = async (file, url, init = {}, params = {}) => {
  const mod = await import("../" + file + "?v=" + Math.random());   /* Node risolve gli import senza estensione come fa Cloudflare */
  return mod.onRequest({ request: new Request(url, init), env, params });
};
let r = await call("functions/api/slots.ts", "https://x/api/slots?date=2026-09-25");
ok("/api/slots risponde con le fasce orarie", r.status === 200 && Array.isArray((await r.json()).slots));

r = await call("functions/api/admin/login.ts", "https://x/api/admin/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ username: "Rizwan", password: "sbagliata" }) });
ok("/api/admin/login rifiuta la password sbagliata", r.status === 401);

r = await call("functions/api/cron/escalation.ts", "https://x/api/cron/escalation");
ok("la escalation senza chiave risponde 404", r.status === 404);
r = await call("functions/api/cron/escalation.ts", "https://x/api/cron/escalation?key=sbagliata");
ok("la escalation con chiave sbagliata risponde 404", r.status === 404);

console.log(`\nTUTTI I TEST SUPERATI: ${pass}`);
