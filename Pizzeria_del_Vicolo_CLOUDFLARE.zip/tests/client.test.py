"""Test del sito cliente in un browser headless con API finte.  python3 tests/client.test.py"""
import json, re, subprocess, sys
from playwright.sync_api import sync_playwright

ROOT = "/home/claude/vicolo"
def node(js):
    return json.loads(subprocess.check_output(["node", "-e", f'const P=require("{ROOT}/shared/pricing.js");process.stdout.write(JSON.stringify((()=>{{{js}}})()))']).decode())

# date utili (ora di Roma): primo giorno mar-ven con pranzo disponibile, primo lun-gio con sera disponibile
info = node("""
const dates=P.nextDates(new Date(),8); const out={dates};
for(const d of dates){const wd=P.weekdayOf(d); const sl=P.slotsFor(d); if(!out.lunch && [2,3,4,5].includes(wd) && sl.includes('12:30')) out.lunch=d; if(!out.evening && [1,2,3,4].includes(wd) && sl.includes('19:30')) out.evening=d; if(!out.weekend && [5,6,0].includes(wd) && sl.includes('20:00')) out.weekend=d;}
return out;""")
print("date di test:", info)

state = {"orders": [], "status": {}, "slotFull": False, "loyaltyReady": False, "loyaltyCalls": 0}
def handle(route, request):
    url = request.url; p = url.split("/api/")[1]
    if p.startswith("slots"):
        date = url.split("date=")[1]
        slots = node(f"return P.slotsFor('{date}').map(t=>({{t,full:false}}))")
        return route.fulfill(status=200, content_type="application/json", body=json.dumps({"date": date, "slots": slots, "capacity": None, "minLeadMinutes": 20}))
    if p.startswith("orders"):
        body = json.loads(request.post_data)
        if state["slotFull"]:
            state["slotFull"] = False
            return route.fulfill(status=409, content_type="application/json", body=json.dumps({"error": "Questa fascia oraria è piena: scegli un altro orario", "slotFull": True}))
        n = f"V2609-TST{len(state['orders'])+1}"
        order = {"id": "x", "order_number": n, "status": "NUOVO", "requested_at": body["requestedAt"], "total_cents": round(body["clientTotal"]*100), "fulfillment_type": body["fulfillmentType"], "created_at": "2026-09-18T10:00:00Z", "ticket_text": "PIZZERIA DEL VICOLO — ORDINE " + n + "\n1x Margherita + Bufala"}
        state["orders"].append(body); state["status"][n] = dict(order)
        return route.fulfill(status=201, content_type="application/json", body=json.dumps({"order": order}))
    if p.startswith("order-status"):
        n = re.search(r"order=([^&]+)", url).group(1)
        o = state["status"].get(n)
        if not o: return route.fulfill(status=404, content_type="application/json", body='{"error":"no"}')
        return route.fulfill(status=200, content_type="application/json", body=json.dumps(o))
    if p.startswith("loyalty"):
        state["loyaltyCalls"] += 1
        if not state["loyaltyReady"] or "phone=3331234567" not in url or "key=" not in url: return route.fulfill(status=404, content_type="application/json", body='{"error":"no"}')
        return route.fulfill(status=200, content_type="application/json", body=json.dumps({"stamps": 2, "goal": 10, "missing": 8, "unitsTotal": 12, "creditCents": 500, "rewardCents": 500, "canUse": True}))
    route.fulfill(status=404, body="")

passed = 0
def ok(name, cond):
    global passed
    if not cond: raise SystemExit("FAIL: " + name)
    passed += 1; print("  ✓", name)

srv = subprocess.Popen([sys.executable, "-m", "http.server", "8765", "--bind", "127.0.0.1"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
import time; time.sleep(0.8)
with sync_playwright() as pw:
    b = pw.chromium.launch(); ctx = b.new_context(viewport={"width": 390, "height": 844})
    pg = ctx.new_page(); errors = []; pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.route("**/api/**", handle)
    U = "http://127.0.0.1:8765/index.html"
    pg.goto(U); pg.wait_for_timeout(300)
    ok("home: 7 tessere categoria", pg.locator(".tile").count() == 7)
    ok("home: pubblicità tessera fedeltà", pg.locator(".loyalty-ad").count() == 1 and "10 prodotti" in pg.inner_text(".loyalty-ad"))
    pg.goto(U + "#offerte"); pg.wait_for_timeout(200)
    ok("offerte: la tessera è la prima offerta", "Tessera Fedeltà" in pg.locator(".offer").first.inner_text())
    ok("pricing condiviso caricato nel browser", pg.evaluate("!!window.VicoloPricing && VicoloPricing.PROMO.bigGift.min===60"))

    # personalizzazione pizza: Margherita + Bufala + integrale
    pg.goto(U + "#cat/pizze"); pg.wait_for_timeout(200)
    pg.click("[data-add='pizze:0:0'], [data-customize='pizze:0:0'] >> nth=0"); pg.wait_for_timeout(200)
    ok("si apre il personalizzatore", pg.locator("#customOverlay.on").count() == 1)
    pg.click("#addonsToggle"); pg.check("input[data-addon='Bufala']"); pg.check("input[data-opt='Impasto integrale']")
    ok("totale personalizzato 6+2+1 = 9", pg.inner_text("#customTotal") == "€ 9,00")
    pg.fill("#customNote", "ben cotta"); pg.click("#customConfirm"); pg.wait_for_timeout(200)
    pg.click("[data-add='pizze:0:4'], [data-customize='pizze:0:4'] >> nth=0"); pg.click("#customConfirm"); pg.wait_for_timeout(100)  # Capricciosa liscia
    ok("badge carrello = 2", pg.inner_text("#cartCount") == "2")

    # scrittura nei campi: niente deve rubare il testo mentre si digita
    pg.goto(U + "#carrello"); pg.wait_for_timeout(600)
    for sel, txt in [("#fNome", "Mario Rossi"), ("#fPhone", "3331234567"), ("#fEmail", "mario.rossi@test.it"), ("#fAddr", "Via Roma 12, Scanzorosciate")]:
        if pg.locator(sel).count():
            pg.fill(sel, ""); pg.click(sel); pg.keyboard.type(txt, delay=35); pg.wait_for_timeout(1100)
            ok(f"si scrive tutto in {sel} (non solo la prima lettera)", pg.input_value(sel) == txt)
    pg.click("#fEmail"); pg.keyboard.type("x"); render_forced = pg.evaluate("render(); document.activeElement.id")
    ok("se la pagina si ridisegna mentre scrivi, il campo resta selezionato", render_forced == "fEmail")



    # carrello: pranzo mar-ven → €7 + lattine
    pg.goto(U + "#carrello"); pg.wait_for_timeout(500)
    pg.click(f"[data-date='{info['lunch']}']"); pg.wait_for_timeout(400)
    pg.click("[data-time='12:30']"); pg.wait_for_timeout(300)
    txt = pg.inner_text("#app")
    ok("pranzo: Margherita+Bufala a 10 (7+3) e Capricciosa a 7", "€ 10,00 cad." in txt and "€ 7,00 cad." in txt and "PRANZO €7" in txt)
    ok("2 lattine incluse con scelta gusto", pg.locator("select[data-can]").count() == 2)
    pg.select_option("select[data-can='1']", "Fanta")
    ok("totale pranzo 17", "€ 17,00" in pg.inner_text(".total"))

    # sera lun-gio → €6 sulla Capricciosa
    pg.click(f"[data-date='{info['evening']}']"); pg.wait_for_timeout(400); pg.click("[data-time='19:30']"); pg.wait_for_timeout(300)
    txt = pg.inner_text("#app")
    ok("sera: Capricciosa 8,50 → 6,00 con etichetta LUN–GIO", "LUN–GIO €6" in txt and "€ 6,00 cad." in txt)
    ok("totale sera = 9 + 6 = 15", "€ 15,00" in pg.inner_text(".total"))
    ok("nudge dolci -50% (mancano €10)", "metà prezzo" in txt and "€ 10,00" in txt)

    # dati cliente persistono cambiando orario
    pg.fill("#fNome", "Anna Test"); pg.fill("#fPhone", "3331234567"); pg.fill("#fAddr", "Via Roma 1, Scanzorosciate"); pg.fill("#fNote", "citofono")
    pg.click("[data-time='20:00']"); pg.wait_for_timeout(300)
    ok("nome/telefono/indirizzo/note restano dopo il cambio orario", pg.input_value("#fNome") == "Anna Test" and pg.input_value("#fAddr").startswith("Via Roma") and pg.input_value("#fNote") == "citofono")

    # fascia piena → errore gentile, poi invio ok
    state["slotFull"] = True
    pg.click("#sendOrder"); pg.wait_for_timeout(600)
    ok("fascia piena: toast e carrello ancora pieno", "piena" in pg.inner_text("#toast") and pg.inner_text("#cartCount") == "2")
    pg.click("[data-time='20:15']"); pg.wait_for_timeout(200)
    pg.click("#sendOrder"); pg.wait_for_timeout(800)
    sent = state["orders"][-1]
    ok("payload: 2 articoli con aggiunte, nota, totale, indirizzo, orario UTC", len(sent["items"]) == 2 and sent["items"][0]["addons"] == ["Impasto integrale", "Bufala"] and sent["items"][0]["note"] == "ben cotta" and sent["clientTotal"] == 15 and sent["address"].startswith("Via Roma") and sent["requestedAt"].endswith("Z"))
    ok("dopo l'invio: carrello vuoto e pagina ordini", pg.evaluate("location.hash") == "#ordini" and pg.locator("#cartCount").is_hidden())
    ok("card ordine in attesa", "in attesa di conferma" in pg.inner_text("#app") and "V2609-TST1" in pg.inner_text("#app"))
    ok("pulsante Condividi ordine presente per il cliente", pg.locator("[data-share]").count() == 1)
    dims = pg.evaluate("(()=>{const o=orders[0];const c=orderCanvas(o);return [c.width,c.height];})()")
    ok("condividi ordine: crea l'immagine del riepilogo", dims[0] >= 1000 and dims[1] >= 100)
    wa = pg.locator("a.btn.wa")
    ok("pulsante WhatsApp con numero pizzeria e scontrino", wa.count() == 1 and "wa.me/390350346406" in wa.get_attribute("href") and "Margherita" in pg.evaluate("decodeURIComponent(document.querySelector('a.btn.wa').href)"))

    # stato cambia lato server → la card si aggiorna senza popup
    n = "V2609-TST1"; state["status"][n].update({"status": "ACCETTATO", "confirmed_at": "2026-09-22T18:30:00Z", "delay_minutes": 30})
    pg.wait_for_timeout(16500)
    txt = pg.inner_text("#app")
    ok("ACCETTATO con orario confermato (+30 min)", "ACCETTATO" in txt and "confermato" in txt and "+30 min" in txt)
    state["status"][n].update({"status": "COMPLETATO", "completed_at": "2026-09-22T19:00:00Z", "loyalty_units": 2}); state["loyaltyReady"] = True
    pg.wait_for_timeout(16500)
    txt = pg.inner_text("#app")
    ok("COMPLETATO finisce nello storico, nessun ordine attivo", "Storico" in txt and "Nessun ordine in corso" in txt)
    ok("storico: +2 timbri fedeltà sull'ordine completato", "+2 timbri" in txt)
    pg.wait_for_timeout(1800)
    pg.goto(U + "#fedelta"); pg.wait_for_timeout(400); pg.fill("#fedPhone", "3331234567"); pg.wait_for_timeout(1200)
    ok("pagina fedeltà: 2/10 timbri veri dal server e credito € 5 pronto", "2/10" in pg.inner_text("#app") and pg.locator(".stamps span.f").count() == 2 and "€ 5,00 di credito" in pg.inner_text("#app"))
    ok("ordine salvato nel telefono (dv_orders)", pg.evaluate("JSON.parse(localStorage.getItem('dv_orders')).length") == 1)
    ok("nessun dialog/alert aperto e nessun errore JS", errors == [])

    # secondo ordine: weekend → 1L omaggio, dolce -50%, fritto mix
    pg.goto(U + "#cat/burger"); pg.wait_for_timeout(200)
    for _ in range(3): pg.click("[data-customize='burger:0:6']"); pg.click("#customConfirm"); pg.wait_for_timeout(80)
    pg.goto(U + "#cat/dolci"); pg.wait_for_timeout(200); pg.click("[data-add='dolci:0:0']"); pg.wait_for_timeout(100)
    pg.goto(U + "#carrello"); pg.wait_for_timeout(400); pg.click(f"[data-date='{info['weekend']}']"); pg.wait_for_timeout(400); pg.click("[data-time='20:00']"); pg.wait_for_timeout(300)
    txt = pg.inner_text("#app")
    ok("weekend: 39,25 → 1 solo litro omaggio, dolce -50%", "€ 39,25" in pg.inner_text(".total") and "1 × 1 litro" in txt and "DOLCE -50%" in txt)
    pg.click("[data-q='burger:0:6'][data-d='1']"); pg.wait_for_timeout(200); pg.click("[data-q='burger:0:6'][data-d='1']"); pg.wait_for_timeout(300)
    txt = pg.inner_text("#app")
    ok("a 63,25: fritto mix omaggio e 2 × 1L (regola sopra € 60)", "Fritto Mix 12 pezzi" in txt and "2 × 1 litro" in txt)
    ok("carrello: box credito fedeltà € 5 con 'Usa ora' e conteggio timbri", pg.locator(".gift.loyalty").count() == 1 and "Usa ora" in pg.inner_text(".gift.loyalty") and "accumuli 6 timbri" in txt and "hai 2/10" in txt)
    pg.click("[data-loyalty]"); pg.wait_for_timeout(300); txt = pg.inner_text("#app")
    ok("credito usato: −5, totale 58,25, fritto mix sparisce (si paga meno di 60)", "Credito tessera fedeltà" in txt and "€ 58,25" in pg.inner_text(".total") and pg.locator(".gift", has_text="Fritto Mix").count() == 0 and "Aggiungi ancora" in txt)
    ok("dopo il primo ordine i dati personali sono spariti dal telefono", pg.input_value("#fNome") == "" and pg.input_value("#fPhone") == "" and pg.input_value("#fAddr") == "")
    pg.fill("#fNome", "Anna Test"); pg.fill("#fPhone", "3331234567"); pg.fill("#fAddr", "Via Roma 1, Scanzorosciate")
    pg.wait_for_timeout(900)
    pg.select_option("select[data-wgift]", "Pepsi 1L"); pg.click("#sendOrder"); pg.wait_for_timeout(900)
    sent = state["orders"][-1]
    ok("payload weekend: Pepsi, useLoyalty true, totale 58,25", sent["choices"]["weekendGift"] == "Pepsi 1L" and sent["useLoyalty"] is True and sent["clientTotal"] == 58.25)
    ok("2 ordini: 1 attivo + 1 nello storico", "V2609-TST2" in pg.inner_text("#app") and "Storico" in pg.inner_text("#app"))
    pg.screenshot(path="/tmp/c_orders.png", clip={"x": 0, "y": 60, "width": 390, "height": 700})
    pg.goto(U + "#carrello"); pg.wait_for_timeout(200)
    pg.goto(U + "#cat/pizze"); pg.click("[data-customize='pizze:0:0']"); pg.click("#customConfirm"); pg.wait_for_timeout(100)
    pg.goto(U + "#carrello"); pg.wait_for_timeout(500); pg.click(f"[data-date='{info['lunch']}']"); pg.wait_for_timeout(400); pg.click("[data-time='12:30']"); pg.wait_for_timeout(300)
    pg.screenshot(path="/tmp/c_cart.png", clip={"x": 0, "y": 60, "width": 390, "height": 900})
    ok("nessun errore JS in tutto il test", errors == [])
    b.close()
srv.terminate()
print(f"\nTUTTI I TEST SUPERATI: {passed}")
