/* Test locali delle funzioni server con un finto Supabase (PostgREST) in memoria.
   Esecuzione:  node --experimental-strip-types tests/server.test.mjs  */
import assert from "node:assert/strict";

process.env.SUPABASE_URL = "https://fake.supabase.co";
process.env.SUPABASE_SECRET_KEY = "secret";
process.env.ACCOUNTS = "Rizwan:OWNER:pw-owner;Mario:STAFF:pw-staff";
process.env.ADMIN_SESSION_SECRET = "session-secret";
globalThis.Netlify = { env: { get: (k) => process.env[k] } };

/* ---------- mini PostgREST ---------- */
const db = { orders: [], order_items: [], audit_log: [], notification_log: [], settings: [{ key: "slot_capacity", value: { n: null } }], push_subscriptions: [], customers: [], loyalty_accounts: [], loyalty_ledger: [], admin_users: [] };
let ids = 0; const uuid = () => "00000000-0000-4000-8000-" + String(++ids).padStart(12, "0");
function match(row, key, op, val) {
  const v = row[key];
  switch (op) {
    case "eq": return String(v) === val; case "neq": return String(v) !== val;
    case "gte": return v >= val; case "gt": return v > val; case "lte": return v <= val; case "lt": return v < val;
    case "in": return val.slice(1, -1).split(",").includes(String(v));
    case "not.in": return !val.slice(1, -1).split(",").includes(String(v));
    case "ilike": return String(v || "").toLowerCase().includes(val.replace(/\*/g, "").toLowerCase());
    default: throw new Error("op " + op);
  }
}
function filterRows(table, params, project) {
  let rows = db[table].slice();
  for (const [k, raw] of params) {
    if (["select", "order", "limit", "offset"].includes(k)) continue;
    if (k === "or") { const alts = raw.slice(1, -1).split(","); rows = rows.filter(r => alts.some(a => { const [f, op, ...rest] = a.split("."); return match(r, f, op, rest.join(".")); })); continue; }
    if (k.includes(".")) continue; // filtri su tabelle incorporate: ignorati nel mock (gestiti a mano sotto)
    if (raw === "is.null") { rows = rows.filter(r => r[k] == null); continue; }
    if (raw === "is.true") { rows = rows.filter(r => r[k] === true); continue; }
    const m = raw.match(/^(not\.in|eq|neq|gte|gt|lte|lt|in|ilike)\.(.*)$/s); if (!m) throw new Error("filtro " + k + "=" + raw);
    rows = rows.filter(r => match(r, k, m[1], m[2]));
  }
  const order = params.get("order"); if (order) { const [f, dir] = order.split("."); rows.sort((a, b) => (a[f] > b[f] ? 1 : a[f] < b[f] ? -1 : 0) * (dir === "desc" ? -1 : 1)); }
  const limit = params.get("limit"); if (limit) rows = rows.slice(0, Number(limit));
  const select = params.get("select") || "";
  if (project && select && !select.includes("*") && !select.includes("(")) { const cols = select.split(","); rows = rows.map(r => Object.fromEntries(cols.filter(c => c in r).map(c => [c, r[c]]))); }
  if (table === "orders" && select.includes("order_items(")) rows = rows.map(o => ({ ...o, order_items: db.order_items.filter(i => i.order_id === o.id) }));
  if (table === "order_items" && select.includes("orders!inner")) { const from = params.get("orders.created_at")?.slice(4); rows = rows.filter(i => { const o = db.orders.find(o => o.id === i.order_id); return o && o.status !== "ANNULLATO" && (!from || o.created_at >= from); }); }
  return rows;
}
const external = [];
globalThis.fetch = async (url, init = {}) => {
  url = String(url);
  if (!url.startsWith("https://fake.supabase.co/rest/v1/")) { external.push({ url, init }); return new Response(JSON.stringify({ id: "ext-1" }), { status: 200 }); }
  const u = new URL(url); const table = u.pathname.split("/").pop(); const params = u.searchParams; const method = init.method || "GET";
  if (!db[table]) return new Response(JSON.stringify({ message: "relation missing " + table }), { status: 404 });
  const prefer = new Headers(init.headers || {}).get("prefer") || "";
  if (method === "HEAD") { const n = filterRows(table, params).length; return new Response(null, { status: 200, headers: { "content-range": `0-${n}/${n}` } }); }
  if (method === "GET") return new Response(JSON.stringify(filterRows(table, params, true)), { status: 200 });
  if (method === "POST") {
    const body = JSON.parse(init.body); const list = Array.isArray(body) ? body : [body]; const out = [];
    for (const r of list) {
      if (table === "settings" && prefer.includes("merge-duplicates")) { const i = db.settings.findIndex(s => s.key === r.key); if (i >= 0) db.settings[i] = { ...db.settings[i], ...r }; else db.settings.push(r); out.push(r); continue; }
      if (table === "push_subscriptions" && prefer.includes("merge-duplicates")) { const i = db.push_subscriptions.findIndex(s => s.endpoint === r.endpoint); if (i >= 0) db.push_subscriptions[i] = { ...db.push_subscriptions[i], ...r }; else db.push_subscriptions.push({ id: uuid(), created_at: new Date().toISOString(), ...r }); out.push(r); continue; }
      if (table === "orders" && db.orders.some(o => o.idempotency_key === r.idempotency_key)) return new Response(JSON.stringify({ code: "23505" }), { status: 409 });
      if (table === "customers" && db.customers.some(c => c.phone === r.phone)) return new Response(JSON.stringify({ code: "23505" }), { status: 409 });
      if (table === "loyalty_ledger" && ["EARN", "REFUND"].includes(r.entry_type) && db.loyalty_ledger.some(l => l.order_id === r.order_id && l.entry_type === r.entry_type)) return new Response(JSON.stringify({ code: "23505" }), { status: 409 });
      const row = { id: uuid(), created_at: new Date().toISOString(), reminder_count: 0, delay_minutes: 0, ...r }; db[table].push(row); out.push(row);
    }
    return new Response(prefer.includes("return=representation") ? JSON.stringify(out) : "", { status: 201 });
  }
  if (method === "PATCH") { const rows = filterRows(table, params); const patch = JSON.parse(init.body); rows.forEach(r => Object.assign(r, patch)); return new Response(JSON.stringify(rows), { status: 200 }); }
  if (method === "DELETE") { const rows = filterRows(table, params); rows.forEach(r => db[table].splice(db[table].indexOf(r), 1)); return new Response(null, { status: 204 }); }
  throw new Error("method " + method);
};

/* ---------- import funzioni ---------- */
const F = async (name) => (await import("../netlify/functions/" + name + ".mts")).default;
const pricing = (await import("../shared/pricing.js")).default;
const loyalty = await F("loyalty"), print = await F("print"), printEpson = await F("print-epson"), reprint = await F("admin-reprint"), users = await F("admin-users");
const orders = await F("orders"), orderStatus = await F("order-status"), slots = await F("slots"), login = await F("admin-login"), adminOrders = await F("admin-orders"),
  setStatus = await F("admin-order-status"), stats = await F("admin-stats"), customers = await F("admin-customers"), settings = await F("admin-settings"), push = await F("admin-push"), escalation = await F("escalation");
const req = (path, method = "GET", body, cookie) => new Request("https://site.test" + path, { method, headers: { "content-type": "application/json", ...(cookie ? { cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
const J = async (r) => ({ status: r.status, data: await r.json().catch(() => null), setCookie: r.headers.get("set-cookie") });

/* orario richiesto: prossimo mercoledì 12:30 ora di Roma (pranzo) */
/* prossima occorrenza di quel giorno della settimana a quell'ora, entro i 7 giorni consentiti */
/* prima data utile fra i giorni indicati, entro la finestra permessa dal sito (max 7 giorni) */
function nextWeekday(wds, time) { const days = [].concat(wds); const p = pricing.romeParts(new Date()); for (let i = 0; i < 7; i++) { const d = new Date(Date.UTC(p.y, p.m - 1, p.d + i)); const ds = d.toISOString().slice(0, 10); if (!days.includes(pricing.weekdayOf(ds))) continue; const t = pricing.romeToUTC(ds, time); if (t.getTime() > Date.now() + 40 * 60_000 && t.getTime() < Date.now() + 6.5 * 864e5) return t; } throw new Error("nessuna data utile per " + days.join("/")); }
const wedLunch = nextWeekday([2, 3, 4, 5], "12:30"), tueEvening = nextWeekday([1, 2, 3, 4], "19:30"), satEvening = nextWeekday([5, 6, 0], "20:00");

let pass = 0; const ok = (name, cond) => { if (!cond) throw new Error("FAIL: " + name); pass++; console.log("  ✓", name); };

/* 1. ordine pranzo con lattine, server ricalcola */
let items = [{ baseKey: "pizze:0:0", qty: 2 }, { baseKey: "pizze:0:1", qty: 1, addons: ["Bufala"] }];
let priced = pricing.priceOrder(items, pricing.romeParts(wedLunch), { cans: ["Fanta", "Sprite"] });
let r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k1", customer: { name: "Anna", phone: "3331234567", email: "a@b.it" }, fulfillmentType: "DELIVERY", address: "Via Roma 1", requestedAt: wedLunch.toISOString(), items, choices: { cans: ["Fanta", "Sprite"] }, clientTotal: priced.total, paymentMethod: "Contanti", notes: "citofono rotto" })));
ok("ordine pranzo creato (201)", r.status === 201);
ok("totale server = 7+7+(7+2) = 23", r.data.order.total_cents === 2300);
ok("3 lattine omaggio negli articoli", db.order_items.filter(i => i.product_name.startsWith("Lattina")).length === 3 && db.order_items.some(i => i.product_name.includes("Fanta")));
ok("comanda unica larga 32: intestazione, promo, totale, nessuna riga oltre 32 caratteri", r.data.order.ticket_text.includes("PRANZO €7") && r.data.order.ticket_text.includes("PIZZERIA DEL VICOLO") && /TOTALE\s+\d+,\d\d/.test(r.data.order.ticket_text) && r.data.order.ticket_text.split("\n").every(l => l.replace(/\u0001/, "").length <= 32));
ok("notifiche registrate come SKIPPED (nessuna chiave)", db.notification_log.length >= 2 && db.notification_log.every(n => n.status === "SKIPPED"));
const o1 = r.data.order;

/* 2. idempotenza */
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k1", customer: { name: "Anna", phone: "3331234567" }, fulfillmentType: "PICKUP", requestedAt: wedLunch.toISOString(), items, clientTotal: priced.total })));
ok("stesso idempotencyKey → duplicate:true, nessun nuovo ordine", r.data.duplicate === true && db.orders.length === 1);

/* 3. validazioni */
const monLunch = nextWeekday([1], "12:30");
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k2", customer: { name: "B", phone: "3331234567" }, fulfillmentType: "PICKUP", requestedAt: monLunch.toISOString(), items, clientTotal: 1 })));
ok("lunedì a pranzo → chiuso (400)", r.status === 400 && /chiusa/.test(r.data.error));
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k3", customer: { name: "B", phone: "3331234567" }, fulfillmentType: "PICKUP", requestedAt: new Date(Date.now() - 3600_000).toISOString(), items, clientTotal: 1 })));
ok("orario passato → 400", r.status === 400 && /passato/.test(r.data.error));
priced = pricing.priceOrder(items, pricing.romeParts(tueEvening));
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k4", customer: { name: "B", phone: "3331234567" }, fulfillmentType: "PICKUP", requestedAt: tueEvening.toISOString(), items, clientTotal: priced.total - 1 })));
ok("totale cliente diverso → 409", r.status === 409 && r.data.serverTotal === priced.total);
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k5", customer: { name: "B", phone: "12" }, fulfillmentType: "PICKUP", requestedAt: tueEvening.toISOString(), items, clientTotal: priced.total })));
ok("telefono non valido → 400", r.status === 400);

/* 4. martedì sera: classiche a 6, dolci -50% da 25, fritto mix da 60 */
items = [{ baseKey: "pizze:0:4", qty: 4 }, { baseKey: "dolci:0:0", qty: 1 }, { baseKey: "burger:0:6", qty: 3 }];
priced = pricing.priceOrder(items, pricing.romeParts(tueEvening));
ok("capricciosa a 6 la sera", priced.lines[0].unit === 6);
ok("dolce a metà (resto ≥ 25)", priced.lines[1].unit === 3.25 && priced.dolciHalf);
ok("fritto mix omaggio (totale ≥ 60)", priced.bigGift && priced.total === 63.25);
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k6", customer: { name: "Carlo", phone: "3489876543" }, fulfillmentType: "PICKUP", requestedAt: tueEvening.toISOString(), items, clientTotal: priced.total })));
ok("ordine sera creato", r.status === 201 && r.data.order.total_cents === 6325);
const o2 = r.data.order;

/* 5. capacità fascia */
const cookieOwner = (await J(await login(req("/api/admin/login", "POST", { username: "rizwan", password: "pw-owner" })))).setCookie.split(";")[0];
const cookieStaff = (await J(await login(req("/api/admin/login", "POST", { username: "Mario", password: "pw-staff" })))).setCookie.split(";")[0];
ok("login errato → 401", (await login(req("/api/admin/login", "POST", { username: "Mario", password: "no" }))).status === 401);
ok("staff non può cambiare impostazioni (403)", (await settings(req("/api/admin/settings", "POST", { slotCapacity: 1 }, cookieStaff))).status === 403);
ok("owner imposta capacità 1", (await J(await settings(req("/api/admin/settings", "POST", { slotCapacity: 1 }, cookieOwner)))).data.slotCapacity === 1);
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k7", customer: { name: "D", phone: "3331111111" }, fulfillmentType: "PICKUP", requestedAt: tueEvening.toISOString(), items: [{ baseKey: "pizze:0:0", qty: 1 }], clientTotal: 6 })));
ok("fascia piena → 409 slotFull", r.status === 409 && r.data.slotFull === true);
r = await J(await slots(req("/api/slots?date=" + pricing.romeParts(tueEvening).dateStr)));
ok("/api/slots segna 19:30 piena", r.data.slots.find(s => s.t === "19:30")?.full === true && r.data.slots.find(s => s.t === "19:45")?.full === false);
await settings(req("/api/admin/settings", "POST", { slotCapacity: null }, cookieOwner));

/* 6. transizioni di stato */
ok("senza login → 401", (await setStatus(req("/api/admin/order-status", "POST", { id: o1.id, status: "ACCETTATO" }))).status === 401);
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o1.id, status: "COMPLETATO" }, cookieStaff)));
ok("NUOVO → COMPLETATO vietato (409)", r.status === 409);
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o1.id, status: "ACCETTATO", delayMinutes: 30 }, cookieStaff)));
ok("accettato con +30: confirmed_at = richiesto + 30", r.status === 200 && new Date(r.data.order.confirmed_at).getTime() === wedLunch.getTime() + 30 * 60_000 && r.data.order.accepted_by === "Mario");
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o1.id, status: "ACCETTATO" }, cookieOwner)));
ok("doppia accettazione da altro dispositivo → 409", r.status === 409);
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o2.id, status: "ACCETTATO", delayMinutes: 0 }, cookieOwner)));
await setStatus(req("/api/admin/order-status", "POST", { id: o2.id, status: "PRONTO" }, cookieOwner));
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o2.id, status: "IN_CONSEGNA" }, cookieOwner)));
ok("ritiro → IN_CONSEGNA vietato (400)", r.status === 400);
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o2.id, status: "COMPLETATO" }, cookieOwner)));
ok("PRONTO → COMPLETATO ok, completed_at valorizzato", r.status === 200 && db.orders.find(o => o.id === o2.id).completed_at);
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: o1.id, status: "ANNULLATO" }, cookieOwner)));
ok("annullamento senza motivo → 400", r.status === 400);
{ const before = db.notification_log.length;
  const tmp = (await J(await orders(req("/api/orders", "POST", { idempotencyKey: "kx", customer: { name: "Test", phone: "3339990000" }, fulfillmentType: "PICKUP", requestedAt: tueEvening.toISOString(), items: [{ baseKey: "pizze:0:0", qty: 1 }], clientTotal: pricing.priceOrder([{ baseKey: "pizze:0:0", qty: 1 }], pricing.romeParts(tueEvening)).total })))).data.order;
  await setStatus(req("/api/admin/order-status", "POST", { id: tmp.id, status: "ANNULLATO", reason: "Fuori zona" }, cookieStaff));
  const canc = db.notification_log.slice(before);
  ok("annullato dallo staff → avviso ai proprietari su tutti i canali", canc.length >= 4 && [...new Set(canc.map(n => n.channel))].sort().join(",") === "email,ntfy,push,telegram"); }

/* 7. cliente vede lo stato; elenco gestionale; ricerca; storico */
r = await J(await orderStatus(req(`/api/order-status?order=${o1.order_number}&key=k1`)));
ok("stato cliente = ACCETTATO con confirmed_at", r.data.status === "ACCETTATO" && r.data.confirmed_at);
ok("chiave sbagliata → 404", (await orderStatus(req(`/api/order-status?order=${o1.order_number}&key=zzz`))).status === 404);
r = await J(await adminOrders(req("/api/admin/orders?scope=active", "GET", null, cookieStaff)));
ok("attivi: o1 presente con i suoi articoli", r.data.orders.some(x => x.id === o1.id) && Array.isArray(r.data.orders.find(x => x.id === o1.id).order_items));
r = await J(await adminOrders(req("/api/admin/orders?scope=history", "GET", null, cookieStaff)));
ok("storico: contiene o2 e l'ordine annullato di prova", r.data.orders.some(x => x.id === o2.id) && r.data.orders.some(x => x.status === "ANNULLATO"));
r = await J(await adminOrders(req("/api/admin/orders?q=carlo", "GET", null, cookieStaff)));
ok("ricerca per nome", r.data.orders.length === 1 && r.data.orders[0].customer_name === "Carlo");

/* 8. statistiche e clienti */
r = await J(await stats(req("/api/admin/stats", "GET", null, cookieOwner)));
ok("stats oggi: include i due ordini validi (€ 86,25 su 2)", r.data.today.orders >= 2 && r.data.today.revenue_cents >= 8625 && r.data.today.cancelled >= 1);
ok("top prodotti calcolati (Capricciosa 4)", r.data.topProducts.find(p => p.product_name === "Capricciosa")?.qty === 4);
r = await J(await customers(req("/api/admin/customers", "GET", null, cookieStaff)));
ok("clienti aggregati per telefono", r.data.customers.length >= 2 && r.data.customers.find(c => c.name === "Anna").spent_cents === 2300);

/* 9. escalation: ordine NUOVO vecchio di 4 minuti */
items = [{ baseKey: "pizze:0:0", qty: 1 }];
priced = pricing.priceOrder(items, pricing.romeParts(satEvening));
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k9", customer: { name: "Eva", phone: "3332222222" }, fulfillmentType: "PICKUP", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
const o3 = db.orders.find(o => o.id === r.data.order.id); o3.created_at = new Date(Date.now() - 4 * 60_000).toISOString();
const before = db.notification_log.length;
await escalation();
ok("escalation: escalated_at + reminder_count=1", o3.escalated_at && o3.reminder_count === 1);
ok("escalation a 3 min: push+email+telegram+ntfy (SKIPPED senza chiavi), NESSUNA chiamata", db.notification_log.slice(before).map(n => n.channel).sort().join(",") === "email,ntfy,push,telegram" && !o3.called_at);
await escalation();
ok("secondo giro entro 3 min: nessun nuovo promemoria", o3.reminder_count === 1);
o3.last_reminder_at = new Date(Date.now() - 4 * 60_000).toISOString(); await escalation();
ok("dopo 3 min: promemoria n.2", o3.reminder_count === 2);
o3.created_at = new Date(Date.now() - 11 * 60_000).toISOString(); const beforeCall = db.notification_log.length; await escalation();
ok("dopo 10 min: parte la telefonata (una sola volta)", o3.called_at && db.notification_log.slice(beforeCall).some(n => n.channel === "call"));
await escalation();
ok("la chiamata non si ripete", db.notification_log.filter(n => n.channel === "call").length === 1);
await setStatus(req("/api/admin/order-status", "POST", { id: o3.id, status: "ACCETTATO" }, cookieOwner)); const rc = o3.reminder_count; await escalation();
ok("accettato → escalation si ferma", o3.reminder_count === rc);

/* 10. email/push con chiavi finte: chiamate esterne partono */
process.env.RESEND_API_KEY = "re_test"; process.env.NOTIFY_EMAILS = "a@a.it, b@b.it";
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k10", customer: { name: "Eva", phone: "3332222222" }, fulfillmentType: "PICKUP", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
const mail = external.find(x => x.url.includes("api.resend.com"));
ok("email inviata a Resend con 2 destinatari e scontrino", mail && JSON.parse(mail.init.body).to.length === 2 && JSON.parse(mail.init.body).text.includes("Margherita"));
ok("registro email SENT", db.notification_log.some(n => n.channel === "email" && n.status === "SENT"));
r = await J(await push(req("/api/admin/push", "GET", null, cookieOwner)));
ok("push non configurate → configured:false", r.data.configured === false);
process.env.TELEGRAM_BOT_TOKEN = "123:abc"; process.env.TELEGRAM_CHAT_IDS = "-100555, 777";
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k11", customer: { name: "Eva", phone: "3332222222" }, fulfillmentType: "PICKUP", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
const tg = external.filter(x => x.url.includes("api.telegram.org"));
ok("Telegram: 2 messaggi (uno per chat) con numero ordine e scontrino", tg.length === 2 && JSON.parse(tg[0].init.body).chat_id === "-100555" && JSON.parse(tg[1].init.body).text.includes(r.data.order.order_number) && JSON.parse(tg[1].init.body).text.includes("Margherita"));
ok("registro telegram SENT", db.notification_log.filter(n => n.channel === "telegram" && n.status === "SENT").length === 2);
r = await J(await push(req("/api/admin/push?test=1", "POST", {}, cookieOwner)));
ok("prova dal gestionale manda anche Telegram", r.data.telegram.sent === 2);
process.env.NTFY_TOPIC = "vicolo-test-topic";
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "k12", customer: { name: "Eva", phone: "3332222222" }, fulfillmentType: "PICKUP", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
const nf = external.filter(x => x.url.startsWith("https://ntfy.sh/vicolo-test-topic"));
ok("ntfy: allarme con priorità massima, senza dati del cliente", nf.length === 1 && new Headers(nf[0].init.headers).get("priority") === "5" && nf[0].init.headers.Title.includes(r.data.order.order_number) && !nf[0].init.body.includes("Eva") && !nf[0].init.body.includes("3332222222"));
ok("registro ntfy SENT", db.notification_log.some(n => n.channel === "ntfy" && n.status === "SENT"));

/* 11. tessera fedeltà: 10 prodotti = € 5 */
const monEvening = nextWeekday([1], "20:00");
items = [{ baseKey: "pizze:0:0", qty: 7 }, { baseKey: "fritti:0:0", qty: 5 }]; // 12 prodotti
priced = pricing.priceOrder(items, pricing.romeParts(monEvening));
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "L1", customer: { name: "Fede Le", phone: "+39 333 999 8888" }, fulfillmentType: "PICKUP", requestedAt: monEvening.toISOString(), items, clientTotal: priced.total })));
ok("ordine fedeltà creato e cliente collegato (telefono normalizzato)", r.status === 201 && r.data.order.customer_id && db.customers.find(c => c.id === r.data.order.customer_id).phone === "3339998888");
const oL = r.data.order; const accL = () => db.loyalty_accounts.find(a => a.customer_id === oL.customer_id);
ok("prima del completamento: 0 timbri, 0 credito", r.data.loyalty.stamps === 0 && r.data.loyalty.creditCents === 0);
await setStatus(req("/api/admin/order-status", "POST", { id: oL.id, status: "ACCETTATO" }, cookieOwner));
await setStatus(req("/api/admin/order-status", "POST", { id: oL.id, status: "PRONTO" }, cookieOwner));
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: oL.id, status: "COMPLETATO" }, cookieOwner)));
ok("COMPLETATO → 1 solo premio da € 5 e conteggio azzerato", r.data.loyalty.units === 12 && r.data.loyalty.rewards === 1 && accL().available_credit_cents === 500 && accL().qualifying_count === 0);
ok("ledger EARN una sola riga per l'ordine (e Carlo ha già 8 timbri dall'ordine precedente)", db.loyalty_ledger.filter(l => l.entry_type === "EARN" && l.order_id === oL.id).length === 1 && db.loyalty_accounts.some(a => a.qualifying_count === 8));
r = await J(await loyalty(req(`/api/loyalty?phone=3339998888&order=${oL.order_number}&key=L1`)));
ok("/api/loyalty: conteggio azzerato, credito da usare", r.data.stamps === 0 && r.data.creditCents === 500 && r.data.canUse === true);
/* con il premio in cassa i timbri NON salgono: niente accumulo */
{ const items2 = [{ baseKey: "pizze:0:0", qty: 12 }];
  const p2 = pricing.priceOrder(items2, pricing.romeParts(monEvening));
  const r2 = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "L1b", customer: { name: "Fede Le", phone: "3339998888" }, fulfillmentType: "PICKUP", requestedAt: monEvening.toISOString(), items: items2, clientTotal: p2.total })));
  await setStatus(req("/api/admin/order-status", "POST", { id: r2.data.order.id, status: "ACCETTATO" }, cookieOwner));
  await setStatus(req("/api/admin/order-status", "POST", { id: r2.data.order.id, status: "PRONTO" }, cookieOwner));
  const r3 = await J(await setStatus(req("/api/admin/order-status", "POST", { id: r2.data.order.id, status: "COMPLETATO" }, cookieOwner)));
  ok("premio non ancora usato → niente nuovi timbri né nuovo credito", r3.data.loyalty.skipped === true && accL().available_credit_cents === 500 && accL().qualifying_count === 0); }
ok("/api/loyalty con chiave sbagliata → 404", (await loyalty(req(`/api/loyalty?phone=3339998888&order=${oL.order_number}&key=nope`))).status === 404);
ok("/api/loyalty con telefono di un altro → 404", (await loyalty(req(`/api/loyalty?phone=3331111111&order=${oL.order_number}&key=L1`))).status === 404);
/* usa il credito */
items = [{ baseKey: "pizze:0:4", qty: 2 }]; priced = pricing.priceOrder(items, pricing.romeParts(monEvening), { loyaltyCents: 500 });
ok("motore: 2 capricciose sera 12 − 5 credito = 7", priced.promoTotal === 12 && priced.loyaltyDiscount === 5 && priced.total === 7);
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "L2", customer: { name: "Fede Le", phone: "3339998888" }, fulfillmentType: "PICKUP", requestedAt: monEvening.toISOString(), items, clientTotal: 7, useLoyalty: true })));
ok("ordine con credito: totale 7, credito usato 500, conto a 0", r.status === 201 && r.data.order.total_cents === 700 && r.data.order.loyalty_credit_used_cents === 500 && accL().available_credit_cents === 0);
ok("comanda riporta il credito fedeltà", /Credito fedelta\s+-5,00/.test(r.data.order.ticket_text));
const oL2 = r.data.order;
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "L3", customer: { name: "Fede Le", phone: "3339998888" }, fulfillmentType: "PICKUP", requestedAt: monEvening.toISOString(), items, clientTotal: 7, useLoyalty: true })));
ok("credito finito → 409 con stato tessera", r.status === 409 && r.data.loyalty.creditCents === 0);
r = await J(await setStatus(req("/api/admin/order-status", "POST", { id: oL2.id, status: "ANNULLATO", reason: "test rimborso" }, cookieOwner)));
ok("annullato → credito rimborsato (500)", r.data.loyalty.refunded === 500 && accL().available_credit_cents === 500);
r = await J(await orderStatus(req(`/api/order-status?order=${oL2.order_number}&key=L2`)));
ok("stato cliente riporta credito usato", r.data.loyalty_credit_used_cents === 500 && r.data.status === "ANNULLATO");
r = await J(await customers(req("/api/admin/customers?q=fede", "GET", null, cookieStaff)));
ok("clienti: timbri e credito visibili allo staff", r.data.customers[0].stamps === 0 && r.data.customers[0].credit_cents === 500);

/* 12. stampante cloud */
process.env.PRINT_KEY = "chiave-stampante"; process.env.SITE_URL = "https://pizzeriavicolo.it";
db.orders.forEach(o => { o.printed_at = new Date().toISOString(); }); // ordini vecchi: già "stampati"
items = [{ baseKey: "pizze:0:0", qty: 2, addons: ["Bufala"], note: "ben cotta" }]; priced = pricing.priceOrder(items, pricing.romeParts(satEvening));
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "P1", customer: { name: "Giò Verdè", phone: "3335556666" }, fulfillmentType: "DELIVERY", address: "Via Colleoni 92", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
const oP = r.data.order;
ok("chiave sbagliata → 404", (await print(req("/api/print/sbagliata", "POST", { status: "23 6 0 0" }))).status === 404);
r = await J(await print(req("/api/print/chiave-stampante", "POST", { status: "23 6 0 0 0 0 0 0 0 0 0", printerMAC: "00:11:62:AA:BB:CC", printingInProgress: false })));
ok("Star POST: jobReady true con token dell'ordine e text/plain", r.data.jobReady === true && r.data.jobToken === oP.id && r.data.mediaTypes[0] === "text/plain");
ok("ultimo contatto stampante salvato", db.settings.find(x => x.key === "printer_last_seen").value.ident === "00:11:62:AA:BB:CC");
let pr = await print(req(`/api/print/chiave-stampante?type=text%2Fplain&mac=00:11:62:AA:BB:CC&token=${oP.id}`, "GET"));
let body = await pr.text();
ok("Star GET: comanda in ASCII, consegna, indirizzo, nota, righe grandi in ESC/POS", pr.status === 200 && body.includes("CONSEGNA") && body.includes("Via Colleoni 92") && body.includes("ben cotta") && body.includes("Gio Verde") && !/[àèé€]/.test(body) && body.includes("\x1D\x21\x11") && /TOTALE\s+\d+,\d\d/.test(body));
ok("dopo il GET l'ordine è segnato stampato (print_count 1)", db.orders.find(o => o.id === oP.id).printed_at && db.orders.find(o => o.id === oP.id).print_count === 1);
r = await J(await print(req("/api/print/chiave-stampante", "POST", { status: "23 6 0 0" })));
ok("secondo giro: niente da stampare", r.data.jobReady === false);
ok("Star DELETE con esito OK → 200 e audit PRINTED", (await print(req(`/api/print/chiave-stampante?code=200%20OK&mac=x&token=${oP.id}`, "DELETE"))).status === 200 && db.audit_log.some(a => a.action === "PRINTED" && a.entity_id === oP.id));
/* errore stampa (es. carta finita) → torna in coda */
await print(req(`/api/print/chiave-stampante?code=Paper%20End&mac=x&token=${oP.id}`, "DELETE"));
ok("esito errore → l'ordine torna in coda", db.orders.find(o => o.id === oP.id).printed_at === null);
r = await J(await print(req("/api/print/chiave-stampante", "POST", { status: "23 6 0 0" })));
ok("ristampa automatica: jobReady di nuovo", r.data.jobReady === true);
await print(req(`/api/print/chiave-stampante?type=text%2Fplain&token=${oP.id}`, "GET"));
/* ristampa dal gestionale */
r = await J(await reprint(req("/api/admin/reprint", "POST", { id: oP.id }, cookieStaff)));
ok("ristampa dal gestionale: ok + ultimo contatto stampante", r.data.ok && r.data.printerSeenAt);
pr = await print(req(`/api/print/chiave-stampante?type=text%2Fplain&token=${oP.id}`, "GET")); body = await pr.text();
ok("la ristampa è marcata *** RISTAMPA ***", body.includes("*** RISTAMPA ***"));
/* ordine annullato non si stampa */
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "P2", customer: { name: "X", phone: "3335556667" }, fulfillmentType: "PICKUP", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
await setStatus(req("/api/admin/order-status", "POST", { id: r.data.order.id, status: "ANNULLATO", reason: "prova" }, cookieOwner));
r = await J(await print(req("/api/print/chiave-stampante", "POST", { status: "23 6 0 0" })));
ok("ordine annullato: non va in stampa", r.data.jobReady === false);
/* Epson */
r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: "P3", customer: { name: "Y", phone: "3335556668" }, fulfillmentType: "PICKUP", requestedAt: satEvening.toISOString(), items, clientTotal: priced.total })));
const oE = r.data.order;
pr = await printEpson(new Request("https://site.test/api/print-epson/chiave-stampante", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "ConnectionType=GetRequest&ID=TM-m30III-001&Name=cucina" })); body = await pr.text();
ok("Epson GetRequest: XML ePOS con printjobid e taglio", pr.status === 200 && body.includes("<PrintRequestInfo") && body.includes(`<printjobid>${oE.id}</printjobid>`) && body.includes("<cut") && body.includes("RITIRO"));
pr = await printEpson(new Request("https://site.test/api/print-epson/chiave-stampante", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "ConnectionType=SetResponse&ResponseFile=" + encodeURIComponent(`<PrintResponseInfo Version="3.00"><ePOSPrint><Parameter><devid>local_printer</devid><printjobid>${oE.id}</printjobid></Parameter><PrintResponse><response success="true" code="" status="252641300"/></PrintResponse></ePOSPrint></PrintResponseInfo>`) }));
ok("Epson SetResponse: esito registrato", pr.status === 200 && db.audit_log.some(a => a.action === "PRINTED" && a.entity_id === oE.id));
pr = await printEpson(new Request("https://site.test/api/print-epson/chiave-stampante", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "ConnectionType=GetRequest&ID=TM-m30III-001" })); body = await pr.text();
ok("Epson: niente in coda → risposta vuota", pr.status === 200 && body === "");

/* 13. Web Push senza librerie: cifratura decifrabile dal "browser" e token VAPID verificabile */
{
  const crypto = await import("node:crypto");
  const { generateKeyPairSync, createECDH, hkdfSync, createDecipheriv, createPublicKey, verify } = crypto;
  const { privateKey: pk } = generateKeyPairSync("ec", { namedCurve: "prime256v1" }); const jwk = pk.export({ format: "jwk" });
  const vapidPub = Buffer.concat([Buffer.from([4]), Buffer.from(jwk.x, "base64url"), Buffer.from(jwk.y, "base64url")]).toString("base64url");
  process.env.VAPID_PUBLIC_KEY = vapidPub; process.env.VAPID_PRIVATE_KEY = jwk.d; process.env.VAPID_SUBJECT = "mailto:test@vicolo.it";
  /* finto browser: coppia di chiavi + auth secret */
  const ua = createECDH("prime256v1"); ua.generateKeys(); const authSecret = crypto.randomBytes(16);
  db.push_subscriptions.push({ id: "sub-1", endpoint: "https://fcm.googleapis.com/fcm/send/abc", p256dh: ua.getPublicKey().toString("base64url"), auth: authSecret.toString("base64url"), user_label: "tablet" });
  db.push_subscriptions.push({ id: "sub-2", endpoint: "https://updates.push.services.mozilla.com/wpush/v2/gone", p256dh: ua.getPublicKey().toString("base64url"), auth: authSecret.toString("base64url"), user_label: "vecchio" });
  const savedFetch = globalThis.fetch;
  globalThis.fetch = async (url, init = {}) => { if (String(url).includes("/gone")) { external.push({ url: String(url), init }); return new Response("", { status: 410 }); } return savedFetch(url, init); };
  r = await J(await push(req("/api/admin/push?test=1", "POST", {}, cookieOwner)));
  globalThis.fetch = savedFetch;
  ok("push: 1 inviata, 1 fallita (410) e l'iscrizione scaduta viene cancellata", r.data.sent === 1 && r.data.failed === 1 && db.push_subscriptions.length === 1);
  const call = external.find(x => x.url === "https://fcm.googleapis.com/fcm/send/abc");
  const h = call.init.headers;
  ok("header: aes128gcm, TTL, Urgency", h["Content-Encoding"] === "aes128gcm" && h.TTL === "600" && h.Urgency === "normal");
  /* verifica del token VAPID con la chiave pubblica */
  const m = h.Authorization.match(/^vapid t=([^,]+), k=(.+)$/); const [hb, pb, sb64] = m[1].split(".");
  const pubKey = createPublicKey({ key: { kty: "EC", crv: "P-256", x: jwk.x, y: jwk.y }, format: "jwk" });
  const okSig = verify("sha256", Buffer.from(`${hb}.${pb}`), { key: pubKey, dsaEncoding: "ieee-p1363" }, Buffer.from(sb64, "base64url"));
  const claims = JSON.parse(Buffer.from(pb, "base64url").toString());
  ok("token VAPID firmato correttamente, aud = origine del servizio push, k = chiave pubblica", okSig && claims.aud === "https://fcm.googleapis.com" && claims.sub === "mailto:test@vicolo.it" && m[2] === vapidPub);
  /* decifra come farebbe il browser */
  const body = Buffer.from(call.init.body); const salt = body.subarray(0, 16), idlen = body[20], asPublic = body.subarray(21, 21 + idlen), cipherText = body.subarray(21 + idlen);
  const shared = ua.computeSecret(asPublic);
  const ikm = Buffer.from(hkdfSync("sha256", shared, authSecret, Buffer.concat([Buffer.from("WebPush: info\0"), ua.getPublicKey(), asPublic]), 32));
  const cek = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: aes128gcm\0"), 16)), nonce = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: nonce\0"), 12));
  const dec = createDecipheriv("aes-128-gcm", cek, nonce); dec.setAuthTag(cipherText.subarray(cipherText.length - 16));
  const plain = Buffer.concat([dec.update(cipherText.subarray(0, cipherText.length - 16)), dec.final()]);
  const msg = JSON.parse(plain.subarray(0, plain.length - 1).toString("utf8"));
  ok("il browser decifra il messaggio: titolo e testo giusti, delimitatore 0x02", plain[plain.length - 1] === 2 && msg.title === "🔔 Prova notifiche" && msg.body.includes("Rizwan"));
}

/* 14. account dello staff creati dal gestionale */
ok("lo staff non può gestire gli account (403)", (await users(req("/api/admin/users", "GET", null, cookieStaff))).status === 403);
r = await J(await users(req("/api/admin/users", "POST", { username: "Giulia", password: "471", role: "STAFF" }, cookieOwner)));
ok("PIN troppo corto → errore", r.status === 400 && /almeno 4/.test(r.data.error));
r = await J(await users(req("/api/admin/users", "POST", { username: "Giulia", password: "47281", role: "STAFF" }, cookieOwner)));
ok("account creato, password non in chiaro nel database", r.status === 201 && db.admin_users.length === 1 && db.admin_users[0].pass_hash && !JSON.stringify(db.admin_users[0]).includes("47281"));
const gid = db.admin_users[0].id;
r = await J(await login(req("/api/admin/login", "POST", { username: "giulia", password: "47281" })));
ok("Giulia entra col PIN (maiuscole indifferenti), ruolo STAFF", r.status === 200 && r.data.role === "STAFF" && r.data.user === "Giulia");
ok("PIN sbagliato → 401", (await login(req("/api/admin/login", "POST", { username: "Giulia", password: "00000" }))).status === 401);
ok("ultimo accesso registrato", !!db.admin_users[0].last_login_at);
await users(req("/api/admin/users", "POST", { id: gid, password: "99887" }, cookieOwner));
ok("cambio PIN: vecchio non va più, nuovo sì", (await login(req("/api/admin/login", "POST", { username: "Giulia", password: "47281" }))).status === 401 && (await login(req("/api/admin/login", "POST", { username: "Giulia", password: "99887" }))).status === 200);
await users(req("/api/admin/users", "POST", { id: gid, active: false }, cookieOwner));
ok("account sospeso → non entra più", (await login(req("/api/admin/login", "POST", { username: "Giulia", password: "99887" }))).status === 401);
await users(req("/api/admin/users", "POST", { id: gid, active: true }, cookieOwner));
r = await J(await users(req("/api/admin/users", "GET", null, cookieOwner)));
ok("elenco account senza impronte della password", r.data.users.length === 1 && !JSON.stringify(r.data.users).includes("pass_hash"));
await users(req("/api/admin/users", "DELETE", { id: gid }, cookieOwner));
ok("account eliminato", db.admin_users.length === 0 && (await login(req("/api/admin/login", "POST", { username: "Giulia", password: "99887" }))).status === 401);
ok("gli account delle variabili Netlify funzionano ancora", (await login(req("/api/admin/login", "POST", { username: "Rizwan", password: "pw-owner" }))).status === 200);

/* 15. offerta mezzogiorno estesa alle piadine e prezzi corretti dal volantino */
{
  const mid = { weekday: 3, mins: 12 * 60 + 30 };
  const r2 = pricing.priceOrder([{ baseKey: "pizze:0:0", qty: 1 }, { baseKey: "piadine:0:0", qty: 1 }, { baseKey: "burger:0:0", qty: 1 }], mid, {});
  ok("pranzo: pizza classica E piadina a € 7, hamburger a listino", r2.lines[0].unit === 7 && r2.lines[1].unit === 7 && r2.lines[2].unit === 6 && r2.lunchCans === 2);
  const sera = pricing.priceOrder([{ baseKey: "piadine:0:0", qty: 1 }], { weekday: 2, mins: 20 * 60 });
  ok("sera: la piadina resta a listino (promo €6 solo pizze classiche)", sera.lines[0].unit === 6.5);
  const pizze = pricing.MENU.find(c => c.id === "pizze");
  ok("Maialina € 9,00 e Profumo di Mare € 9,00 come sul volantino", pizze.groups[2].items.find(x => x[0] === "Maialina")[2] === 9 && pizze.groups[3].items.find(x => x[0] === "Profumo di Mare")[2] === 9);
}

/* 16. litro omaggio: 1 da € 20, 2 sopra € 60 */
{
  const sab = { weekday: 6, mins: 20 * 60 };
  const g = n => pricing.priceOrder([{ baseKey: "pizze:0:4", qty: n }], sab).weekendGifts;
  ok("weekend: sotto € 20 nessun litro", pricing.priceOrder([{ baseKey: "pizze:0:0", qty: 1 }], sab).weekendGifts === 0);
  ok("weekend: € 25 e € 45 → 1 solo litro", g(3) === 1 && g(6) === 1);
  ok("weekend: sopra € 60 → 2 litri, mai di più", g(8) === 2 && g(20) === 2);
}

/* 17. ordini fino alle 22:00 tutte le sere */
{
  const lun = "2026-09-21";
  ok("lunedì alle 22:00 si può ancora ordinare (per le 22:20)", pricing.slotsFor(lun, pricing.romeToUTC(lun, "22:00")).join() === "22:20");
  ok("lunedì alle 22:05 non si può più ordinare", pricing.slotsFor(lun, pricing.romeToUTC(lun, "22:05")).length === 0);
  ok("lunedì a pranzo resta chiuso", !pricing.isOpenAt(1, 12 * 60));
}

/* 18. tessera fedeltà: il giro completo, ordine dopo ordine */
{
  const cust = db.customers.find(c => c.phone === "3339998888");
  const acc = () => db.loyalty_accounts.find(a => a.customer_id === cust.id);
  const mkOrder = async (qty, key, useLoyalty) => {
    const items = [{ baseKey: "pizze:0:0", qty }];
    const p = pricing.priceOrder(items, pricing.romeParts(monEvening));
    const r = await J(await orders(req("/api/orders", "POST", { idempotencyKey: key, customer: { name: "Fede Le", phone: "3339998888" }, fulfillmentType: "PICKUP", requestedAt: monEvening.toISOString(), items, clientTotal: useLoyalty ? p.total - 5 : p.total, useLoyalty: !!useLoyalty })));
    for (const st of ["ACCETTATO", "PRONTO", "COMPLETATO"]) await setStatus(req("/api/admin/order-status", "POST", { id: r.data.order.id, status: st }, cookieOwner));
    return r;
  };
  const start = { count: Number(acc().qualifying_count), credit: Number(acc().available_credit_cents) };
  ok("punto di partenza: premio da € 5 pronto, conteggio a zero", start.credit === 500 && start.count === 0);

  /* usa il credito: lo sconto scende dal totale e il premio si consuma */
  const used = await mkOrder(3, "F1", true);
  ok("usando il credito lo sconto compare sull'ordine", used.data.order.loyalty_credit_used_cents === 500 && Number(acc().available_credit_cents) === 0);
  ok("dopo aver usato lo sconto i timbri ripartono e salgono", Number(acc().qualifying_count) === 3);

  await mkOrder(4, "F2");
  ok("secondo ordine: i timbri si sommano (3+4=7)", Number(acc().qualifying_count) === 7 && Number(acc().available_credit_cents) === 0);

  await mkOrder(4, "F3");
  ok("arrivato a 10 scatta il premio e il conteggio torna a zero", Number(acc().available_credit_cents) === 500 && Number(acc().qualifying_count) === 0);

  await mkOrder(6, "F4");
  ok("con il premio non usato i timbri restano fermi", Number(acc().qualifying_count) === 0 && Number(acc().available_credit_cents) === 500);

  const r = await J(await loyalty(req(`/api/loyalty?phone=3339998888&order=${used.data.order.order_number}&key=F1`)));
  ok("il riepilogo dice: timbri in pausa e premi già ricevuti", r.data.paused === true && r.data.stamps === 0 && r.data.rewardsTotal >= 1 && r.data.canUse === true);
}

/* 19. l'email della comanda: righe grandi davvero grandi */
{
  const notify = await import("../netlify/functions/_notify.mts");
  const t = "\u0001  V260930-3244\n\u0001  RITIRO\n1 Pizza Kebab              8,50\n--------------------------------\n\u0001  TOTALE 8,50";
  const html = notify.ticketHtmlEmail(t, "https://pizzeriavicolo.it/admin/");
  ok("email: numero ordine, RITIRO e TOTALE escono a 26px", (html.match(/font:800 26px/g) || []).length === 3);
  ok("email: le righe normali restano piccole e allineate", html.includes("15px/1.45 ui-monospace") && html.includes("Pizza Kebab"));
  ok("email: c'è il pulsante per aprire il gestionale", html.includes("APRI IL GESTIONALE") && html.includes("/admin/"));
  ok("email: nessun carattere di controllo visibile", !html.includes("\u0001"));
}

console.log(`\nTUTTI I TEST SUPERATI: ${pass}`);
