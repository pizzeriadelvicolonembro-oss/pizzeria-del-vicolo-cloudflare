Test automatici (richiedono Node 22+ e, per quelli browser, Python 3 + Playwright):
  node --experimental-strip-types tests/server.test.mjs   → funzioni server con Supabase simulato (42 controlli)
  python3 tests/client.test.py                             → sito cliente in Chromium con API simulate (25 controlli)
  python3 tests/admin.test.py                              → gestionale in Chromium con API simulate (24 controlli)
