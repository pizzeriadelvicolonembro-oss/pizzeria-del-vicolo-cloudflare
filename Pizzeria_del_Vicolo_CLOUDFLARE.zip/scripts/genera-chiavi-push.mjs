/* Genera una coppia di chiavi VAPID per le notifiche push (da fare UNA volta sola).
   Esecuzione: node scripts/genera-chiavi-push.mjs  → copia i valori nelle variabili Netlify. */
import { generateKeyPairSync } from "node:crypto";
const { privateKey } = generateKeyPairSync("ec", { namedCurve: "prime256v1" });
const jwk = privateKey.export({ format: "jwk" });
const pub = Buffer.concat([Buffer.from([4]), Buffer.from(jwk.x, "base64url"), Buffer.from(jwk.y, "base64url")]).toString("base64url");
console.log("VAPID_PUBLIC_KEY=" + pub);
console.log("VAPID_PRIVATE_KEY=" + jwk.d);
console.log("VAPID_SUBJECT=mailto:pizzeriadelvicolonembro@gmail.com");
