/* Ricostruisce index.html partendo da:
   - site/index.template.html  (grafica + immagini incorporate, con i segnaposto <!--PRICING--> <!--CLIENT--> <!--EXTRA_CSS-->)
   - shared/pricing.js         (listino/orari/promo, condiviso col server)
   - site/client.js            (logica del sito)
   - site/extra.css
   Esecuzione: node scripts/build-index.mjs */
import { readFileSync, writeFileSync } from "node:fs";
const tpl = readFileSync("site/index.template.html", "utf8");
const pricing = readFileSync("shared/pricing.js", "utf8"), client = readFileSync("site/client.js", "utf8"), css = readFileSync("site/extra.css", "utf8");
for (const m of ["<!--PRICING-->", "<!--CLIENT-->", "<!--EXTRA_CSS-->"]) if (!tpl.includes(m)) throw new Error("manca il segnaposto " + m);
const out = tpl.replace("<!--EXTRA_CSS-->", css).replace("<!--PRICING-->", "<script>\n" + pricing + "\n</script>").replace("<!--CLIENT-->", client);
writeFileSync("index.html", out);
console.log("index.html generato:", (out.length / 1024 / 1024).toFixed(2), "MB");
