PIZZERIA DEL VICOLO — VERSIONE CLOUDFARE AUDITATA 2026-09-30

GESTIONALE:
https://pizzeriavicolo.it/admin/

PRIMA DI USARE IN SERVIZIO:
1) login OWNER
2) ALTRO > Controllo sistema
3) PROVA EMAIL
4) PROVA PUSH
5) crea un account STAFF dall'app
6) ordine di prova
7) lascia NUOVO per 3-6 minuti e verifica reminder
8) accetta ordine: reminder deve fermarsi
9) prova Condividi comanda (foto)

NON TOCCARE DNS / ROUTE.
HTTP/3: lasciare OFF se il 5G mostra ERR_QUIC_PROTOCOL_ERROR.
HTTP/2 e TLS 1.3: ON.

Vedi AUDIT_REPORT.md e CLOUDFLARE_SETUP.md.
