import { envGet } from "./env.ts";
/* Notifiche ai proprietari/staff: Web Push (gratis, anche a gestionale chiuso) + Email (Resend).
   Ogni tentativo viene registrato in notification_log. Un errore qui NON blocca mai l'ordine. */
import { sb } from "./_supabase.ts";
import { sendWebPush } from "./_webpush.ts";

type PushSub = { id: string; endpoint: string; p256dh: string; auth: string; user_label: string | null };

export function notifyEmails(): string[] {
  return (envGet("NOTIFY_EMAILS") || "").split(",").map(s => s.trim()).filter(s => s.includes("@"));
}
export function siteUrl() { return (envGet("SITE_URL") || envGet("URL") || "https://pizzeriavicolo.it").replace(/\/$/, ""); }

async function log(order_id: string | null, channel: string, recipient: string, status: "SENT" | "FAILED" | "SKIPPED", error?: string, payload?: any) {
  try {
    await sb("notification_log", { method: "POST", body: JSON.stringify({ order_id, channel, recipient: recipient.slice(0, 200), status, attempts: 1, last_error: error ? String(error).slice(0, 500) : null, payload: payload || {} , sent_at: status === "SENT" ? new Date().toISOString() : null }) });
  } catch (e) { console.error("notification_log:", e); }
}

/* ---------------- WEB PUSH ---------------- */
export function vapid() {
  const publicKey = envGet("VAPID_PUBLIC_KEY"), privateKey = envGet("VAPID_PRIVATE_KEY");
  const subject = envGet("VAPID_SUBJECT") || "mailto:pizzeriadelvicolonembro@gmail.com";
  return publicKey && privateKey ? { publicKey, privateKey, subject } : null;
}
export async function sendPushToAll(order_id: string | null, payload: { title: string; body: string; tag?: string; url?: string; urgent?: boolean }) {
  const v = vapid(); if (!v) { await log(order_id, "push", "*", "SKIPPED", "VAPID non configurato"); return { sent: 0, failed: 0, skipped: true }; }
  let subs: PushSub[] = [];
  try { subs = await sb("push_subscriptions?select=id,endpoint,p256dh,auth,user_label&limit=200"); } catch (e) { await log(order_id, "push", "*", "FAILED", "lettura iscrizioni: " + e); return { sent: 0, failed: 1 }; }
  let sent = 0, failed = 0;
  await Promise.all(subs.map(async s => {
    try {
      const r = await sendWebPush({ endpoint: s.endpoint, p256dh: s.p256dh, auth: s.auth }, JSON.stringify(payload), { publicKey: v.publicKey, privateKey: v.privateKey, subject: v.subject, ttl: 600, urgency: payload.urgent ? "high" : "normal" });
      if (!r.ok) throw Object.assign(new Error(`${r.status} ${r.body.slice(0, 200)}`), { statusCode: r.status });
      sent++; await log(order_id, "push", s.user_label || s.endpoint, "SENT", undefined, { tag: payload.tag });
      await sb(`push_subscriptions?id=eq.${s.id}`, { method: "PATCH", body: JSON.stringify({ last_ok_at: new Date().toISOString(), last_error: null }) }).catch(() => {});
    } catch (e: any) {
      failed++; const code = e?.statusCode;
      await log(order_id, "push", s.user_label || s.endpoint, "FAILED", String(e?.message || e));
      if (code === 404 || code === 410) { await sb(`push_subscriptions?id=eq.${s.id}`, { method: "DELETE" }).catch(() => {}); } // iscrizione scaduta: rimossa
      else await sb(`push_subscriptions?id=eq.${s.id}`, { method: "PATCH", body: JSON.stringify({ last_error: String(e?.message || e).slice(0, 300) }) }).catch(() => {});
    }
  }));
  return { sent, failed };
}

/* ---------------- EMAIL (Resend) ---------------- */
/* Trasforma la comanda in HTML: le righe marcate (numero ordine, CONSEGNA/RITIRO, orario, TOTALE)
   escono grandi, esattamente come sulla stampante e nell'app. */
export function ticketHtmlEmail(ticket: string, adminUrl: string) {
  const esc = (t: string) => escapeHtml(t);
  const rows = String(ticket || "").split("\n").map(l => {
    if (l.startsWith("\u0001")) return `<div style="font:800 26px/1.25 Arial,Helvetica,sans-serif;text-align:center;color:#111;margin:6px 0">${esc(l.slice(1).trim())}</div>`;
    if (/^-{10,}$/.test(l.trim())) return `<hr style="border:0;border-top:1px solid #ccc;margin:10px 0">`;
    if (!l.trim()) return `<div style="height:8px"></div>`;
    return `<div style="font:15px/1.45 ui-monospace,Menlo,Consolas,monospace;color:#111;white-space:pre-wrap">${esc(l)}</div>`;
  }).join("");
  return `<div style="background:#f4f4f4;padding:16px"><div style="max-width:420px;margin:0 auto;background:#fff;border-radius:12px;padding:18px">${rows}
    <div style="margin-top:16px;text-align:center"><a href="${esc(adminUrl)}" style="display:inline-block;background:#ffc400;color:#111;font:800 16px Arial,Helvetica,sans-serif;text-decoration:none;padding:13px 22px;border-radius:10px">APRI IL GESTIONALE</a></div>
  </div></div>`;
}
export async function sendEmailToOwners(order_id: string | null, subject: string, text: string, html?: string) {
  const key = envGet("RESEND_API_KEY"); const to = notifyEmails();
  const from = envGet("NOTIFY_FROM") || "Pizzeria del Vicolo <onboarding@resend.dev>";
  if (!key) { await log(order_id, "email", to.join(",") || "*", "SKIPPED", "RESEND_API_KEY non configurata"); return { sent: 0, skipped: true }; }
  if (!to.length) { await log(order_id, "email", "*", "SKIPPED", "NOTIFY_EMAILS vuoto"); return { sent: 0, skipped: true }; }
  try {
    const r = await fetch("https://api.resend.com/emails", { method: "POST", headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
      body: JSON.stringify({ from, to, subject, text, html: html || `<pre style="font:15px/1.5 monospace;white-space:pre-wrap">${escapeHtml(text)}</pre>` }) });
    const body = await r.text();
    if (!r.ok) throw new Error(`Resend ${r.status}: ${body}`);
    await log(order_id, "email", to.join(","), "SENT", undefined, { id: safeJson(body)?.id });
    return { sent: to.length };
  } catch (e) { await log(order_id, "email", to.join(","), "FAILED", String(e)); return { sent: 0, failed: 1 }; }
}

/* ---------------- TELEGRAM (gratis, illimitato): messaggio a un gruppo con proprietari e staff ---------------- */
export function telegramCfg() {
  const token = envGet("TELEGRAM_BOT_TOKEN"); const chats = (envGet("TELEGRAM_CHAT_IDS") || "").split(",").map(s => s.trim()).filter(Boolean);
  return token ? { token, chats } : null;
}
export async function sendTelegram(order_id: string | null, text: string) {
  const cfg = telegramCfg();
  if (!cfg) { await log(order_id, "telegram", "*", "SKIPPED", "TELEGRAM_BOT_TOKEN non configurato"); return { sent: 0, skipped: true }; }
  if (!cfg.chats.length) { await log(order_id, "telegram", "*", "SKIPPED", "TELEGRAM_CHAT_IDS vuoto (vedi Impostazioni → Telegram)"); return { sent: 0, skipped: true }; }
  let sent = 0, failed = 0;
  for (const chat of cfg.chats) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${cfg.token}/sendMessage`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ chat_id: chat, text: text.slice(0, 3900), parse_mode: "HTML", disable_notification: false }) });
      const body = await r.text(); if (!r.ok) throw new Error(`Telegram ${r.status}: ${body}`);
      sent++; await log(order_id, "telegram", chat, "SENT");
    } catch (e) { failed++; await log(order_id, "telegram", chat, "FAILED", String(e)); }
  }
  return { sent, failed };
}
/* Chat viste dal bot (per trovare l'ID del gruppo senza strumenti tecnici) */
export async function telegramChats() {
  const cfg = telegramCfg(); if (!cfg) return { configured: false, chats: [] };
  const r = await fetch(`https://api.telegram.org/bot${cfg.token}/getUpdates?limit=100`); const d: any = await r.json().catch(() => ({}));
  const seen: Record<string, any> = {};
  (d.result || []).forEach((u: any) => { const c = (u.message || u.channel_post || u.my_chat_member || {}).chat; if (c) seen[c.id] = { id: String(c.id), title: c.title || [c.first_name, c.last_name].filter(Boolean).join(" ") || c.username || "chat", type: c.type }; });
  return { configured: true, active: cfg.chats, chats: Object.values(seen) };
}

/* ---------------- NTFY (gratis): allarme "insistente" che continua a suonare finché non viene toccato ----------------
   L'app ntfy (Android/iPhone) iscritta al "topic" riceve la notifica con priorità massima. Nel testo NON mettiamo dati del cliente:
   il topic è come una password, ma resta prudente mandare solo numero ordine e importo. */
export function ntfyCfg() {
  const topic = (envGet("NTFY_TOPIC") || "").trim(); if (!topic) return null;
  return { topic, server: (envGet("NTFY_SERVER") || "https://ntfy.sh").replace(/\/$/, ""), token: envGet("NTFY_TOKEN") || "" };
}
export async function sendNtfy(order_id: string | null, title: string, body: string, urgent: boolean) {
  const cfg = ntfyCfg(); if (!cfg) { await log(order_id, "ntfy", "*", "SKIPPED", "NTFY_TOPIC non configurato"); return { sent: 0, skipped: true }; }
  try {
    const h: Record<string, string> = { Title: title.replace(/[^\x20-\x7E]/g, "").trim() || "Pizzeria", Priority: urgent ? "5" : "4", Tags: urgent ? "rotating_light,pizza" : "pizza", Click: siteUrl() + "/admin/", "Content-Type": "text/plain; charset=utf-8" };
    if (cfg.token) h.Authorization = `Bearer ${cfg.token}`;
    const r = await fetch(`${cfg.server}/${encodeURIComponent(cfg.topic)}`, { method: "POST", headers: h, body });
    const txt = await r.text(); if (!r.ok) throw new Error(`ntfy ${r.status}: ${txt}`);
    await log(order_id, "ntfy", cfg.topic, "SENT"); return { sent: 1 };
  } catch (e) { await log(order_id, "ntfy", cfg.topic, "FAILED", String(e)); return { sent: 0, failed: 1 }; }
}

/* ---------------- TELEFONATA (Twilio, facoltativa) ---------------- */
export async function callOwners(order_id: string | null, message: string) {
  const sid = envGet("TWILIO_ACCOUNT_SID"), token = envGet("TWILIO_AUTH_TOKEN"), from = envGet("TWILIO_FROM");
  const to = (envGet("CALL_NUMBERS") || "").split(",").map(s => s.trim()).filter(Boolean);
  if (!sid || !token || !from || !to.length) { await log(order_id, "call", to.join(",") || "*", "SKIPPED", "Twilio non configurato"); return { sent: 0, skipped: true }; }
  let sent = 0;
  for (const num of to) {
    try {
      const twiml = `<Response><Say language="it-IT" voice="alice">${escapeHtml(message)}</Say><Pause length="1"/><Say language="it-IT" voice="alice">${escapeHtml(message)}</Say></Response>`;
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Calls.json`, { method: "POST",
        headers: { authorization: "Basic " + btoa(`${sid}:${token}`), "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ To: num, From: from, Twiml: twiml }) });
      const body = await r.text(); if (!r.ok) throw new Error(`Twilio ${r.status}: ${body}`);
      sent++; await log(order_id, "call", num, "SENT", undefined, { sid: safeJson(body)?.sid });
    } catch (e) { await log(order_id, "call", num, "FAILED", String(e)); }
  }
  return { sent };
}

/* ---------------- NUOVO ORDINE: tutti i canali ---------------- */
export async function notifyNewOrder(order: any, ticket: string) {
  const n = order.order_number, tot = ((order.total_cents || 0) / 100).toFixed(2).replace(".", ",");
  const when = fmtRome(order.requested_at);
  const title = `🍕 NUOVO ORDINE ${n} — € ${tot}`;
  const body = `${order.fulfillment_type === "DELIVERY" ? "Consegna" : "Ritiro"} · richiesto ${when} · ${order.customer_name}. APRI E ACCETTA.`;
  const results: any = {};
  results.push = await sendPushToAll(order.id, { title, body, tag: `order-${order.id}`, url: siteUrl() + "/admin/", urgent: true });
  results.email = await sendEmailToOwners(order.id, `${title} (${order.fulfillment_type === "DELIVERY" ? "consegna" : "ritiro"} ${when})`,
    ticket.replace(/\u0001/g, "") + `\n\nGestionale: ${siteUrl()}/admin/`, ticketHtmlEmail(ticket, siteUrl() + "/admin/"));
  results.telegram = await sendTelegram(order.id, `<b>${escapeHtml(title)}</b>\n${escapeHtml(body)}\n\n<pre>${escapeHtml(ticket.replace(/\u0001/g, ""))}</pre>\n👉 ${siteUrl()}/admin/`);
  results.ntfy = await sendNtfy(order.id, `NUOVO ORDINE ${n} - EUR ${tot}`, `${order.fulfillment_type === "DELIVERY" ? "Consegna" : "Ritiro"} richiesto ${when}. Apri il gestionale e ACCETTA.`, true);
  return results;
}

/* ---------------- ORDINE ANNULLATO: avviso ai proprietari ---------------- */
export async function notifyCancelled(order: any, by: string, reason: string) {
  const n = order.order_number, tot = ((order.total_cents || 0) / 100).toFixed(2).replace(".", ",");
  const title = `❌ ORDINE ${n} ANNULLATO da ${by}`;
  const body = `€ ${tot} · ${order.customer_name || ""} · richiesto ${fmtRome(order.requested_at)}\nMotivo: ${reason}`;
  const out: any = {};
  out.push = await sendPushToAll(order.id, { title, body, tag: `cancel-${order.id}`, url: siteUrl() + "/admin/", urgent: true });
  out.email = await sendEmailToOwners(order.id, title, `${body}\n\nGestionale: ${siteUrl()}/admin/`);
  out.telegram = await sendTelegram(order.id, `<b>${escapeHtml(title)}</b>\n${escapeHtml(body)}`);
  out.ntfy = await sendNtfy(order.id, `ORDINE ${n} ANNULLATO`, `Annullato da ${by}. EUR ${tot}. Motivo: ${reason}`, false);
  return out;
}

export function fmtRome(iso: string | null | undefined) {
  if (!iso) return "—";
  try { return new Intl.DateTimeFormat("it-IT", { timeZone: "Europe/Rome", weekday: "short", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(iso)); } catch { return String(iso); }
}
function escapeHtml(s: string) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function safeJson(s: string) { try { return JSON.parse(s); } catch { return null; } }
