/* Tessera fedeltà: 10 prodotti = € 5 di credito. Identità = numero di telefono.
   - EARN: quando un ordine diventa COMPLETATO, i prodotti (omaggi esclusi) diventano timbri; ogni 10 timbri → € 5 di credito.
   - USE: al checkout il cliente può usare € 5 di credito (uno per ordine).
   - REFUND: se un ordine con credito usato viene annullato, il credito torna disponibile.
   Ogni operazione è registrata in loyalty_ledger ed è idempotente per ordine. */
import { sb } from "./_supabase.ts";
import pricing from "../../shared/pricing.js";

export const GOAL = pricing.LOYALTY.goal;                 // 10 prodotti
export const REWARD_CENTS = Math.round(pricing.LOYALTY.credit * 100); // 500

export function normPhone(p: unknown) {
  let d = String(p || "").replace(/\D/g, "");
  if (d.startsWith("0039")) d = d.slice(4); else if (d.startsWith("39") && d.length >= 12) d = d.slice(2);
  return d;
}
export async function getOrCreateCustomer(name: string, phone: string, email: string) {
  const ph = normPhone(phone); if (ph.length < 8) return null;
  const found = await sb(`customers?phone=eq.${ph}&select=id,name,phone,email`);
  if (found?.[0]) return found[0];
  const code = "C" + Math.random().toString(36).slice(2, 8).toUpperCase();
  const created = await sb("customers", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ customer_code: code, name: name.slice(0, 120), phone: ph, email: (email || "").slice(0, 200) }) });
  return created?.[0] || null;
}
export async function getAccount(customerId: string) {
  const rows = await sb(`loyalty_accounts?customer_id=eq.${customerId}&select=*`);
  if (rows?.[0]) return rows[0];
  const created = await sb("loyalty_accounts", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify({ customer_id: customerId, qualifying_count: 0, available_credit_cents: 0, lifetime_earned_cents: 0 }) });
  return created?.[0];
}
export function summary(acc: any) {
  const count = Number(acc?.qualifying_count || 0), credit = Number(acc?.available_credit_cents || 0);
  return { unitsTotal: count, stamps: count % GOAL, goal: GOAL, missing: GOAL - (count % GOAL), creditCents: credit, rewardCents: REWARD_CENTS, canUse: credit >= REWARD_CENTS };
}
async function patchAccount(acc: any, patch: any) {
  /* PATCH condizionato ai valori letti: se un'altra operazione è passata nel frattempo, nessun danno (0 righe) */
  const rows = await sb(`loyalty_accounts?customer_id=eq.${acc.customer_id}&qualifying_count=eq.${acc.qualifying_count}&available_credit_cents=eq.${acc.available_credit_cents}&select=*`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ ...patch, updated_at: new Date().toISOString() }) });
  if (!rows?.[0]) throw new Error("loyalty: conflitto, riprova");
  return rows[0];
}
/* Timbri per un ordine COMPLETATO (idempotente).
   Regola: si accumula UN SOLO premio da € 5. Finché il cliente non lo usa, i timbri non salgono.
   Quando il premio scatta, il conteggio riparte da zero. */
export async function earnForOrder(order: any, actor: string) {
  const dup = await sb(`loyalty_ledger?order_id=eq.${order.id}&entry_type=eq.EARN&select=id`);
  if (dup?.[0]) return { skipped: true };
  const cust = order.customer_id ? (await sb(`customers?id=eq.${order.customer_id}&select=id,phone`))?.[0] : await getOrCreateCustomer(order.customer_name, order.customer_phone, order.customer_email);
  if (!cust) return { skipped: true };
  const items = await sb(`order_items?order_id=eq.${order.id}&select=quantity,product_key`);
  const units = (items || []).filter((i: any) => i.product_key !== "omaggio").reduce((s: number, i: any) => s + Number(i.quantity || 0), 0);
  if (!units) return { skipped: true };
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const acc = await getAccount(cust.id);
      /* premio già pronto e non usato: non si accumula altro */
      if (Number(acc.available_credit_cents) >= REWARD_CENTS) return { skipped: true, reason: "premio già disponibile" };
      const before = Number(acc.qualifying_count), reached = before + units >= GOAL;
      const after = reached ? 0 : before + units;                    /* al premio si riparte da zero */
      const rewards = reached ? 1 : 0, credit = rewards * REWARD_CENTS;
      await patchAccount(acc, { qualifying_count: after, available_credit_cents: Number(acc.available_credit_cents) + credit, lifetime_earned_cents: Number(acc.lifetime_earned_cents || 0) + credit });
      await sb("loyalty_ledger", { method: "POST", body: JSON.stringify({ customer_id: cust.id, order_id: order.id, entry_type: "EARN", quantity_delta: units, credit_delta_cents: credit, reason: `${units} prodotti (ordine ${order.order_number})${rewards ? ` → +${rewards} premio` : ""}`, actor }) });
      if (!order.customer_id) sb(`orders?id=eq.${order.id}`, { method: "PATCH", body: JSON.stringify({ customer_id: cust.id, loyalty_units: units }) }).catch(() => {});
      else sb(`orders?id=eq.${order.id}`, { method: "PATCH", body: JSON.stringify({ loyalty_units: units }) }).catch(() => {});
      return { units, rewards, credit };
    } catch (e) { if (attempt) throw e; }
  }
}
/* Uso del credito al checkout: toglie € 5 e lo registra. Ritorna i centesimi effettivamente usati. */
export async function useCredit(customerId: string, orderId: string, orderNumber: string) {
  const acc = await getAccount(customerId);
  if (Number(acc.available_credit_cents) < REWARD_CENTS) return 0;
  await patchAccount(acc, { available_credit_cents: Number(acc.available_credit_cents) - REWARD_CENTS });
  await sb("loyalty_ledger", { method: "POST", body: JSON.stringify({ customer_id: customerId, order_id: orderId, entry_type: "USE", quantity_delta: 0, credit_delta_cents: -REWARD_CENTS, reason: `credito usato sull'ordine ${orderNumber}`, actor: "checkout" }) });
  return REWARD_CENTS;
}
/* Ordine annullato: il credito usato torna disponibile (idempotente) */
export async function refundCredit(order: any, actor: string) {
  const used = Number(order.loyalty_credit_used_cents || 0); if (!used || !order.customer_id) return { skipped: true };
  const dup = await sb(`loyalty_ledger?order_id=eq.${order.id}&entry_type=eq.REFUND&select=id`); if (dup?.[0]) return { skipped: true };
  const acc = await getAccount(order.customer_id);
  await patchAccount(acc, { available_credit_cents: Number(acc.available_credit_cents) + used });
  await sb("loyalty_ledger", { method: "POST", body: JSON.stringify({ customer_id: order.customer_id, order_id: order.id, entry_type: "REFUND", quantity_delta: 0, credit_delta_cents: used, reason: `ordine ${order.order_number} annullato`, actor }) });
  return { refunded: used };
}
