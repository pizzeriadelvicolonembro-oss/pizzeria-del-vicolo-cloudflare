import { envGet } from "./env.ts";
/* Accesso a Supabase via REST (PostgREST) con la chiave segreta, SOLO lato server. */
export function cfg() {
  const url = envGet("SUPABASE_URL"); const key = envGet("SUPABASE_SECRET_KEY");
  if (!url || !key) throw new Error("Supabase non configurato (SUPABASE_URL / SUPABASE_SECRET_KEY)");
  return { url: url.replace(/\/$/, ""), key };
}
export async function sb(path: string, init: RequestInit = {}) {
  const { url, key } = cfg();
  const h = new Headers(init.headers);
  h.set("apikey", key); h.set("authorization", `Bearer ${key}`);
  if (init.body && !h.has("content-type")) h.set("content-type", "application/json");
  const r = await fetch(`${url}/rest/v1/${path}`, { ...init, headers: h });
  const text = await r.text(); let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) throw new Error(`Supabase ${r.status}: ${typeof data === "string" ? data : JSON.stringify(data)}`);
  return data;
}
/* Conteggio righe senza scaricarle */
export async function sbCount(path: string): Promise<number> {
  const { url, key } = cfg();
  const r = await fetch(`${url}/rest/v1/${path}`, { method: "HEAD", headers: { apikey: key, authorization: `Bearer ${key}`, Prefer: "count=exact" } });
  if (!r.ok) throw new Error(`Supabase count ${r.status}`);
  const cr = r.headers.get("content-range") || ""; const n = Number(cr.split("/")[1]);
  return Number.isFinite(n) ? n : 0;
}
export const json = (data: any, status = 200, extra: Record<string, string> = {}) =>
  Response.json(data, { status, headers: { "Cache-Control": "no-store", ...extra } });
