/* Su Cloudflare le variabili d'ambiente arrivano a ogni richiesta: le raccogliamo qui,
   così il resto del codice resta identico alla versione Netlify. */
let ENV: Record<string, string> = {};
export function setEnv(e: any) { ENV = e || {}; }
export function envGet(k: string): string | undefined { return (ENV as any)[k]; }
