/* Web Push (RFC 8291 + RFC 8292) con la sola crittografia standard WebCrypto:
   funziona sia su Netlify sia su Cloudflare, senza librerie e senza moduli Node. */
const enc = new TextEncoder();
export const b64u = (b: ArrayBuffer | Uint8Array) => {
  const a = b instanceof Uint8Array ? b : new Uint8Array(b);
  let s = ""; for (let i = 0; i < a.length; i++) s += String.fromCharCode(a[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
export const fromB64u = (s: string) => {
  const t = String(s).replace(/-/g, "+").replace(/_/g, "/"); const pad = "=".repeat((4 - t.length % 4) % 4);
  const bin = atob(t + pad); const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
};
const concat = (...parts: Uint8Array[]) => { const len = parts.reduce((n, p) => n + p.length, 0); const out = new Uint8Array(len); let o = 0; parts.forEach(p => { out.set(p, o); o += p.length; }); return out; };

/* chiave privata VAPID (32 byte) → CryptoKey per firmare (ES256) */
async function vapidKey(privateKey: string, publicKey: string) {
  const d = fromB64u(privateKey), pub = fromB64u(publicKey);
  const jwk = { kty: "EC", crv: "P-256", d: b64u(d), x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)), ext: true };
  return crypto.subtle.importKey("jwk", jwk as any, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
}
export async function vapidAuthHeader(endpoint: string, publicKey: string, privateKey: string, subject: string) {
  const header = b64u(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const payload = b64u(enc.encode(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject })));
  const key = await vapidKey(privateKey, publicKey);
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(`${header}.${payload}`));
  return `vapid t=${header}.${payload}.${b64u(sig)}, k=${publicKey}`;
}

async function hkdf(salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, len: number) {
  const key = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-256", salt, info }, key, len * 8));
}
/* Cifratura aes128gcm per il browser del destinatario */
export async function encryptPayload(p256dh: string, auth: string, payload: string) {
  const uaPublic = fromB64u(p256dh), authSecret = fromB64u(auth);
  if (uaPublic.length !== 65 || authSecret.length !== 16) throw new Error("chiavi iscrizione non valide");
  const pair = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const asPublic = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
  const uaKey = await crypto.subtle.importKey("raw", uaPublic, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: uaKey }, pair.privateKey, 256));
  const ikm = await hkdf(authSecret, shared, concat(enc.encode("WebPush: info\0"), uaPublic, asPublic), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  const nonce = await hkdf(salt, ikm, enc.encode("Content-Encoding: nonce\0"), 12);
  const aes = await crypto.subtle.importKey("raw", cek, "AES-GCM", false, ["encrypt"]);
  const plain = concat(enc.encode(payload), new Uint8Array([2]));      /* 0x02 = ultimo record */
  const body = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce, tagLength: 128 }, aes, plain));
  const rs = new Uint8Array(4); new DataView(rs.buffer).setUint32(0, 4096);
  return concat(salt, rs, new Uint8Array([asPublic.length]), asPublic, body);
}

export type PushResult = { ok: boolean; status: number; body: string };
export async function sendWebPush(sub: { endpoint: string; p256dh: string; auth: string }, payload: string, opts: { publicKey: string; privateKey: string; subject: string; ttl?: number; urgency?: "very-low" | "low" | "normal" | "high" }): Promise<PushResult> {
  const body = await encryptPayload(sub.p256dh, sub.auth, payload);
  const r = await fetch(sub.endpoint, { method: "POST", headers: { Authorization: await vapidAuthHeader(sub.endpoint, opts.publicKey, opts.privateKey, opts.subject), "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", TTL: String(opts.ttl ?? 600), Urgency: opts.urgency || "normal" }, body });
  return { ok: r.ok, status: r.status, body: await r.text().catch(() => "") };
}
