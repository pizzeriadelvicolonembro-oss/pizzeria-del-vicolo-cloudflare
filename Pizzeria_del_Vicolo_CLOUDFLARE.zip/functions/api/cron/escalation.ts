/* Ogni 2 minuti: ordini NUOVI non accettati.
   - dopo 3 minuti: push urgente + email "NON ACCETTATO"
   - poi un promemoria push ogni 3 minuti, al massimo 10 volte
   - dopo 10 minuti: TELEFONATA automatica ai numeri in CALL_NUMBERS (se Twilio configurato)
   Si ferma da solo appena l'ordine viene accettato/annullato. */
import { sb } from "../../_lib/_supabase.ts";
import { sendPushToAll, sendEmailToOwners, sendTelegram, sendNtfy, callOwners, siteUrl, fmtRome } from "../../_lib/_notify.ts";
const AFTER_MIN = 3, EVERY_MIN = 3, MAX_REMINDERS = 10, CALL_AFTER_MIN = 10;
const handler = async (req?: Request, context?: any) => {
  const now = Date.now();
  const rows = await sb(`orders?select=id,order_number,total_cents,customer_name,customer_phone,requested_at,created_at,escalated_at,reminder_count,last_reminder_at,called_at,ticket_text&status=eq.NUOVO&created_at=lte.${new Date(now - AFTER_MIN * 60_000).toISOString()}&limit=50`).catch(e => { console.error(e); return []; });
  for (const o of rows || []) {
    const tot = ((o.total_cents || 0) / 100).toFixed(2).replace(".", ",");
    const waiting = Math.floor((now - new Date(o.created_at).getTime()) / 60_000);
    const patch: any = {};
    if (!o.escalated_at) {
      await sendPushToAll(o.id, { title: `⚠️ ORDINE ${o.order_number} NON ACCETTATO`, body: `In attesa da ${waiting} min · € ${tot} · ${o.customer_name}. Apri il gestionale ORA.`, tag: `esc-${o.id}`, url: siteUrl() + "/admin/", urgent: true });
      await sendEmailToOwners(o.id, `⚠️ ORDINE ${o.order_number} NON ACCETTATO da ${waiting} minuti`, (o.ticket_text || "") + `\n\nNessuno ha ancora accettato l'ordine. Gestionale: ${siteUrl()}/admin/`);
      await sendNtfy(o.id, `ORDINE ${o.order_number} NON ACCETTATO`, `In attesa da ${waiting} minuti, EUR ${tot}. Qualcuno apra il gestionale ORA.`, true);
      await sendTelegram(o.id, `⚠️⚠️ <b>ORDINE ${escapeT(o.order_number)} NON ACCETTATO da ${waiting} minuti</b>\n€ ${tot} · ${escapeT(o.customer_name)} · ${escapeT(o.customer_phone)}\nQualcuno apra il gestionale ORA: ${siteUrl()}/admin/`);
      patch.escalated_at = new Date(now).toISOString(); patch.reminder_count = 1; patch.last_reminder_at = patch.escalated_at;
    } else if ((o.reminder_count || 0) < MAX_REMINDERS && (!o.last_reminder_at || now - new Date(o.last_reminder_at).getTime() >= EVERY_MIN * 60_000)) {
      await sendPushToAll(o.id, { title: `⏰ ORDINE ${o.order_number} ancora in attesa`, body: `${waiting} min senza risposta · € ${tot}. Richiesto ${fmtRome(o.requested_at)}.`, tag: `esc-${o.id}`, url: siteUrl() + "/admin/", urgent: true });
      await sendNtfy(o.id, `ORDINE ${o.order_number} ANCORA IN ATTESA`, `${waiting} minuti senza risposta, EUR ${tot}.`, true);
      await sendTelegram(o.id, `⏰ <b>ORDINE ${escapeT(o.order_number)} ancora in attesa</b> — ${waiting} min senza risposta · € ${tot}\n${siteUrl()}/admin/`);
      patch.reminder_count = (o.reminder_count || 0) + 1; patch.last_reminder_at = new Date(now).toISOString();
    }
    if (!o.called_at && waiting >= CALL_AFTER_MIN) {
      await callOwners(o.id, `Attenzione. Ordine ${o.order_number.replace(/-/g, " ")} sul sito della pizzeria non accettato da ${waiting} minuti. Importo ${tot} euro. Aprire il gestionale.`);
      patch.called_at = new Date(now).toISOString();
    }
    if (Object.keys(patch).length) await sb(`orders?id=eq.${o.id}`, { method: "PATCH", body: JSON.stringify(patch) }).catch(e => console.error(e));
  }
  return new Response(JSON.stringify({ checked: (rows || []).length }), { headers: { "content-type": "application/json" } });
};
function escapeT(s: unknown) { return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
/* Ogni 2 minuti dalle 8 alle 23 UTC (10–01 ora italiana): ~13.500 esecuzioni al mese, dentro il piano gratuito Netlify. */
/* Ogni 3 minuti dalle 9 alle 21 UTC (11–23 ora italiana): ~7.800 esecuzioni al mese. */

import { setEnv } from "../../_lib/env.ts";
/* Cloudflare Pages non ha il cron: questo indirizzo va chiamato ogni 3 minuti da un
   servizio gratuito (es. cron-job.org) con ?key=CRON_KEY. Senza chiave giusta risponde 404. */
export const onRequest = async (ctx: any) => {
  setEnv(ctx.env);
  const key = new URL(ctx.request.url).searchParams.get("key") || "";
  const expected = (ctx.env.CRON_KEY || "").trim();
  if (!expected || key !== expected) return new Response("Not found", { status: 404 });
  return handler(ctx.request, ctx);
};
