/* Creazione ordine dal sito cliente. Il server RICALCOLA prezzi e promozioni con shared/pricing.js:
   il totale del cliente viene solo confrontato, mai creduto. Controlla orari di apertura, orario nel
   passato, capacità della fascia, idempotenza. Poi salva e avvisa la pizzeria (push + email). */
import { sb, sbCount, json } from "../_lib/_supabase.ts";
import { notifyNewOrder } from "../_lib/_notify.ts";
import { getOrCreateCustomer, getAccount, useCredit, summary, REWARD_CENTS } from "../_lib/_loyalty.ts";
import pricing from "../../shared/pricing.js";

const clean = (s: unknown, max = 500) => typeof s === "string" ? s.trim().slice(0, max) : "";
const toCents = (n: number) => Math.round(n * 100);

async function slotCapacity(): Promise<number | null> {
  try { const rows = await sb("settings?key=eq.slot_capacity&select=value"); const v = Number(rows?.[0]?.value?.n); return Number.isFinite(v) && v > 0 ? v : null; } catch { return null; }
}

const handler = async (req: Request, context?: any) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const body = await req.json().catch(() => null);
  if (!body) return json({ error: "Dati non validi" }, 400);

  /* --- dati cliente --- */
  const idem = clean(body.idempotencyKey, 120);
  const name = clean(body.customer?.name, 120), phone = clean(body.customer?.phone, 60).replace(/[^\d+ ]/g, ""), email = clean(body.customer?.email, 200);
  const fulfillment = body.fulfillmentType === "DELIVERY" ? "DELIVERY" : "PICKUP";
  const address = clean(body.address, 500);
  if (!idem || !name || phone.replace(/\D/g, "").length < 8) return json({ error: "Inserisci nome e un numero di telefono valido" }, 400);
  if (fulfillment === "DELIVERY" && address.length < 5) return json({ error: "Inserisci l'indirizzo di consegna" }, 400);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ error: "Email non valida" }, 400);
  if (!Array.isArray(body.items) || !body.items.length) return json({ error: "Il carrello è vuoto" }, 400);

  /* --- orario richiesto (istante UTC, valutato in ora di Roma) --- */
  const requested = new Date(String(body.requestedAt || ""));
  if (Number.isNaN(requested.getTime())) return json({ error: "Orario non valido" }, 400);
  const now = Date.now();
  if (requested.getTime() < now - 60_000) return json({ error: "L'orario scelto è già passato: scegli un altro orario" }, 400);
  if (requested.getTime() < now + (pricing.MIN_LEAD_MINUTES - 5) * 60_000) return json({ error: `Serve almeno ${pricing.MIN_LEAD_MINUTES} minuti di anticipo` }, 400);
  if (requested.getTime() > now + pricing.MAX_DAYS_AHEAD * 86_400_000) return json({ error: "Data troppo lontana" }, 400);
  const moment = pricing.romeParts(requested);
  if (!pricing.isOpenAt(moment.weekday, moment.mins)) return json({ error: "La pizzeria è chiusa nell'orario scelto" }, 400);

  /* --- ricalcolo server dei prezzi --- */
  const items = body.items.slice(0, 60).map((it: any) => ({ baseKey: clean(it.baseKey, 40), qty: Number(it.qty), addons: Array.isArray(it.addons) ? it.addons.slice(0, 20).map((a: any) => clean(a, 60)) : [], note: clean(it.note, 180) }));
  const choices = { cans: Array.isArray(body.choices?.cans) ? body.choices.cans : [], weekendGift: clean(body.choices?.weekendGift, 40), loyaltyCents: 0 };
  let priced = pricing.priceOrder(items, moment, choices);
  if (priced.errors.length) return json({ error: priced.errors[0] }, 400);

  try {
    /* --- idempotenza: stesso invio ripetuto → stesso ordine --- */
    const old = await sb(`orders?idempotency_key=eq.${encodeURIComponent(idem)}&select=*`);
    if (old?.[0]) return json({ order: old[0], duplicate: true });

    /* --- cliente (telefono = identità) e credito fedeltà --- */
    let customer: any = null, account: any = null;
    try { customer = await getOrCreateCustomer(name, phone, email); if (customer) account = await getAccount(customer.id); } catch (e) { console.error("loyalty lookup:", e); }
    const wantsCredit = body.useLoyalty === true;
    if (wantsCredit) {
      if (!account || Number(account.available_credit_cents) < REWARD_CENTS) return json({ error: "Credito fedeltà non disponibile su questo numero di telefono", loyalty: summary(account) }, 409);
      choices.loyaltyCents = REWARD_CENTS; priced = pricing.priceOrder(items, moment, choices);
    }
    if (Math.abs(priced.total - Number(body.clientTotal || 0)) > 0.011) return json({ error: "I prezzi sono stati aggiornati: ricarica la pagina e riprova", serverTotal: priced.total }, 409);

    /* --- capacità per fascia di 15 minuti (configurabile dal proprietario, nessun limite se vuota) --- */
    const cap = await slotCapacity();
    if (cap) {
      const slotStart = new Date(Math.floor(requested.getTime() / (pricing.SLOT_MINUTES * 60_000)) * pricing.SLOT_MINUTES * 60_000);
      const slotEnd = new Date(slotStart.getTime() + pricing.SLOT_MINUTES * 60_000);
      const n = await sbCount(`orders?requested_at=gte.${slotStart.toISOString()}&requested_at=lt.${slotEnd.toISOString()}&status=neq.ANNULLATO&select=id`);
      if (n >= cap) return json({ error: "Questa fascia oraria è piena: scegli un altro orario", slotFull: true }, 409);
    }

    const orderNumber = `V${new Date().toISOString().slice(2, 10).replaceAll("-", "")}-${crypto.randomUUID().slice(0, 4).toUpperCase()}`;
    const requestedText = pricing.romeParts(requested).dateStr.split("-").reverse().join("/") + " " + pricing.romeParts(requested).timeStr;
    const ticket = pricing.buildTicket({ orderNumber, fulfillmentType: fulfillment, address, requestedText, lines: priced.lines, gifts: priced.gifts, subtotal: priced.subtotal, delta: priced.delta, loyaltyDiscount: priced.loyaltyDiscount, total: priced.total, paymentMethod: clean(body.paymentMethod, 80) || "Contanti", customer: { name, phone }, notes: clean(body.notes, 1200), allergyNotes: clean(body.allergyNotes, 1200) });

    const payload = {
      order_number: orderNumber, idempotency_key: idem, fulfillment_type: fulfillment, requested_at: requested.toISOString(), status: "NUOVO", customer_id: customer?.id || null,
      subtotal_cents: toCents(priced.subtotal), promo_discount_cents: toCents(Math.max(0, priced.delta)), loyalty_credit_used_cents: toCents(priced.loyaltyDiscount), total_cents: toCents(priced.total),
      payment_method: clean(body.paymentMethod, 80) || "Contanti", payment_status: "PENDING",
      customer_name: name, customer_phone: phone, customer_email: email || "", address_snapshot: fulfillment === "DELIVERY" ? address : null,
      notes: clean(body.notes, 1200) || null, allergy_notes: clean(body.allergyNotes, 1200) || null,
      promo_snapshot: { lunch: priced.lunch, evening: priced.evening, weekend: priced.weekend, dolciHalf: priced.dolciHalf, bigGift: priced.bigGift, gifts: priced.gifts, tags: priced.lines.flatMap((l: any) => l.tags) },
      ticket_text: ticket, source: "web"
    };
    const created = await sb("orders", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(payload) });
    const order = created[0];
    if (priced.loyaltyDiscount > 0 && customer) {
      /* scala il credito ora; se non riesce (conflitto), l'ordine resta a prezzo pieno e lo diciamo al cliente */
      let used = 0; try { used = await useCredit(customer.id, order.id, orderNumber); } catch (e) { console.error("useCredit:", e); }
      if (!used) { await sb(`orders?id=eq.${order.id}`, { method: "PATCH", body: JSON.stringify({ loyalty_credit_used_cents: 0, total_cents: toCents(priced.promoTotal) }) }).catch(() => {}); order.loyalty_credit_used_cents = 0; order.total_cents = toCents(priced.promoTotal); }
    }
    const rows = priced.lines.map((l: any) => ({ order_id: order.id, product_key: l.baseKey, product_name: l.name, quantity: l.qty, base_unit_cents: toCents(l.listUnit), effective_unit_cents: toCents(l.unit), modifiers: l.addons, item_notes: l.note || null, allergens_snapshot: [] }));
    priced.gifts.forEach((g: any) => rows.push({ order_id: order.id, product_key: "omaggio", product_name: g.name + " (OMAGGIO)", quantity: g.qty, base_unit_cents: 0, effective_unit_cents: 0, modifiers: [], item_notes: null, allergens_snapshot: [] }));
    await sb("order_items", { method: "POST", body: JSON.stringify(rows) });
    sb("audit_log", { method: "POST", body: JSON.stringify({ entity_type: "order", entity_id: order.id, action: "CREATED", actor: "checkout", details: { order_number: orderNumber, total_cents: order.total_cents } }) }).catch(() => {});

    /* --- avvisi alla pizzeria: non devono mai far fallire l'ordine --- */
    let notify: any = null;
    try { notify = await notifyNewOrder(order, ticket); } catch (e) { console.error("notify:", e); }

    return json({ order: { ...order, items: rows }, notify, loyalty: account ? summary(account) : null }, 201);
  } catch (e: any) {
    console.error(e);
    /* messaggio chiaro quando mancano le variabili d'ambiente (es. dopo un trasloco di hosting) */
    if (/non configurat|SUPABASE/i.test(String(e?.message || ""))) return json({ error: "Il sito non è collegato al database: mancano le variabili SUPABASE. Chiama la pizzeria allo 035 034 6406." }, 503);
    return json({ error: "Errore nel salvataggio dell'ordine. Riprova tra poco." }, 500);
  }
};

import { setEnv } from "../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
