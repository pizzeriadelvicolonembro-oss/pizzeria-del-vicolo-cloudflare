/* Registro notifiche (ultime 200) per capire cosa è partito e cosa ha fallito. */
import { isAdmin } from "../../_lib/_auth.ts";
import { sb, json } from "../../_lib/_supabase.ts";
const handler = async (req: Request, context?: any) => {
  if (!(await isAdmin(req))) return json({ error: "Non autorizzato" }, 401);
  try { return json({ log: await sb("notification_log?select=*&order=created_at.desc&limit=200"), subscriptions: await sb("push_subscriptions?select=id,user_label,role,created_at,last_ok_at,last_error&order=created_at.desc") }); }
  catch (e) { console.error(e); return json({ error: "Registro non disponibile" }, 503); }
};

import { setEnv } from "../../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
