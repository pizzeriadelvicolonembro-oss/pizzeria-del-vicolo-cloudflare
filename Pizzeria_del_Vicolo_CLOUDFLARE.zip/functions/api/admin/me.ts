import { getSession } from "../../_lib/_auth.ts";
const handler = async (req: Request, context?: any) => {
  const s = await getSession(req); if (!s) return Response.json({ error: "Non autorizzato" }, { status: 401 });
  return Response.json({ role: s.role, user: s.user, exp: s.exp }, { headers: { "Cache-Control": "no-store" } });
};

import { setEnv } from "../../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
