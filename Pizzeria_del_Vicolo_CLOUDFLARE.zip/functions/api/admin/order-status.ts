/* Cambio stato con transizioni controllate e tracciamento di CHI ha fatto cosa.
   body: { id, status, reason?, delayMinutes? (0/15/30/45/60 in accettazione), confirmedAt? }
   ACCETTATO calcola confirmed_at = requested_at + delayMinutes. */
import { getSession } from "../../_lib/_auth.ts";
import { sb, json } from "../../_lib/_supabase.ts";
import { earnForOrder, refundCredit } from "../../_lib/_loyalty.ts";
import { notifyCancelled } from "../../_lib/_notify.ts";
const NEXT: Record<string, string[]> = {
  NUOVO: ["ACCETTATO", "ANNULLATO"],
  ACCETTATO: ["IN_PREPARAZIONE", "PRONTO", "ANNULLATO"],
  IN_PREPARAZIONE: ["PRONTO", "ANNULLATO"],
  PRONTO: ["IN_CONSEGNA", "COMPLETATO", "ANNULLATO"],
  IN_CONSEGNA: ["COMPLETATO", "ANNULLATO"],
  COMPLETATO: [], ANNULLATO: []
};
const handler = async (req: Request, context?: any) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { id, status, reason, delayMinutes, confirmedAt } = await req.json().catch(() => ({}));
  if (!id || !NEXT[status]) return json({ error: "Stato non valido" }, 400);
  if (status === "ANNULLATO" && (!reason || String(reason).trim().length < 3)) return json({ error: "Motivo annullamento obbligatorio" }, 400);
  try {
    const cur = (await sb(`orders?id=eq.${encodeURIComponent(id)}&select=id,status,requested_at,fulfillment_type,order_number,customer_id,customer_name,customer_phone,customer_email,loyalty_credit_used_cents,total_cents`))?.[0];
    if (!cur) return json({ error: "Ordine non trovato" }, 404);
    if (!NEXT[cur.status]?.includes(status)) return json({ error: `Da ${cur.status} non si può passare a ${status}`, current: cur.status }, 409);
    if (status === "IN_CONSEGNA" && cur.fulfillment_type !== "DELIVERY") return json({ error: "Ordine da ritiro: usa COMPLETATO" }, 400);
    const nowIso = new Date().toISOString();
    const patch: any = { status, updated_by: s.user, updated_at: nowIso };
    if (status === "ACCETTATO") {
      const delay = [0, 15, 30, 45, 60].includes(Number(delayMinutes)) ? Number(delayMinutes) : 0;
      let conf = confirmedAt ? new Date(confirmedAt) : new Date(new Date(cur.requested_at).getTime() + delay * 60_000);
      if (Number.isNaN(conf.getTime())) conf = new Date(cur.requested_at);
      Object.assign(patch, { accepted_at: nowIso, accepted_by: s.user, confirmed_at: conf.toISOString(), delay_minutes: delay });
    }
    if (status === "COMPLETATO") patch.completed_at = nowIso;
    if (status === "ANNULLATO") Object.assign(patch, { cancelled_at: nowIso, cancellation_reason: String(reason).trim().slice(0, 300), cancelled_by: s.user });
    /* PATCH condizionato allo stato corrente: due tablet che premono insieme non si sovrascrivono */
    const rows = await sb(`orders?id=eq.${encodeURIComponent(id)}&status=eq.${cur.status}&select=id,order_number,status,confirmed_at,accepted_by,updated_by`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(patch) });
    if (!rows?.[0]) return json({ error: "Ordine già modificato da un altro dispositivo: ricarica" }, 409);
    sb("audit_log", { method: "POST", body: JSON.stringify({ entity_type: "order", entity_id: id, action: "STATUS_" + status, actor: s.user, details: { from: cur.status, to: status, reason: reason || null, delayMinutes: patch.delay_minutes ?? null } }) }).catch(() => {});
    /* tessera fedeltà: timbri all'ordine completato, rimborso del credito se annullato. Un errore qui non blocca il cambio stato. */
    let loyalty: any = null;
    try { if (status === "COMPLETATO") loyalty = await earnForOrder(cur, s.user); else if (status === "ANNULLATO") loyalty = await refundCredit(cur, s.user); } catch (e) { console.error("loyalty:", e); loyalty = { error: String(e) }; }
    /* annullamento: i proprietari devono saperlo subito (push, email, Telegram, ntfy) */
    if (status === "ANNULLATO") { try { await notifyCancelled(cur, s.user, String(reason).trim().slice(0, 300)); } catch (e) { console.error("notifyCancelled:", e); } }
    return json({ ok: true, order: rows[0], loyalty });
  } catch (e) { console.error(e); return json({ error: "Errore aggiornamento ordine" }, 500); }
};

import { setEnv } from "../../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
