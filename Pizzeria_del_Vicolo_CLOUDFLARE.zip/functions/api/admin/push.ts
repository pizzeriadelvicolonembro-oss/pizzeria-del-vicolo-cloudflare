/* Notifiche push per il gestionale.
   GET  /api/admin/push   → chiave pubblica VAPID (per iscrivere il dispositivo)
   POST /api/admin/push   → salva l'iscrizione di questo dispositivo {subscription, label}
   DELETE /api/admin/push → rimuove l'iscrizione {endpoint}
   POST /api/admin/push?test=1 → invia una push di prova a tutti i dispositivi */
import { getSession } from "../../_lib/_auth.ts";
import { sb, json } from "../../_lib/_supabase.ts";
import { vapid, sendPushToAll, sendTelegram, sendNtfy, telegramChats, ntfyCfg, siteUrl } from "../../_lib/_notify.ts";
const handler = async (req: Request, context?: any) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  const v = vapid();
  if (req.method === "GET" && new URL(req.url).searchParams.get("telegram")) { try { return json(await telegramChats()); } catch (e) { return json({ configured: true, chats: [], error: String(e) }); } }
  if (req.method === "GET") return json({ publicKey: v?.publicKey || null, configured: !!v, ntfy: ntfyCfg() ? { topic: ntfyCfg()!.topic, server: ntfyCfg()!.server } : null });
  try {
    if (req.method === "POST" && new URL(req.url).searchParams.get("test")) {
      const r = await sendPushToAll(null, { title: "🔔 Prova notifiche", body: `Le notifiche funzionano su questo dispositivo (${s.user})`, tag: "test", url: siteUrl() + "/admin/" });
      const t = await sendTelegram(null, `🔔 <b>Prova notifiche</b> — inviata da ${s.user} dal gestionale. Se leggi questo, Telegram funziona.`);
      const nt = await sendNtfy(null, "PROVA ALLARME ORDINI", `Prova inviata da ${s.user}. Se suona forte, sei a posto.`, true);
      return json({ ok: true, ...r, telegram: t, ntfy: nt });
    }
    if (req.method === "POST") {
      if (!v) return json({ error: "Push non configurate su Netlify (VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY)" }, 503);
      const { subscription, label } = await req.json().catch(() => ({}));
      const endpoint = subscription?.endpoint, p256dh = subscription?.keys?.p256dh, auth = subscription?.keys?.auth;
      if (!endpoint || !p256dh || !auth) return json({ error: "Iscrizione non valida" }, 400);
      await sb("push_subscriptions", { method: "POST", headers: { Prefer: "resolution=merge-duplicates" }, body: JSON.stringify({ endpoint, p256dh, auth, user_label: `${s.user} · ${String(label || "").slice(0, 80)}`, role: s.role, updated_at: new Date().toISOString() }) });
      return json({ ok: true });
    }
    if (req.method === "DELETE") {
      const { endpoint } = await req.json().catch(() => ({}));
      if (endpoint) await sb(`push_subscriptions?endpoint=eq.${encodeURIComponent(endpoint)}`, { method: "DELETE" });
      return json({ ok: true });
    }
    return new Response("Method not allowed", { status: 405 });
  } catch (e) { console.error(e); return json({ error: "Errore notifiche" }, 500); }
};

import { setEnv } from "../../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
