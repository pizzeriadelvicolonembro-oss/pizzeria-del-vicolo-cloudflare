/* Ristampa una comanda sulla stampante cloud (rimette l'ordine in coda). */
import { getSession } from "../../_lib/_auth.ts";
import { sb, json } from "../../_lib/_supabase.ts";
const handler = async (req: Request, context?: any) => {
  const s = await getSession(req); if (!s) return json({ error: "Non autorizzato" }, 401);
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { id } = await req.json().catch(() => ({})); if (!id) return json({ error: "Ordine mancante" }, 400);
  try {
    const rows = await sb(`orders?id=eq.${encodeURIComponent(id)}&select=id,order_number`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ printed_at: null, reprint_requested_at: new Date().toISOString(), reprint_by: s.user }) });
    if (!rows?.[0]) return json({ error: "Ordine non trovato" }, 404);
    const seen = (await sb("settings?key=eq.printer_last_seen&select=value"))?.[0]?.value;
    return json({ ok: true, printerSeenAt: seen?.at || null });
  } catch (e) { console.error(e); return json({ error: "Errore ristampa" }, 500); }
};

import { setEnv } from "../../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
