import { clearAdminCookie } from "../../_lib/_auth.ts";
const handler = async (req?: Request, context?: any) => new Response(JSON.stringify({ ok: true }), { headers: { "content-type": "application/json", "set-cookie": clearAdminCookie() } });

import { setEnv } from "../../_lib/env.ts";
export const onRequest = async (ctx: any) => { setEnv(ctx.env); return handler(ctx.request, ctx); };
